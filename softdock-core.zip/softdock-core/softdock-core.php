<?php
/**
 * Plugin Name: Softdock Core
 * Description: Software directory content for the Softdock theme: Software post type, platforms, categories, program details, download counting, ratings and sample data. Keep this active even if you change themes, so your programs stay available.
 * Version: 1.7.1
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: softdock
 */

defined( 'ABSPATH' ) || exit;

define( 'SOFTDOCK_CORE', true );
define( 'SOFTDOCK_CORE_VERSION', '1.7.1' );
define( 'SOFTDOCK_CORE_URL', plugin_dir_url( __FILE__ ) );

require __DIR__ . '/inc/post-types.php';
require __DIR__ . '/inc/meta.php';
require __DIR__ . '/inc/editor.php';
require __DIR__ . '/inc/post-editor.php';
require __DIR__ . '/inc/settings.php';
require __DIR__ . '/inc/downloads.php';
require __DIR__ . '/inc/ratings.php';
require __DIR__ . '/inc/seo.php';
require __DIR__ . '/inc/sample-data.php';
require __DIR__ . '/inc/convert.php';
require __DIR__ . '/inc/csv-import.php';

register_activation_hook( __FILE__, function () {
	softdock_register_types();
	softdock_ensure_platforms();
	flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, function () {
	delete_option( 'softdock_rewrite_version' );
	flush_rewrite_rules();
} );

add_action( 'init', function () {
	load_plugin_textdomain( 'softdock', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );
