/* Tools > Convert to programs: preview, batched convert, undo. */
(function () {
  var form = document.getElementById('sd-convert-form');
  if (!form) return;
  var t = sdConvert.i18n;
  var runBtn = document.getElementById('sd-run');
  var out = document.getElementById('sd-preview-out');
  var progress = document.getElementById('sd-progress');
  var bar = document.getElementById('sd-bar');
  var status = document.getElementById('sd-status');
  var fmt = function (s) { var a = [].slice.call(arguments, 1), i = 0; return s.replace(/%(\d\$)?d|%(\d\$)?s/g, function () { return a[i++]; }); };

  function post(action, extra) {
    var body = new FormData(form);
    body.append('action', action);
    Object.keys(extra || {}).forEach(function (k) { body.append(k, extra[k]); });
    return fetch(sdConvert.ajax, { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) {
      return r.json().catch(function () { throw new Error(t.error); });
    }).then(function (r) {
      if (!r.success) throw new Error((r.data && r.data.message) || t.error);
      return r.data;
    });
  }

  // Changing the source reloads the page so the field and category lists match it.
  ['source_type', 'source_term'].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('change', function () {
      var url = new URL(sdConvert.page);
      url.searchParams.set('source_type', document.getElementById('source_type').value);
      if (id === 'source_term') url.searchParams.set('source_term', el.value);
      location.href = url.toString();
    });
  });

  var previewBtn = document.getElementById('sd-preview');
  if (previewBtn) previewBtn.addEventListener('click', function () {
    previewBtn.disabled = true;
    post('softdock_convert_preview').then(function (d) {
      out.textContent = '';
      if (!d.rows.length) { out.innerHTML = '<p></p>'; out.firstChild.textContent = t.empty; return; }
      var cols = ['old', 'title', 'version', 'size', 'license', 'developer', 'tagline', 'link', 'platforms', 'cats'];
      var wrap = document.createElement('div'); wrap.style.overflowX = 'auto';
      var table = document.createElement('table'); table.className = 'widefat striped';
      var head = table.createTHead().insertRow();
      cols.forEach(function (c) { var th = document.createElement('th'); th.textContent = t[c]; head.appendChild(th); });
      var body = table.createTBody();
      d.rows.forEach(function (r) {
        var tr = body.insertRow();
        cols.forEach(function (c) { var td = tr.insertCell(); td.textContent = r[c] || '—'; });
      });
      wrap.appendChild(table); out.appendChild(wrap);
      runBtn.disabled = d.total === 0;
      runBtn.textContent = fmt(t.convertN, d.total);
      runBtn.dataset.total = d.total;
    }).catch(function (e) { out.textContent = e.message; })
      .finally(function () { previewBtn.disabled = false; });
  });

  if (runBtn) runBtn.addEventListener('click', function () {
    var total = Number(runBtn.dataset.total || 0), done = 0, failed = [];
    runBtn.disabled = true; previewBtn.disabled = true;
    progress.hidden = false;
    (function step() {
      post('softdock_convert_batch').then(function (d) {
        done += d.done; failed = failed.concat(d.failed);
        bar.style.width = Math.min(100, Math.round(done / Math.max(total, 1) * 100)) + '%';
        status.textContent = fmt(t.progress, done, total);
        // Stop when nothing is left, or when a batch converted nothing (only failures remain).
        if (d.remaining > 0 && d.done > 0) return step();
        bar.style.width = '100%';
        status.textContent = fmt(t.finished, done) + (failed.length ? ' ' + fmt(t.failedIds, failed.join(', ')) : '');
        var a = document.createElement('a'); a.href = sdConvert.home; a.textContent = ' ' + t.viewSite; status.appendChild(a);
      }).catch(function (e) { status.textContent = e.message; runBtn.disabled = false; previewBtn.disabled = false; });
    })();
  });

  var undo = document.getElementById('sd-undo');
  if (undo) undo.addEventListener('click', function () {
    var confirmMsg = document.getElementById('sd-undo-confirm');
    if (confirmMsg.hidden) { confirmMsg.hidden = false; undo.textContent += ' ✓'; return; }
    undo.disabled = true;
    var total = 0;
    (function step() {
      post('softdock_unconvert_batch').then(function (d) {
        total += d.done;
        confirmMsg.textContent = fmt(t.undone, total);
        if (d.remaining > 0 && d.done > 0) return step();
        setTimeout(function () { location.href = sdConvert.page; }, 1200);
      }).catch(function (e) { confirmMsg.textContent = e.message; undo.disabled = false; });
    })();
  });
})();
