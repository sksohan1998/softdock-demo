/* Screenshot picker on the program edit screen. */
jQuery(function ($) {
  var frame;
  var $input = $('#sd_screenshots');
  var $list = $('.softdock-shots');
  $('.softdock-pick').on('click', function (e) {
    e.preventDefault();
    if (!frame) {
      frame = wp.media({ title: 'Choose screenshots', button: { text: 'Use these screenshots' }, library: { type: 'image' }, multiple: 'add' });
      frame.on('open', function () {
        var sel = frame.state().get('selection');
        ($input.val() || '').split(',').filter(Boolean).forEach(function (id) {
          var a = wp.media.attachment(id); a.fetch(); sel.add(a);
        });
      });
      frame.on('select', function () {
        var items = frame.state().get('selection').toJSON();
        $input.val(items.map(function (i) { return i.id; }).join(','));
        $list.empty();
        items.forEach(function (i) {
          var url = (i.sizes && i.sizes.thumbnail ? i.sizes.thumbnail : i).url;
          $('<img>').attr({ src: url, alt: '' }).css({ width: 80, height: 80, objectFit: 'cover', borderRadius: 4 }).appendTo($list);
        });
      });
    }
    frame.open();
  });
  var fileFrame;
  $('.softdock-pick-file').on('click', function (e) {
    e.preventDefault();
    if (!fileFrame) {
      fileFrame = wp.media({ title: 'Choose download file', button: { text: 'Use this file' }, multiple: false });
      fileFrame.on('select', function () {
        var f = fileFrame.state().get('selection').first().toJSON();
        $('#sd_file').val(f.id);
        $('.softdock-file-name').text(f.filename);
      });
    }
    fileFrame.open();
  });
  $('.softdock-clear-file').on('click', function (e) { e.preventDefault(); $('#sd_file').val(''); $('.softdock-file-name').text('No file chosen'); });
  $('.softdock-clear').on('click', function (e) { e.preventDefault(); $input.val(''); $list.empty(); });
});
