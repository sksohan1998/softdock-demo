/* Add / edit program screen: live preview text, icon, screenshots and file uploads. */
jQuery(function ($) {
  var t = window.softdockEditor || {};
  var $app = $('.sd-app');
  if (!$app.length) return;

  /* Live text in the band, headings and side card. */
  function firstChecked(tax) {
    var $c = $('.sd-chips[data-tax="' + tax + '"] input:checked').first();
    return $c.length ? $c.data('name') : '';
  }
  function refresh() {
    var title = $.trim($('#title').val()) || $app.data('emptyTitle') || t.program || 'Program name';
    $('.sd-live-title').text(title);
    $('.sd-live-version').text($.trim($('#sd_version').val()));
    $('.sd-letter').text(title.charAt(0).toUpperCase());
    var plat = firstChecked('platform'), cat = firstChecked('software_cat');
    $('.sd-live-platform').text(plat || 'Platform').toggle(true);
    $('.sd-live-cat').text(cat || firstChecked('category') || 'Category');
  }
  /* Grow the name field with its text so "download" sits right after it, like on the page. */
  /* The name box wraps onto more lines for long names instead of widening the page. */
  function sizeTitle() {
    var el = document.getElementById('title'); if (!el) return;
    el.style.height = 'auto';
    el.style.height = el.scrollHeight + 'px';
  }
  $('#title').on('input', sizeTitle).on('keydown', function (e) {
    if (e.key === 'Enter') e.preventDefault(); // names are one line
  }).on('paste', function () {
    var el = this; setTimeout(function () { el.value = el.value.replace(/\s*\n\s*/g, ' '); sizeTitle(); }, 0);
  });
  sizeTitle();
  $(window).on('resize', sizeTitle);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(sizeTitle);
  $('#title, #sd_version').on('input', refresh);
  $app.on('change', '.sd-chips input', refresh);
  refresh();

  $('#sd_color').on('input', function () {
    var c = this.value;
    $('.sd-ico').css('background', c);
    $('.sd-pane').css('background', 'linear-gradient(120deg,' + c + 'cc,' + c + '22)');
  });

  /* Icon (featured image). */
  var iconFrame;
  $('.sd-pick-icon').on('click', function (e) {
    e.preventDefault();
    if (!iconFrame) {
      iconFrame = wp.media({ title: 'Upload icon', button: { text: 'Use as icon' }, library: { type: 'image' }, multiple: false });
      iconFrame.on('select', function () {
        var a = iconFrame.state().get('selection').first().toJSON();
        var url = (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail : a).url;
        $('#sd_icon').val(a.id).trigger('change');
        $('.sd-ico img, .sd-letter').remove();
        $('<img alt="">').attr('src', url).prependTo('.sd-ico');
        $('.sd-clear-icon').prop('hidden', false);
      });
    }
    iconFrame.open();
  });
  $('.sd-clear-icon').on('click', function (e) {
    e.preventDefault();
    $('#sd_icon').val('').trigger('change');
    $('.sd-ico img').remove();
    if (!$('.sd-letter').length) $('<span class="sd-letter"></span>').prependTo('.sd-ico');
    $(this).prop('hidden', true);
    refresh();
  });

  /* Screenshots slider. */
  var $gal = $('.sd-gallery'), cur = 0;
  function layoutShots() {
    var $s = $gal.find('.sd-shot'), n = $s.length;
    cur = Math.min(cur, Math.max(0, n - 1));
    $s.removeClass('on').eq(cur).addClass('on');
    $gal.toggleClass('has-shots', n > 0).toggleClass('many', n > 1);
    var $dots = $gal.find('.sd-dots').empty();
    if (n > 1) for (var i = 0; i < n; i++) $('<i>').toggleClass('on', i === cur).appendTo($dots);
  }
  $gal.on('click', '.sd-arrow', function (e) {
    e.preventDefault();
    var n = $gal.find('.sd-shot').length;
    if (n) { cur = (cur + Number($(this).data('shot')) + n) % n; layoutShots(); }
  });
  layoutShots();

  var shotFrame;
  $('.sd-pick-shots').on('click', function (e) {
    e.preventDefault();
    if (!shotFrame) {
      shotFrame = wp.media({ title: 'Upload screenshots', button: { text: 'Use these screenshots' }, library: { type: 'image' }, multiple: 'add' });
      shotFrame.on('open', function () {
        var sel = shotFrame.state().get('selection');
        sel.reset();
        ($('#sd_screenshots').val() || '').split(',').filter(Boolean).forEach(function (id) {
          var a = wp.media.attachment(id); a.fetch(); sel.add(a);
        });
      });
      shotFrame.on('select', function () {
        var items = shotFrame.state().get('selection').toJSON();
        $('#sd_screenshots').val(items.map(function (i) { return i.id; }).join(',')).trigger('change');
        var $list = $gal.find('.sd-shots').empty();
        items.forEach(function (i) {
          var url = (i.sizes && i.sizes.large ? i.sizes.large : i).url;
          $('<div class="sd-shot">').append($('<img alt="">').attr('src', url)).appendTo($list);
        });
        cur = 0; layoutShots();
      });
    }
    shotFrame.open();
  });
  $('.sd-clear-shots').on('click', function (e) {
    e.preventDefault();
    $('#sd_screenshots').val('').trigger('change');
    $gal.find('.sd-shots').empty();
    layoutShots();
  });

  /* Download file. */
  var fileFrame;
  $('.sd-pick-file').on('click', function (e) {
    e.preventDefault();
    if (!fileFrame) {
      fileFrame = wp.media({ title: 'Upload download file', button: { text: 'Use this file' }, multiple: false });
      fileFrame.on('select', function () {
        var f = fileFrame.state().get('selection').first().toJSON();
        $('#sd_file').val(f.id).trigger('change');
        $('.sd-file-name').text(f.filename);
        $('.sd-clear-file').prop('hidden', false);
      });
    }
    fileFrame.open();
  });
  $('.sd-clear-file').on('click', function (e) {
    e.preventDefault();
    $('#sd_file').val('').trigger('change');
    $('.sd-file-name').text(t.noFile || 'No file chosen');
    $(this).prop('hidden', true);
  });

  /* Featured image on the post screen. */
  var featFrame, $feat = $('.sd-feature');
  $('.sd-pick-feature').on('click', function (e) {
    e.preventDefault();
    if (!featFrame) {
      featFrame = wp.media({ title: 'Upload featured image', button: { text: 'Use this image' }, library: { type: 'image' }, multiple: false });
      featFrame.on('select', function () {
        var a = featFrame.state().get('selection').first().toJSON();
        var url = (a.sizes && a.sizes.large ? a.sizes.large : a).url;
        $('#sd_icon').val(a.id).trigger('change');
        $feat.find('.sd-shots').html($('<div class="sd-shot on">').append($('<img alt="">').attr('src', url)));
        $feat.addClass('has-shots');
      });
    }
    featFrame.open();
  });
  $('.sd-clear-feature').on('click', function (e) {
    e.preventDefault();
    $('#sd_icon').val('').trigger('change');
    $feat.find('.sd-shots').empty();
    $feat.removeClass('has-shots');
  });


  /* Previous versions: add and remove rows. */
  var $vers = $('.sd-vers');
  $('.sd-ver-add').on('click', function (e) {
    e.preventDefault();
    var n = Number($vers.attr('data-next')) || 0;
    var $row = $vers.find('.sd-ver-template').clone().removeClass('sd-ver-template').prop('hidden', false);
    $row.find('input').each(function () {
      $(this).attr('name', 'sd_ver_rows[' + n + '][' + $(this).data('k') + ']').removeAttr('data-name').val('');
    });
    $vers.attr('data-next', n + 1);
    $row.insertBefore($vers.find('.sd-ver-template'));
    $row.find('input').first().trigger('focus');
  });
  $vers.on('click', '.sd-ver-remove', function (e) {
    e.preventDefault();
    $(this).closest('.sd-ver').remove();
  });
  if (!$vers.find('.sd-ver:not(.sd-ver-template)').length) $('.sd-ver-add').trigger('click');
});
