/* Add / edit program screen: live preview text, icon, screenshots and file uploads. */
jQuery(function ($) {
  var t = window.softdockEditor || {};
  var $app = $('.sd-app');
  if (!$app.length) return;

  /* Live text in the band, headings and side card. */
  function firstChecked(tax) {
    var $c = $('.sd-chips[data-tax="' + tax + '"] input:checked').first();
    return $c.length ? $c.data('name') : '';
  }
  function refresh() {
    var title = $.trim($('#title').val()) || t.program || 'Program name';
    $('.sd-live-title').text(title);
    $('.sd-live-version').text($.trim($('#sd_version').val()));
    $('.sd-letter').text(title.charAt(0).toUpperCase());
    var plat = firstChecked('platform'), cat = firstChecked('software_cat');
    $('.sd-live-platform').text(plat || 'Platform').toggle(true);
    $('.sd-live-cat').text(cat || 'Category');
  }
  /* Grow the name field with its text so "download" sits right after it, like on the page. */
  var $mirror = $('<span class="sd-title-mirror" aria-hidden="true"></span>').appendTo('.sd-h2');
  function sizeTitle() {
    var el = document.getElementById('title'); if (!el) return;
    $mirror.text(el.value || el.placeholder);
    el.style.width = Math.ceil($mirror[0].getBoundingClientRect().width) + 2 + 'px';
  }
  $('#title').on('input', sizeTitle);
  sizeTitle();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(sizeTitle);
  $('#title, #sd_version').on('input', refresh);
  $app.on('change', '.sd-chips input', refresh);
  refresh();

  $('#sd_color').on('input', function () {
    var c = this.value;
    $('.sd-ico').css('background', c);
    $('.sd-pane').css('background', 'linear-gradient(120deg,' + c + 'cc,' + c + '22)');
  });

  /* Icon (featured image). */
  var iconFrame;
  $('.sd-pick-icon').on('click', function (e) {
    e.preventDefault();
    if (!iconFrame) {
      iconFrame = wp.media({ title: 'Upload icon', button: { text: 'Use as icon' }, library: { type: 'image' }, multiple: false });
      iconFrame.on('select', function () {
        var a = iconFrame.state().get('selection').first().toJSON();
        var url = (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail : a).url;
        $('#sd_icon').val(a.id).trigger('change');
        $('.sd-ico img, .sd-letter').remove();
        $('<img alt="">').attr('src', url).prependTo('.sd-ico');
        $('.sd-clear-icon').prop('hidden', false);
      });
    }
    iconFrame.open();
  });
  $('.sd-clear-icon').on('click', function (e) {
    e.preventDefault();
    $('#sd_icon').val('').trigger('change');
    $('.sd-ico img').remove();
    if (!$('.sd-letter').length) $('<span class="sd-letter"></span>').prependTo('.sd-ico');
    $(this).prop('hidden', true);
    refresh();
  });

  /* Screenshots slider. */
  var $gal = $('.sd-gallery'), cur = 0;
  function layoutShots() {
    var $s = $gal.find('.sd-shot'), n = $s.length;
    cur = Math.min(cur, Math.max(0, n - 1));
    $s.removeClass('on').eq(cur).addClass('on');
    $gal.toggleClass('has-shots', n > 0).toggleClass('many', n > 1);
    var $dots = $gal.find('.sd-dots').empty();
    if (n > 1) for (var i = 0; i < n; i++) $('<i>').toggleClass('on', i === cur).appendTo($dots);
  }
  $gal.on('click', '.sd-arrow', function (e) {
    e.preventDefault();
    var n = $gal.find('.sd-shot').length;
    if (n) { cur = (cur + Number($(this).data('shot')) + n) % n; layoutShots(); }
  });
  layoutShots();

  var shotFrame;
  $('.sd-pick-shots').on('click', function (e) {
    e.preventDefault();
    if (!shotFrame) {
      shotFrame = wp.media({ title: 'Upload screenshots', button: { text: 'Use these screenshots' }, library: { type: 'image' }, multiple: 'add' });
      shotFrame.on('open', function () {
        var sel = shotFrame.state().get('selection');
        sel.reset();
        ($('#sd_screenshots').val() || '').split(',').filter(Boolean).forEach(function (id) {
          var a = wp.media.attachment(id); a.fetch(); sel.add(a);
        });
      });
      shotFrame.on('select', function () {
        var items = shotFrame.state().get('selection').toJSON();
        $('#sd_screenshots').val(items.map(function (i) { return i.id; }).join(',')).trigger('change');
        var $list = $gal.find('.sd-shots').empty();
        items.forEach(function (i) {
          var url = (i.sizes && i.sizes.large ? i.sizes.large : i).url;
          $('<div class="sd-shot">').append($('<img alt="">').attr('src', url)).appendTo($list);
        });
        cur = 0; layoutShots();
      });
    }
    shotFrame.open();
  });
  $('.sd-clear-shots').on('click', function (e) {
    e.preventDefault();
    $('#sd_screenshots').val('').trigger('change');
    $gal.find('.sd-shots').empty();
    layoutShots();
  });

  /* Download file. */
  var fileFrame;
  $('.sd-pick-file').on('click', function (e) {
    e.preventDefault();
    if (!fileFrame) {
      fileFrame = wp.media({ title: 'Upload download file', button: { text: 'Use this file' }, multiple: false });
      fileFrame.on('select', function () {
        var f = fileFrame.state().get('selection').first().toJSON();
        $('#sd_file').val(f.id).trigger('change');
        $('.sd-file-name').text(f.filename);
        $('.sd-clear-file').prop('hidden', false);
      });
    }
    fileFrame.open();
  });
  $('.sd-clear-file').on('click', function (e) {
    e.preventDefault();
    $('#sd_file').val('').trigger('change');
    $('.sd-file-name').text(t.noFile || 'No file chosen');
    $(this).prop('hidden', true);
  });
});
