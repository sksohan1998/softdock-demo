/* Software > Import (CSV): runs the uploaded file in batches with a progress bar. */
(function () {
  var box = document.getElementById('sd-csv-job');
  if (!box) return;
  var t = sdCsv.i18n;
  var bar = document.getElementById('sd-csv-bar');
  var status = document.getElementById('sd-csv-status');
  var errors = document.getElementById('sd-csv-errors');
  var fmt = function (s) { var a = [].slice.call(arguments, 1), i = 0; return s.replace(/%(\d\$)?d/g, function () { return a[i++]; }); };

  (function step() {
    var body = new FormData();
    body.append('action', 'softdock_csv_run');
    body.append('nonce', box.dataset.nonce);
    body.append('job', box.dataset.job);
    fetch(sdCsv.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { throw new Error(t.error); }); })
      .then(function (r) {
        if (!r.success) throw new Error((r.data && r.data.message) || t.error);
        var d = r.data;
        d.errors.forEach(function (e) { var li = document.createElement('li'); li.textContent = e; errors.appendChild(li); });
        bar.style.width = Math.round(d.offset / Math.max(d.total, 1) * 100) + '%';
        if (!d.finished) { status.textContent = fmt(t.progress, d.offset, d.total); return step(); }
        status.textContent = fmt(t.done, d.stats.added, d.stats.updated, d.stats.failed) + ' ';
        var a = document.createElement('a'); a.href = sdCsv.list; a.textContent = t.view; status.appendChild(a);
      })
      .catch(function (e) { status.textContent = e.message; });
  })();
})();
