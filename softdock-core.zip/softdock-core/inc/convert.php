<?php
/**
 * Tools > Convert to programs: turns posts from an old site (brought in with the WordPress Importer)
 * into Softdock programs. Keeps comments, featured images and attachments, maps old fields and
 * categories, and redirects the old URLs to the new program pages.
 */

defined( 'ABSPATH' ) || exit;

const SOFTDOCK_CONVERT_BATCH = 20;

add_action( 'admin_menu', function () {
	add_management_page( __( 'Convert to programs', 'softdock' ), __( 'Convert to programs', 'softdock' ), 'manage_options', 'softdock-convert', 'softdock_convert_page' );
} );

/** Softdock fields that can be filled from old data: key => [label, kind]. */
function softdock_convert_targets() {
	return array(
		'sd_version'      => array( __( 'Version', 'softdock' ), 'text' ),
		'sd_tagline'      => array( __( 'Tagline', 'softdock' ), 'text' ),
		'sd_size_mb'      => array( __( 'File size', 'softdock' ), 'size' ),
		'sd_license'      => array( __( 'License', 'softdock' ), 'text' ),
		'sd_developer'    => array( __( 'Developer', 'softdock' ), 'text' ),
		'sd_official_url' => array( __( 'Official download page', 'softdock' ), 'url' ),
		'sd_features'     => array( __( 'Features', 'softdock' ), 'lines' ),
		'sd_requirements' => array( __( 'System requirements', 'softdock' ), 'lines' ),
		'sd_downloads'    => array( __( 'Download count', 'softdock' ), 'number' ),
	);
}

/** Labels the "Find in post text" option looks for, per field. */
function softdock_text_patterns() {
	return array(
		'sd_version'   => '(?:latest\s+)?version',
		'sd_size_mb'   => '(?:file\s+|setup\s+|download\s+)?size',
		'sd_license'   => 'licen[cs]e(?:\s+type)?',
		'sd_developer' => '(?:developer|publisher|author|developed\s+by|created\s+by)',
	);
}

/** Post types that may hold old software posts. */
function softdock_source_types() {
	$types = get_post_types( array( 'public' => true ), 'objects' );
	unset( $types['software'], $types['attachment'] );
	return $types;
}

/** IDs of posts that match the chosen source, oldest first. */
function softdock_source_query( $s, $count = -1, $only_ids = true ) {
	$args = array(
		'post_type'        => $s['type'],
		'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
		'posts_per_page'   => $count,
		'orderby'          => 'ID',
		'order'            => 'ASC',
		'fields'           => $only_ids ? 'ids' : 'all',
		'suppress_filters' => true,
	);
	if ( ! empty( $s['term'] ) ) {
		list( $tax, $term_id ) = array_pad( explode( ':', $s['term'] ), 2, 0 );
		if ( taxonomy_exists( $tax ) ) {
			$args['tax_query'] = array( array( 'taxonomy' => $tax, 'terms' => (int) $term_id, 'include_children' => true ) );
		}
	}
	return get_posts( $args );
}

/** Custom field names used by the source posts, with an example value each. */
function softdock_source_meta_keys( $ids ) {
	global $wpdb;
	if ( ! $ids ) {
		return array();
	}
	$ids  = array_slice( array_map( 'intval', $ids ), 0, 500 );
	$rows = $wpdb->get_results( "SELECT meta_key, MAX(meta_value) AS example FROM {$wpdb->postmeta} WHERE post_id IN (" . implode( ',', $ids ) . ") GROUP BY meta_key ORDER BY meta_key" ); // phpcs:ignore WordPress.DB
	$skip = array( '_edit_lock', '_edit_last', '_thumbnail_id', '_wp_old_slug', '_wp_old_date', '_pingme', '_encloseme', '_wp_page_template', '_wp_trash_meta_status', '_wp_trash_meta_time', '_wp_desired_post_slug', '_softdock_old_path', '_softdock_converted_from', '_softdock_old_terms' );
	$out  = array();
	foreach ( $rows as $r ) {
		if ( in_array( $r->meta_key, $skip, true ) ) {
			continue;
		}
		// ACF keeps a "_name" => "field_abc123" reference next to each value; hide those.
		if ( '_' === $r->meta_key[0] && 0 === strpos( (string) $r->example, 'field_' ) ) {
			continue;
		}
		$example = maybe_unserialize( $r->example );
		$example = is_array( $example ) ? str_replace( "\n", ', ', softdock_value_lines( $example ) ) : (string) $example;
		$out[ $r->meta_key ] = wp_html_excerpt( wp_strip_all_tags( $example ), 40, '…' );
	}
	return $out;
}

/** Terms attached to the source posts, from every taxonomy of that post type. */
function softdock_source_terms( $s, $ids ) {
	if ( ! $ids ) {
		return array();
	}
	$taxes = array_diff( get_object_taxonomies( $s['type'] ), array( 'post_format', 'platform', 'software_cat' ) );
	if ( ! $taxes ) {
		return array();
	}
	$terms = wp_get_object_terms( array_slice( $ids, 0, 2000 ), $taxes, array( 'orderby' => 'count', 'order' => 'DESC' ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	$unique = array();
	foreach ( $terms as $t ) {
		$unique[ $t->term_id ] = $t;
	}
	return array_slice( $unique, 0, 300, true );
}

/** Best guess for a platform from an old term name, or ''. */
function softdock_guess_platform( $name ) {
	$n = strtolower( $name );
	$map = array(
		'android' => '/android|apk/',
		'mac'     => '/\bmac|macos|osx|os x/',
		'linux'   => '/linux|ubuntu|debian/',
		'games'   => '/game/',
		'windows' => '/windows|\bwin\b|\bpc\b/',
	);
	foreach ( $map as $slug => $re ) {
		if ( preg_match( $re, $n ) ) {
			return $slug;
		}
	}
	return '';
}

/** Parses "65.0 MB", "2.69 GB", "800 KB", "1,024" into megabytes. */
function softdock_parse_size( $raw ) {
	$raw = str_replace( ',', '.', preg_replace( '/(\d),(\d{3})\b/', '$1$2', (string) $raw ) );
	if ( ! preg_match( '/([\d.]+)\s*([kmgt]i?b|bytes?)?/i', $raw, $m ) ) {
		return '';
	}
	$n    = (float) $m[1];
	$unit = isset( $m[2] ) ? strtolower( $m[2][0] ) : 'm';
	$mult = array( 'b' => 1 / 1048576, 'k' => 1 / 1024, 'm' => 1, 'g' => 1024, 't' => 1048576 );
	return round( $n * ( isset( $mult[ $unit ] ) ? $mult[ $unit ] : 1 ), 2 );
}

/** Finds "Label: value" in the post text. */
function softdock_find_in_text( $post, $field ) {
	$patterns = softdock_text_patterns();
	if ( ! isset( $patterns[ $field ] ) ) {
		return '';
	}
	$text = preg_replace( '/<\/(p|li|div|h\d|tr|td|th)>|<br\s*\/?>/i', "\n", $post->post_content );
	$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
	if ( preg_match( '/^\W*' . $patterns[ $field ] . '\s*[:\-–]\s*(.+)$/imu', $text, $m ) ) {
		return trim( wp_html_excerpt( $m[1], 120 ) );
	}
	return '';
}

/** First sentence of the post text, skipping "Label: value" lines. */
function softdock_first_sentence( $html ) {
	$text = preg_replace( '/<\/(p|li|div|h\d|tr|td|th)>|<br\s*\/?>/i', "\n", (string) $html );
	$text = html_entity_decode( wp_strip_all_tags( strip_shortcodes( $text ) ), ENT_QUOTES, 'UTF-8' );
	foreach ( preg_split( '/\R/', $text ) as $line ) {
		$line = trim( $line );
		if ( '' === $line || preg_match( '/^[\w\s]{1,30}:\s/u', $line ) ) {
			continue;
		}
		$sentence = preg_split( '/(?<=[.!?])\s/u', $line, 2 )[0];
		return wp_trim_words( rtrim( $sentence, '.' ), 18, '' );
	}
	return '';
}

/** Turns a stored value (string, list, serialized array) into lines of text. */
function softdock_value_lines( $value ) {
	$value = maybe_unserialize( $value );
	if ( is_array( $value ) ) {
		$flat = array();
		array_walk_recursive( $value, function ( $v ) use ( &$flat ) {
			if ( is_scalar( $v ) && '' !== trim( (string) $v ) ) {
				$flat[] = (string) $v;
			}
		} );
		$value = implode( "\n", $flat );
	}
	$value = preg_replace( '/<\/(p|li|div|h\d)>|<br\s*\/?>/i', "\n", (string) $value );
	$lines = array_filter( array_map( 'trim', preg_split( '/\R/', wp_strip_all_tags( $value ) ) ) );
	return implode( "\n", $lines );
}

/** Values one old post would get, without saving anything. */
function softdock_convert_values( $post, $s ) {
	$out = array();
	foreach ( softdock_convert_targets() as $key => $t ) {
		$src = isset( $s['fields'][ $key ] ) ? $s['fields'][ $key ] : '';
		if ( '' === $src ) {
			continue;
		}
		if ( '@text' === $src ) {
			$raw = softdock_find_in_text( $post, $key );
		} elseif ( '@excerpt' === $src ) {
			$raw = $post->post_excerpt ? $post->post_excerpt : softdock_first_sentence( $post->post_content );
		} else {
			$raw = get_post_meta( $post->ID, $src, true );
		}
		switch ( $t[1] ) {
			case 'size':
				$val = softdock_parse_size( is_scalar( $raw ) ? $raw : '' );
				break;
			case 'number':
				$val = is_scalar( $raw ) ? (int) preg_replace( '/\D/', '', (string) $raw ) : 0;
				break;
			case 'lines':
				$val = softdock_value_lines( $raw );
				break;
			case 'url':
				$val = is_scalar( $raw ) ? softdock_clean_field( trim( (string) $raw ), 'url' ) : '';
				break;
			default:
				$val = is_scalar( $raw ) ? trim( wp_strip_all_tags( (string) $raw ) ) : '';
		}
		if ( '' !== $val && null !== $val ) {
			$out[ $key ] = $val;
		}
	}

	$title = $post->post_title;
	// Remove filler words first, so a version that sits before them ("Tool 1.2 Free Download") ends up last.
	if ( ! empty( $s['strip_words'] ) ) {
		$clean = trim( preg_replace( '/\s*[-–|:]?\s*\b(free download|full version|download|latest|for (windows|pc|mac|android))\b\s*/i', ' ', $title ) );
		$title = '' === $clean ? $title : preg_replace( '/\s{2,}/', ' ', $clean );
	}
	if ( ! empty( $s['strip_version'] ) && ! empty( $out['sd_version'] ) ) {
		$v     = preg_quote( $out['sd_version'], '/' );
		$clean = trim( preg_replace( '/\s*[-–(]?\s*v?' . $v . '\s*\)?\s*$/i', '', $title ) );
		$title = '' === $clean ? $title : $clean;
	}
	$out['_title'] = $title;

	$plats = array();
	$cats  = array();
	foreach ( wp_get_object_terms( $post->ID, array_diff( get_object_taxonomies( $post->post_type ), array( 'post_format' ) ) ) as $term ) {
		$m = isset( $s['terms'][ $term->term_id ] ) ? $s['terms'][ $term->term_id ] : array();
		if ( ! empty( $m['platform'] ) ) {
			$plats[] = $m['platform'];
		}
		if ( ! empty( $m['cat'] ) ) {
			$cats[] = '@same' === $m['cat'] ? $term->name : (int) $m['cat'];
		}
	}
	if ( ! $plats && ! empty( $s['default_platform'] ) ) {
		$plats[] = $s['default_platform'];
	}
	$out['_platforms'] = array_values( array_unique( $plats ) );
	$out['_cats']      = array_values( array_unique( $cats, SORT_REGULAR ) );
	return $out;
}

/** Converts one post in place. Returns true when it was converted. */
function softdock_convert_one( $post_id, $s ) {
	$post = get_post( $post_id );
	if ( ! $post || 'software' === $post->post_type ) {
		return false;
	}
	$vals = softdock_convert_values( $post, $s );

	// Remember where it came from, for redirects and Undo.
	$old_path = trim( (string) wp_parse_url( get_permalink( $post ), PHP_URL_PATH ), '/' );
	$old_tax  = array();
	foreach ( array_diff( get_object_taxonomies( $post->post_type ), array( 'post_format' ) ) as $tax ) {
		$old_tax[ $tax ] = wp_get_object_terms( $post_id, $tax, array( 'fields' => 'ids' ) );
	}
	update_post_meta( $post_id, '_softdock_converted_from', $post->post_type );
	update_post_meta( $post_id, '_softdock_old_terms', $old_tax );
	if ( $old_path ) {
		update_post_meta( $post_id, '_softdock_old_path', strtolower( $old_path ) );
	}

	$update = array( 'ID' => $post_id, 'post_type' => 'software' );
	if ( $vals['_title'] !== $post->post_title ) {
		$update['post_title'] = $vals['_title'];
	}
	wp_update_post( wp_slash( $update ) );
	clean_post_cache( $post_id );

	foreach ( $old_tax as $tax => $ids ) {
		wp_set_object_terms( $post_id, array(), $tax );
	}
	if ( $vals['_platforms'] ) {
		wp_set_object_terms( $post_id, $vals['_platforms'], 'platform' );
	}
	$cat_ids = array();
	foreach ( $vals['_cats'] as $c ) {
		if ( is_int( $c ) ) {
			$cat_ids[] = $c;
			continue;
		}
		$found = term_exists( $c, 'software_cat' );
		if ( ! $found ) {
			$found = wp_insert_term( $c, 'software_cat' );
		}
		if ( ! is_wp_error( $found ) && $found ) {
			$cat_ids[] = (int) $found['term_id'];
		}
	}
	if ( $cat_ids ) {
		wp_set_object_terms( $post_id, $cat_ids, 'software_cat' );
	}

	foreach ( softdock_convert_targets() as $key => $t ) {
		if ( isset( $vals[ $key ] ) ) {
			update_post_meta( $post_id, $key, $vals[ $key ] );
		}
	}

	if ( ! empty( $s['screenshots'] ) && '' === (string) get_post_meta( $post_id, 'sd_screenshots', true ) ) {
		$thumb = (int) get_post_thumbnail_id( $post_id );
		$imgs  = get_children( array( 'post_parent' => $post_id, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'orderby' => 'menu_order ID', 'order' => 'ASC', 'fields' => 'ids' ) );
		$imgs  = array_values( array_diff( array_map( 'intval', $imgs ), array( $thumb ) ) );
		if ( $imgs ) {
			update_post_meta( $post_id, 'sd_screenshots', implode( ',', array_slice( $imgs, 0, 12 ) ) );
		}
	}

	// Fill in missing counters so the program appears in every list.
	foreach ( array( 'sd_downloads', 'sd_rating', 'sd_rating_count', 'sd_size_mb' ) as $key ) {
		if ( '' === (string) get_post_meta( $post_id, $key, true ) ) {
			update_post_meta( $post_id, $key, 0 );
		}
	}
	return true;
}

/** Puts a converted program back the way it was. */
function softdock_unconvert_one( $post_id ) {
	$from = get_post_meta( $post_id, '_softdock_converted_from', true );
	if ( ! $from || ! post_type_exists( $from ) ) {
		return false;
	}
	wp_update_post( array( 'ID' => $post_id, 'post_type' => $from ) );
	clean_post_cache( $post_id );
	wp_set_object_terms( $post_id, array(), 'platform' );
	wp_set_object_terms( $post_id, array(), 'software_cat' );
	foreach ( (array) get_post_meta( $post_id, '_softdock_old_terms', true ) as $tax => $ids ) {
		if ( taxonomy_exists( $tax ) ) {
			wp_set_object_terms( $post_id, array_map( 'intval', (array) $ids ), $tax );
		}
	}
	delete_post_meta( $post_id, '_softdock_converted_from' );
	delete_post_meta( $post_id, '_softdock_old_terms' );
	delete_post_meta( $post_id, '_softdock_old_path' );
	return true;
}

function softdock_converted_ids() {
	return get_posts( array(
		'post_type'        => 'software',
		'post_status'      => 'any',
		'posts_per_page'   => -1,
		'fields'           => 'ids',
		'meta_key'         => '_softdock_converted_from',
		'suppress_filters' => true,
	) );
}

/** Reads the settings form. */
function softdock_convert_settings_from_request() {
	// phpcs:disable WordPress.Security.NonceVerification -- checked by the callers.
	$r = wp_unslash( $_POST );
	$s = array(
		'type'             => isset( $r['source_type'] ) ? sanitize_key( $r['source_type'] ) : 'post',
		'term'             => isset( $r['source_term'] ) ? sanitize_text_field( $r['source_term'] ) : '',
		'fields'           => array(),
		'terms'            => array(),
		'default_platform' => isset( $r['default_platform'] ) ? sanitize_title( $r['default_platform'] ) : '',
		'strip_version'    => ! empty( $r['strip_version'] ),
		'strip_words'      => ! empty( $r['strip_words'] ),
		'screenshots'      => ! empty( $r['screenshots'] ),
	);
	// phpcs:enable
	if ( ! isset( softdock_source_types()[ $s['type'] ] ) ) {
		$s['type'] = 'post';
	}
	foreach ( array_keys( softdock_convert_targets() ) as $key ) {
		$s['fields'][ $key ] = isset( $r['map'][ $key ] ) ? sanitize_text_field( $r['map'][ $key ] ) : '';
	}
	if ( isset( $r['term_map'] ) && is_array( $r['term_map'] ) ) {
		foreach ( $r['term_map'] as $tid => $m ) {
			$s['terms'][ (int) $tid ] = array(
				'platform' => isset( $m['platform'] ) ? sanitize_title( $m['platform'] ) : '',
				'cat'      => isset( $m['cat'] ) ? ( '@same' === $m['cat'] ? '@same' : absint( $m['cat'] ) ) : '',
			);
		}
	}
	return $s;
}

function softdock_convert_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$saved = get_option( 'softdock_convert_settings', array() );
	$s     = wp_parse_args( $saved, array( 'type' => 'post', 'term' => '', 'fields' => array(), 'terms' => array(), 'default_platform' => '', 'strip_version' => true, 'strip_words' => true, 'screenshots' => true ) );

	// Changing the source reloads the page with the new choice.
	// phpcs:disable WordPress.Security.NonceVerification
	if ( isset( $_GET['source_type'] ) && isset( softdock_source_types()[ sanitize_key( $_GET['source_type'] ) ] ) ) {
		$s['type'] = sanitize_key( $_GET['source_type'] );
		$s['term'] = isset( $_GET['source_term'] ) ? sanitize_text_field( wp_unslash( $_GET['source_term'] ) ) : '';
	}
	// phpcs:enable
	$ids       = softdock_source_query( $s );
	$keys      = softdock_source_meta_keys( $ids );
	$terms     = softdock_source_terms( $s, $ids );
	$platforms = softdock_platforms();
	$cats      = get_terms( array( 'taxonomy' => 'software_cat', 'hide_empty' => false ) );
	$converted = softdock_converted_ids();
	$pattern   = softdock_text_patterns();
	?>
	<div class="wrap" id="softdock-convert">
		<h1><?php esc_html_e( 'Convert to programs', 'softdock' ); ?></h1>
		<p style="max-width:780px"><?php esc_html_e( 'Turns posts from your old site into Softdock programs. First bring the old posts in with Tools → Import → WordPress, using the export file from your old site. Then choose which posts to convert, match their fields and categories, check the preview and convert. Comments, featured images and attachments stay with each post, and old URLs redirect to the new program pages.', 'softdock' ); ?></p>
		<div class="notice notice-warning inline"><p><?php esc_html_e( 'Make a backup of your database before converting. You can undo a conversion below, but a backup is the safest way back.', 'softdock' ); ?></p></div>

		<?php if ( $converted ) : ?>
			<div class="card" style="max-width:780px">
				<h2><?php esc_html_e( 'Converted so far', 'softdock' ); ?></h2>
				<?php /* translators: %d: number of programs */ ?>
				<p><?php echo esc_html( sprintf( _n( '%d post has been converted to a program.', '%d posts have been converted to programs.', count( $converted ), 'softdock' ), count( $converted ) ) ); ?></p>
				<p><button type="button" class="button" id="sd-undo"><?php esc_html_e( 'Undo all conversions', 'softdock' ); ?></button> <span id="sd-undo-confirm" hidden><?php esc_html_e( 'This turns every converted program back into its old post type with its old categories. Click again to confirm.', 'softdock' ); ?></span></p>
			</div>
		<?php endif; ?>

		<form id="sd-convert-form" method="post">
			<?php wp_nonce_field( 'softdock_convert', 'sd_nonce' ); ?>
			<h2><?php esc_html_e( '1. Which posts', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr><th scope="row"><label for="source_type"><?php esc_html_e( 'Post type', 'softdock' ); ?></label></th><td>
					<select id="source_type" name="source_type">
						<?php foreach ( softdock_source_types() as $type ) : ?>
							<option value="<?php echo esc_attr( $type->name ); ?>" <?php selected( $s['type'], $type->name ); ?>><?php echo esc_html( $type->labels->name . ' (' . $type->name . ')' ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
				<tr><th scope="row"><label for="source_term"><?php esc_html_e( 'Only posts in', 'softdock' ); ?></label></th><td>
					<select id="source_term" name="source_term">
						<option value=""><?php esc_html_e( 'All posts of this type', 'softdock' ); ?></option>
						<?php foreach ( array_diff( get_object_taxonomies( $s['type'] ), array( 'post_format' ) ) as $tax ) : ?>
							<?php $all = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => true, 'number' => 300 ) ); ?>
							<?php if ( is_wp_error( $all ) || ! $all ) { continue; } ?>
							<optgroup label="<?php echo esc_attr( get_taxonomy( $tax )->labels->name ); ?>">
								<?php foreach ( $all as $t ) : ?>
									<?php $v = $tax . ':' . $t->term_id; ?>
									<option value="<?php echo esc_attr( $v ); ?>" <?php selected( $s['term'], $v ); ?>><?php echo esc_html( $t->name . ' (' . $t->count . ')' ); ?></option>
								<?php endforeach; ?>
							</optgroup>
						<?php endforeach; ?>
					</select>
					<?php /* translators: %d: number of posts */ ?>
					<p class="description"><strong><?php echo esc_html( sprintf( _n( '%d post matches.', '%d posts match.', count( $ids ), 'softdock' ), count( $ids ) ) ); ?></strong> <?php esc_html_e( 'Pages already converted are not counted again.', 'softdock' ); ?></p>
				</td></tr>
			</tbody></table>

			<?php if ( $ids ) : ?>
			<h2><?php esc_html_e( '2. Match the fields', 'softdock' ); ?></h2>
			<p><?php esc_html_e( 'For each program detail, pick the custom field from your old site that holds it, or let Softdock find it in the post text (for lines such as "Version: 3.0.21" or "File Size: 65 MB").', 'softdock' ); ?></p>
			<table class="form-table" role="presentation"><tbody>
				<?php foreach ( softdock_convert_targets() as $key => $t ) : ?>
					<?php $cur = isset( $s['fields'][ $key ] ) ? $s['fields'][ $key ] : ( isset( $pattern[ $key ] ) ? '@text' : ( 'sd_tagline' === $key ? '@excerpt' : '' ) ); ?>
					<tr><th scope="row"><label for="map-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $t[0] ); ?></label></th><td>
						<select id="map-<?php echo esc_attr( $key ); ?>" name="map[<?php echo esc_attr( $key ); ?>]" class="sd-map">
							<option value=""><?php esc_html_e( '— Leave empty —', 'softdock' ); ?></option>
							<?php if ( isset( $pattern[ $key ] ) ) : ?><option value="@text" <?php selected( $cur, '@text' ); ?>><?php esc_html_e( 'Find in post text', 'softdock' ); ?></option><?php endif; ?>
							<?php if ( 'sd_tagline' === $key ) : ?><option value="@excerpt" <?php selected( $cur, '@excerpt' ); ?>><?php esc_html_e( 'Post excerpt (or start of the text)', 'softdock' ); ?></option><?php endif; ?>
							<?php if ( $keys ) : ?>
								<optgroup label="<?php esc_attr_e( 'Custom fields on your old posts', 'softdock' ); ?>">
									<?php foreach ( $keys as $mk => $example ) : ?>
										<option value="<?php echo esc_attr( $mk ); ?>" <?php selected( $cur, $mk ); ?>><?php echo esc_html( $mk . ( '' !== $example ? ' — e.g. ' . $example : '' ) ); ?></option>
									<?php endforeach; ?>
								</optgroup>
							<?php endif; ?>
						</select>
					</td></tr>
				<?php endforeach; ?>
				<tr><th scope="row"><?php esc_html_e( 'Title', 'softdock' ); ?></th><td>
					<label><input type="checkbox" name="strip_version" value="1" <?php checked( ! empty( $s['strip_version'] ) ); ?>> <?php esc_html_e( 'Remove the version number from the end of titles (it shows separately)', 'softdock' ); ?></label><br>
					<label><input type="checkbox" name="strip_words" value="1" <?php checked( ! empty( $s['strip_words'] ) ); ?>> <?php esc_html_e( 'Remove words like "Free Download", "Full Version" and "for Windows" from titles', 'softdock' ); ?></label>
				</td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Screenshots', 'softdock' ); ?></th><td>
					<label><input type="checkbox" name="screenshots" value="1" <?php checked( ! empty( $s['screenshots'] ) ); ?>> <?php esc_html_e( 'Use images attached to each post as its screenshots', 'softdock' ); ?></label>
				</td></tr>
			</tbody></table>

			<h2><?php esc_html_e( '3. Match categories and tags', 'softdock' ); ?></h2>
			<p><?php esc_html_e( 'Choose the platform tab and the program category for each of your old categories. Softdock guessed the platforms from the names; check them.', 'softdock' ); ?></p>
			<table class="widefat striped" style="max-width:900px">
				<thead><tr><th><?php esc_html_e( 'Old category or tag', 'softdock' ); ?></th><th><?php esc_html_e( 'Posts', 'softdock' ); ?></th><th><?php esc_html_e( 'Platform', 'softdock' ); ?></th><th><?php esc_html_e( 'Program category', 'softdock' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $terms as $t ) : ?>
					<?php
					$guess = softdock_guess_platform( $t->name );
					$m     = isset( $s['terms'][ $t->term_id ] ) ? $s['terms'][ $t->term_id ] : array(
						'platform' => $guess,
						'cat'      => ( 'post_tag' === $t->taxonomy || $guess || 'uncategorized' === $t->slug ) ? '' : '@same',
					);
					?>
					<tr>
						<td><?php echo esc_html( $t->name ); ?> <span class="description">(<?php echo esc_html( get_taxonomy( $t->taxonomy )->labels->singular_name ); ?>)</span></td>
						<td><?php echo (int) $t->count; ?></td>
						<td><select name="term_map[<?php echo (int) $t->term_id; ?>][platform]" aria-label="<?php echo esc_attr( $t->name ); ?>: platform">
							<option value=""><?php esc_html_e( '—', 'softdock' ); ?></option>
							<?php foreach ( $platforms as $p ) : ?><option value="<?php echo esc_attr( $p->slug ); ?>" <?php selected( $m['platform'], $p->slug ); ?>><?php echo esc_html( $p->name ); ?></option><?php endforeach; ?>
						</select></td>
						<td><select name="term_map[<?php echo (int) $t->term_id; ?>][cat]" aria-label="<?php echo esc_attr( $t->name ); ?>: category">
							<option value=""><?php esc_html_e( '—', 'softdock' ); ?></option>
							<?php /* translators: %s: category name */ ?>
							<option value="@same" <?php selected( $m['cat'], '@same' ); ?>><?php echo esc_html( sprintf( __( 'Same name: %s', 'softdock' ), $t->name ) ); ?></option>
							<?php if ( ! is_wp_error( $cats ) ) : ?>
								<?php foreach ( $cats as $c ) : ?><option value="<?php echo (int) $c->term_id; ?>" <?php selected( (string) $m['cat'], (string) $c->term_id ); ?>><?php echo esc_html( $c->name ); ?></option><?php endforeach; ?>
							<?php endif; ?>
						</select></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<table class="form-table" role="presentation"><tbody>
				<tr><th scope="row"><label for="default_platform"><?php esc_html_e( 'Posts with no platform', 'softdock' ); ?></label></th><td>
					<select id="default_platform" name="default_platform">
						<option value=""><?php esc_html_e( 'Leave without a platform', 'softdock' ); ?></option>
						<?php foreach ( $platforms as $p ) : ?><option value="<?php echo esc_attr( $p->slug ); ?>" <?php selected( $s['default_platform'], $p->slug ); ?>><?php echo esc_html( $p->name ); ?></option><?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'Programs without a platform do not appear in the platform tabs or on the home page.', 'softdock' ); ?></p>
				</td></tr>
			</tbody></table>

			<h2><?php esc_html_e( '4. Preview and convert', 'softdock' ); ?></h2>
			<p>
				<button type="button" class="button" id="sd-preview"><?php esc_html_e( 'Preview first 5 posts', 'softdock' ); ?></button>
				<button type="button" class="button button-primary" id="sd-run" disabled><?php /* translators: %d: number of posts */ echo esc_html( sprintf( __( 'Convert %d posts', 'softdock' ), count( $ids ) ) ); ?></button>
			</p>
			<p class="description"><?php esc_html_e( 'Preview first. Converting is enabled after a preview.', 'softdock' ); ?></p>
			<div id="sd-preview-out"></div>
			<div id="sd-progress" hidden style="max-width:780px">
				<div style="height:12px;background:#dcdcde;border-radius:6px;overflow:hidden"><div id="sd-bar" style="height:100%;width:0;background:#2271b1;transition:width .2s"></div></div>
				<p id="sd-status" role="status"></p>
			</div>
			<?php endif; ?>
		</form>
	</div>
	<?php
}

/** Checks the nonce and capability for the AJAX steps. */
function softdock_convert_guard() {
	if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'softdock_convert', 'sd_nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Your session expired. Reload the page and try again.', 'softdock' ) ), 403 );
	}
}

add_action( 'wp_ajax_softdock_convert_preview', function () {
	softdock_convert_guard();
	$s = softdock_convert_settings_from_request();
	update_option( 'softdock_convert_settings', $s, false );
	$rows = array();
	foreach ( softdock_source_query( $s, 5, false ) as $post ) {
		$v      = softdock_convert_values( $post, $s );
		$rows[] = array(
			'old'       => $post->post_title,
			'title'     => $v['_title'],
			'version'   => isset( $v['sd_version'] ) ? $v['sd_version'] : '',
			'size'      => isset( $v['sd_size_mb'] ) ? implode( ' ', softdock_size_label( $v['sd_size_mb'] ) ) : '',
			'license'   => isset( $v['sd_license'] ) ? $v['sd_license'] : '',
			'developer' => isset( $v['sd_developer'] ) ? $v['sd_developer'] : '',
			'tagline'   => isset( $v['sd_tagline'] ) ? $v['sd_tagline'] : '',
			'link'      => isset( $v['sd_official_url'] ) ? $v['sd_official_url'] : '',
			'platforms' => implode( ', ', $v['_platforms'] ),
			'cats'      => implode( ', ', array_map( function ( $c ) {
				if ( is_int( $c ) ) {
					$t = get_term( $c, 'software_cat' );
					return $t && ! is_wp_error( $t ) ? $t->name : '';
				}
				return $c;
			}, $v['_cats'] ) ),
		);
	}
	wp_send_json_success( array( 'rows' => $rows, 'total' => count( softdock_source_query( $s ) ) ) );
} );

add_action( 'wp_ajax_softdock_convert_batch', function () {
	softdock_convert_guard();
	$s = get_option( 'softdock_convert_settings' );
	if ( ! $s ) {
		wp_send_json_error( array( 'message' => __( 'Run the preview first.', 'softdock' ) ), 400 );
	}
	wp_raise_memory_limit( 'admin' );
	wp_defer_term_counting( true );
	$done   = 0;
	$failed = array();
	foreach ( softdock_source_query( $s, SOFTDOCK_CONVERT_BATCH ) as $id ) {
		try {
			if ( softdock_convert_one( $id, $s ) ) {
				++$done;
			} else {
				$failed[] = $id;
			}
		} catch ( Throwable $e ) {
			$failed[] = $id;
		}
	}
	wp_defer_term_counting( false );
	softdock_bump_core_cache();
	wp_send_json_success( array(
		'done'      => $done,
		'failed'    => $failed,
		'remaining' => count( softdock_source_query( $s ) ),
	) );
} );

add_action( 'wp_ajax_softdock_unconvert_batch', function () {
	softdock_convert_guard();
	$n = 0;
	foreach ( array_slice( softdock_converted_ids(), 0, SOFTDOCK_CONVERT_BATCH * 2 ) as $id ) {
		if ( softdock_unconvert_one( $id ) ) {
			++$n;
		}
	}
	softdock_bump_core_cache();
	wp_send_json_success( array( 'done' => $n, 'remaining' => count( softdock_converted_ids() ) ) );
} );

/** Size as [number, unit] for the preview (the theme has its own copy for display). */
function softdock_size_label( $mb ) {
	$mb = (float) $mb;
	if ( $mb <= 0 ) {
		return array( '', '' );
	}
	return $mb >= 1024 ? array( round( $mb / 1024, 2 ), 'GB' ) : array( round( $mb, 1 ), 'MB' );
}

/** Tells the theme its cached lists are out of date. */
function softdock_bump_core_cache() {
	wp_cache_set( 'last_changed', microtime(), 'softdock' );
}

/**
 * Old URLs of converted posts send visitors (and search engines) to the new program page
 * with a permanent redirect, so existing links and rankings carry over.
 */
add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	global $wpdb;
	$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
	$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( $home && '/' !== $home && 0 === strpos( $path, $home ) ) {
		$path = substr( $path, strlen( $home ) );
	}
	$path = strtolower( trim( rawurldecode( $path ), '/' ) );
	if ( '' === $path ) {
		return;
	}
	$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_softdock_old_path' AND meta_value = %s LIMIT 1", $path ) );
	if ( $id && 'publish' === get_post_status( $id ) ) {
		wp_safe_redirect( get_permalink( $id ), 301, 'Softdock' );
		exit;
	}
}, 5 );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'tools_page_softdock-convert' === $hook ) {
		wp_enqueue_script( 'softdock-convert', SOFTDOCK_CORE_URL . 'assets/convert.js', array(), SOFTDOCK_CORE_VERSION, true );
		wp_localize_script( 'softdock-convert', 'sdConvert', array(
			'ajax' => admin_url( 'admin-ajax.php' ),
			'page' => admin_url( 'tools.php?page=softdock-convert' ),
			'i18n' => array(
				'old'       => __( 'Old title', 'softdock' ),
				'title'     => __( 'New title', 'softdock' ),
				'version'   => __( 'Version', 'softdock' ),
				'size'      => __( 'Size', 'softdock' ),
				'license'   => __( 'License', 'softdock' ),
				'developer' => __( 'Developer', 'softdock' ),
				'tagline'   => __( 'Tagline', 'softdock' ),
				'link'      => __( 'Download page', 'softdock' ),
				'platforms' => __( 'Platforms', 'softdock' ),
				'cats'      => __( 'Category', 'softdock' ),
				'empty'     => __( 'No posts match. Choose another post type or category.', 'softdock' ),
				/* translators: %d: number of posts */
				'convertN'  => __( 'Convert %d posts', 'softdock' ),
				/* translators: 1: converted so far, 2: total */
				'progress'  => __( 'Converted %1$d of %2$d…', 'softdock' ),
				/* translators: %d: number of posts */
				'finished'  => __( 'Done. %d posts are now programs.', 'softdock' ),
				/* translators: %s: list of post IDs */
				'failedIds' => __( 'These post IDs could not be converted: %s', 'softdock' ),
				'error'     => __( 'The server stopped responding. Reload this page and click Convert again; it continues where it stopped.', 'softdock' ),
				/* translators: %d: number of programs */
				'undone'    => __( 'Undone. %d programs are back to their old post type.', 'softdock' ),
				'viewSite'  => __( 'View site', 'softdock' ),
			),
			'home' => home_url( '/' ),
		) );
	}
} );
