<?php
/**
 * Customisation pages under Software: Homepage, Header, Search bar, Right sidebar, Footer
 * and Ratings. All options live in one stored setting (softdock_home); each page saves only
 * its own options. The header and footer menus are edited in Appearance → Menus.
 */

defined( 'ABSPATH' ) || exit;

function softdock_home_defaults() {
	return array(
		// Homepage.
		'latest_show'          => 1,
		'latest_title'         => __( 'Latest programs', 'softdock' ),
		'latest_count'         => 6,
		'section_order'        => 'latest', // latest | downloads | views | rating.
		'section_count'        => 6,
		'show_counts'          => 0, // "26 programs" next to each section heading.
		'sections'             => array(), // term_id => [ show, title, order ].
		// Right sidebar.
		'popular_show'         => 1,
		'popular_title'        => __( 'Popular downloads', 'softdock' ),
		'popular_count'        => 8,
		'popular_by'           => 'downloads', // downloads | views | rating | latest.
		'popular_pages'        => 'home', // home | all (also on list pages).
		'popular_cat'          => 0, // Only programs in this category (0 = all).
		'cats_show'            => 1,
		'cats_title'           => __( 'Categories', 'softdock' ),
		'cats_count'           => 10,
		'banner_show'          => 0,
		'banner_image'         => 0,
		'banner_link'          => '',
		'banner_newtab'        => 1,
		'order_popular'        => 1,
		'order_cats'           => 2,
		'order_banner'         => 3,
		// Your own content blocks (up to three).
		'custom1_show'         => 0,
		'custom1_title'        => '',
		'custom1_body'         => '',
		'order_custom1'        => 4,
		'custom2_show'         => 0,
		'custom2_title'        => '',
		'custom2_body'         => '',
		'order_custom2'        => 5,
		'custom3_show'         => 0,
		'custom3_title'        => '',
		'custom3_body'         => '',
		'order_custom3'        => 6,
		// Header.
		'show_cats'            => 1,
		'cats_label'           => __( 'Categories', 'softdock' ),
		'show_theme_btn'       => 1,
		'header_sticky'        => 1,
		'logo_text_show'       => 1,
		// Search bar.
		'show_search'          => 1,
		'search_mode'          => 'icon', // icon (opens on click) | bar (always visible).
		'search_placeholder'   => __( 'Search software…', 'softdock' ),
		'search_suggest'       => 1,
		'search_suggest_count' => 8,
		'search_suggest_terms' => 1,
		// Footer.
		'footer_show'          => 1,
		'footer_text'          => '', // Empty: the site tagline.
		'footer_copyright'     => '© {year} {site}',
		'footer_menu_show'     => 1,
		// Ratings.
		'ratings_show'         => 1,
		'ratings_vote'         => 1,
		'ratings_in_lists'     => 1,
		'ratings_count'        => 1,
	);
}

/** One customisation setting, with its default. */
function softdock_home( $key ) {
	$saved = get_option( 'softdock_home', array() );
	$def   = softdock_home_defaults();
	if ( is_array( $saved ) && array_key_exists( $key, $saved ) ) {
		$v = $saved[ $key ];
		if ( in_array( $key, array( 'latest_title', 'popular_title', 'cats_title', 'cats_label', 'search_placeholder' ), true ) && '' === trim( (string) $v ) ) {
			return $def[ $key ];
		}
		return $v;
	}
	return isset( $def[ $key ] ) ? $def[ $key ] : '';
}

/** Platform sections in the order chosen on the Homepage page, with their settings. */
function softdock_home_sections() {
	$saved = softdock_home( 'sections' );
	$saved = is_array( $saved ) ? $saved : array();
	$out   = array();
	$i     = 0;
	foreach ( softdock_platforms() as $t ) {
		$s     = isset( $saved[ $t->term_id ] ) ? $saved[ $t->term_id ] : array();
		$out[] = array(
			'term'  => $t,
			'show'  => isset( $s['show'] ) ? (int) $s['show'] : 1,
			'title' => isset( $s['title'] ) && '' !== trim( $s['title'] ) ? $s['title'] : $t->name,
			'order' => isset( $s['order'] ) ? (int) $s['order'] : ++$i * 10,
		);
	}
	usort( $out, function ( $a, $b ) {
		return $a['order'] - $b['order'];
	} );
	return $out;
}

/** Programs ordered for a homepage list: latest, downloads, views or rating. */
function softdock_home_query( $by, $count, $platform = '', $cat = 0 ) {
	$args = array(
		'post_type'           => 'software',
		'posts_per_page'      => max( 1, (int) $count ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);
	$keys = array( 'downloads' => 'sd_downloads', 'views' => 'sd_views', 'rating' => 'sd_rating' );
	if ( isset( $keys[ $by ] ) && function_exists( 'softdock_meta_order_clause' ) ) {
		$args['meta_query'] = softdock_meta_order_clause( $keys[ $by ] );
		$args['orderby']    = array( 'has' => 'DESC', 'date' => 'DESC' );
	} else {
		$args['orderby'] = array( 'date' => 'DESC', 'ID' => 'DESC' );
	}
	if ( $platform ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'platform', 'field' => 'slug', 'terms' => $platform ) );
	}
	if ( $cat ) {
		$args['tax_query']   = isset( $args['tax_query'] ) ? $args['tax_query'] : array();
		$args['tax_query'][] = array( 'taxonomy' => 'software_cat', 'field' => 'term_id', 'terms' => (int) $cat );
	}
	return new WP_Query( $args );
}

/** How each option is cleaned when saved. */
function softdock_home_types() {
	return array(
		'bool' => array( 'latest_show', 'show_counts', 'popular_show', 'cats_show', 'banner_show', 'banner_newtab', 'show_search', 'show_cats', 'show_theme_btn', 'header_sticky', 'logo_text_show', 'search_suggest', 'search_suggest_terms', 'footer_show', 'footer_menu_show', 'ratings_show', 'ratings_vote', 'ratings_in_lists', 'ratings_count', 'custom1_show', 'custom2_show', 'custom3_show' ),
		'text' => array( 'latest_title', 'popular_title', 'cats_title', 'cats_label', 'search_placeholder', 'footer_copyright', 'custom1_title', 'custom2_title', 'custom3_title' ),
		'post' => array( 'custom1_body', 'custom2_body', 'custom3_body' ),
		'html' => array( 'footer_text' ),
		'int'  => array(
			'latest_count'         => array( 1, 30 ),
			'section_count'        => array( 1, 30 ),
			'popular_count'        => array( 1, 20 ),
			'cats_count'           => array( 1, 50 ),
			'order_popular'        => array( 1, 6 ),
			'order_cats'           => array( 1, 6 ),
			'order_banner'         => array( 1, 6 ),
			'order_custom1'        => array( 1, 6 ),
			'order_custom2'        => array( 1, 6 ),
			'order_custom3'        => array( 1, 6 ),
			'search_suggest_count' => array( 3, 15 ),
			'popular_cat'          => array( 0, PHP_INT_MAX ),
			'banner_image'         => array( 0, PHP_INT_MAX ),
		),
		'pick' => array(
			'section_order' => array( 'latest', 'downloads', 'views', 'rating' ),
			'popular_by'    => array( 'downloads', 'views', 'rating', 'latest' ),
			'popular_pages' => array( 'home', 'all' ),
			'search_mode'   => array( 'icon', 'bar' ),
		),
		'url'  => array( 'banner_link' ),
	);
}

add_action( 'admin_init', function () {
	register_setting( 'softdock_home', 'softdock_home', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in    = is_array( $in ) ? $in : array();
			$saved = get_option( 'softdock_home', array() );
			$out   = array_merge( softdock_home_defaults(), is_array( $saved ) ? $saved : array() );
			$types = softdock_home_types();
			// Only the options sent by the page being saved change; everything else is kept.
			foreach ( $types['bool'] as $k ) {
				if ( array_key_exists( $k, $in ) ) {
					$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
				}
			}
			foreach ( $types['text'] as $k ) {
				if ( array_key_exists( $k, $in ) ) {
					$out[ $k ] = sanitize_text_field( $in[ $k ] );
				}
			}
			foreach ( $types['html'] as $k ) {
				if ( array_key_exists( $k, $in ) ) {
					$out[ $k ] = wp_kses( $in[ $k ], array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ), 'strong' => array(), 'em' => array(), 'br' => array() ) );
				}
			}
			foreach ( $types['post'] as $k ) {
				if ( array_key_exists( $k, $in ) ) {
					// Admins may paste ad or embed code (scripts); others get the usual safe HTML.
					$out[ $k ] = current_user_can( 'unfiltered_html' ) ? (string) $in[ $k ] : wp_kses_post( $in[ $k ] );
				}
			}
			foreach ( $types['int'] as $k => $range ) {
				if ( array_key_exists( $k, $in ) ) {
					$out[ $k ] = min( $range[1], max( $range[0], absint( $in[ $k ] ) ) );
				}
			}
			foreach ( $types['pick'] as $k => $allowed ) {
				if ( isset( $in[ $k ] ) && in_array( $in[ $k ], $allowed, true ) ) {
					$out[ $k ] = $in[ $k ];
				}
			}
			foreach ( $types['url'] as $k ) {
				if ( array_key_exists( $k, $in ) ) {
					$out[ $k ] = esc_url_raw( trim( (string) $in[ $k ] ), array( 'http', 'https' ) );
				}
			}
			if ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
				$secs = array();
				foreach ( $in['sections'] as $tid => $s ) {
					$secs[ absint( $tid ) ] = array(
						'show'  => empty( $s['show'] ) ? 0 : 1,
						'title' => isset( $s['title'] ) ? sanitize_text_field( $s['title'] ) : '',
						'order' => isset( $s['order'] ) ? (int) $s['order'] : 0,
					);
				}
				$out['sections'] = $secs;
			}
			return $out;
		},
	) );
} );

/** The customisation pages: slug => [ menu title, render callback ]. */
function softdock_custom_pages() {
	return array(
		'softdock-home'    => array( __( 'Homepage', 'softdock' ), 'softdock_render_home_page' ),
		'softdock-header'  => array( __( 'Header', 'softdock' ), 'softdock_render_header_page' ),
		'softdock-search'  => array( __( 'Search bar', 'softdock' ), 'softdock_render_search_page' ),
		'softdock-sidebar' => array( __( 'Right sidebar', 'softdock' ), 'softdock_render_sidebar_page' ),
		'softdock-footer'  => array( __( 'Footer', 'softdock' ), 'softdock_render_footer_page' ),
		'softdock-ratings' => array( __( 'Ratings', 'softdock' ), 'softdock_render_ratings_page' ),
	);
}

add_action( 'admin_menu', function () {
	foreach ( softdock_custom_pages() as $slug => $p ) {
		add_submenu_page( 'edit.php?post_type=software', $p[0], $p[0], 'manage_options', $slug, $p[1] );
	}
}, 11 );

/**
 * Software menu order: content first, then the look of the site, then downloads and tools:
 * … Categories, Homepage, Header, Search bar, Right sidebar, Footer, Download links,
 * Download counts, Ratings, Import (CSV).
 */
add_action( 'admin_menu', function () {
	global $submenu;
	$key = 'edit.php?post_type=software';
	if ( empty( $submenu[ $key ] ) ) {
		return;
	}
	$want = array( 'softdock-home', 'softdock-header', 'softdock-search', 'softdock-sidebar', 'softdock-footer', 'softdock-urls', 'softdock-links', 'softdock-settings', 'softdock-ratings', 'softdock-csv' );
	$head = array();
	$tail = array();
	foreach ( $submenu[ $key ] as $item ) {
		$pos = array_search( $item[2], $want, true );
		if ( false === $pos ) {
			$head[] = $item;
		} else {
			$tail[ $pos ] = $item;
		}
	}
	ksort( $tail );
	$submenu[ $key ] = array_merge( $head, array_values( $tail ) ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
}, 999 );

/* ---------- Shared form pieces ---------- */

/** Tabs linking all customisation pages, shown at the top of each one. */
function softdock_cp_tabs() {
	$pages = array();
	foreach ( softdock_custom_pages() as $slug => $p ) {
		$pages[ $slug ] = $p[0];
	}
	$pages['softdock-urls']     = __( 'Page URLs', 'softdock' );
	$pages['softdock-links']    = __( 'Download links', 'softdock' );
	$pages['softdock-settings'] = __( 'Download counts', 'softdock' );
	$current = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	echo '<nav class="sd-cp-tabs" aria-label="' . esc_attr__( 'Customise', 'softdock' ) . '">';
	foreach ( $pages as $slug => $label ) {
		echo '<a class="' . ( $slug === $current ? 'on' : '' ) . '" href="' . esc_url( admin_url( 'edit.php?post_type=software&page=' . $slug ) ) . '">' . esc_html( $label ) . '</a>';
	}
	echo '</nav>';
}
function softdock_cp_open( $title, $intro ) {
	echo '<div class="wrap sd-cp"><h1>' . esc_html( $title ) . '</h1>';
	softdock_cp_tabs();
	echo '<p>' . esc_html( $intro ) . ' <a href="' . esc_url( home_url( '/' ) ) . '" target="_blank">' . esc_html__( 'View site ↗', 'softdock' ) . '</a></p>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'softdock_home' );
}
function softdock_cp_close() {
	submit_button();
	echo '</form></div>';
}
function softdock_cp_check( $key, $label ) {
	echo '<input type="hidden" name="softdock_home[' . esc_attr( $key ) . ']" value="0">';
	echo '<label><input type="checkbox" name="softdock_home[' . esc_attr( $key ) . ']" value="1"' . checked( 1, (int) softdock_home( $key ), false ) . '> ' . esc_html( $label ) . '</label>';
}
function softdock_cp_text( $key, $label, $class = 'regular-text', $placeholder = '' ) {
	echo '<p><label>' . esc_html( $label ) . '<br><input type="text" class="' . esc_attr( $class ) . '" name="softdock_home[' . esc_attr( $key ) . ']" value="' . esc_attr( softdock_home( $key ) ) . '" placeholder="' . esc_attr( $placeholder ) . '"></label></p>';
}
function softdock_cp_number( $key, $label, $min, $max ) {
	echo '<p><label>' . esc_html( $label ) . ' <input type="number" min="' . (int) $min . '" max="' . (int) $max . '" class="small-text" name="softdock_home[' . esc_attr( $key ) . ']" value="' . (int) softdock_home( $key ) . '"></label></p>';
}
function softdock_cp_select( $key, $options ) {
	echo '<select name="softdock_home[' . esc_attr( $key ) . ']">';
	foreach ( $options as $k => $label ) {
		echo '<option value="' . esc_attr( $k ) . '"' . selected( (string) softdock_home( $key ), (string) $k, false ) . '>' . esc_html( $label ) . '</option>';
	}
	echo '</select>';
}
function softdock_cp_position( $key ) {
	echo '<label>' . esc_html__( 'Position', 'softdock' ) . ' ';
	softdock_cp_select( $key, array( '1' => __( '1st', 'softdock' ), '2' => __( '2nd', 'softdock' ), '3' => __( '3rd', 'softdock' ), '4' => __( '4th', 'softdock' ), '5' => __( '5th', 'softdock' ), '6' => __( '6th', 'softdock' ) ) );
	echo '</label>';
}
function softdock_cp_row( $label, $body ) {
	echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>';
	$body();
	echo '</td></tr>';
}

add_action( 'admin_head', function () {
	$screen = get_current_screen();
	if ( ! $screen || false === strpos( (string) $screen->id, 'softdock-' ) ) {
		return;
	}
	echo '<style>.sd-cp-tabs{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0 4px}.sd-cp-tabs a{padding:6px 14px;border-radius:999px;background:#fff;border:1px solid #dcdcde;text-decoration:none;color:#1d2327;font-weight:500}.sd-cp-tabs a:hover{border-color:#0f7b5f;color:#0f7b5f}.sd-cp-tabs a.on{background:#0f7b5f;border-color:#0f7b5f;color:#fff}.sd-cp .form-table th{width:220px}</style>';
} );

/* ---------- Homepage ---------- */
function softdock_render_home_page() {
	softdock_cp_open( __( 'Homepage', 'softdock' ), __( 'What the homepage shows, and in which order.', 'softdock' ) );
	?>
	<h2><?php esc_html_e( 'Latest programs (top of the page)', 'softdock' ); ?></h2>
	<table class="form-table" role="presentation"><tbody>
		<?php
		softdock_cp_row( __( 'Section', 'softdock' ), function () {
			echo '<p>';
			softdock_cp_check( 'latest_show', __( 'Show this section', 'softdock' ) );
			echo '</p>';
			softdock_cp_text( 'latest_title', __( 'Heading', 'softdock' ) );
			softdock_cp_number( 'latest_count', __( 'How many programs', 'softdock' ), 1, 30 );
		} );
		?>
	</tbody></table>

	<h2><?php esc_html_e( 'Platform sections', 'softdock' ); ?></h2>
	<table class="form-table" role="presentation"><tbody>
		<?php
		softdock_cp_row( __( 'All sections', 'softdock' ), function () {
			echo '<p><label>' . esc_html__( 'Order programs by', 'softdock' ) . ' ';
			softdock_cp_select( 'section_order', array( 'latest' => __( 'Latest first', 'softdock' ), 'downloads' => __( 'Most downloaded first', 'softdock' ), 'views' => __( 'Most viewed first', 'softdock' ), 'rating' => __( 'Top rated first', 'softdock' ) ) );
			echo '</label></p>';
			softdock_cp_number( 'section_count', __( 'Programs per section', 'softdock' ), 1, 30 );
			echo '<p>';
			softdock_cp_check( 'show_counts', __( 'Show the total number of programs next to each section heading (for example "26 programs")', 'softdock' ) );
			echo '</p>';
		} );
		?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Each section', 'softdock' ); ?></th>
			<td>
				<table class="widefat striped" style="max-width:640px">
					<thead><tr><th><?php esc_html_e( 'Show', 'softdock' ); ?></th><th><?php esc_html_e( 'Platform', 'softdock' ); ?></th><th><?php esc_html_e( 'Heading', 'softdock' ); ?></th><th><?php esc_html_e( 'Position', 'softdock' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( softdock_home_sections() as $n => $sec ) : ?>
						<?php $tid = (int) $sec['term']->term_id; ?>
						<tr>
							<td><input type="hidden" name="softdock_home[sections][<?php echo $tid; ?>][show]" value="0"><input type="checkbox" name="softdock_home[sections][<?php echo $tid; ?>][show]" value="1"<?php checked( 1, $sec['show'] ); ?> aria-label="<?php esc_attr_e( 'Show', 'softdock' ); ?>"></td>
							<td><?php echo esc_html( $sec['term']->name ); ?></td>
							<td><input type="text" name="softdock_home[sections][<?php echo $tid; ?>][title]" value="<?php echo esc_attr( $sec['title'] === $sec['term']->name ? '' : $sec['title'] ); ?>" placeholder="<?php echo esc_attr( $sec['term']->name ); ?>"></td>
							<td><input type="number" class="small-text" name="softdock_home[sections][<?php echo $tid; ?>][order]" value="<?php echo (int) ( ( $n + 1 ) * 10 ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Untick to hide a section. Leave the heading empty to use the platform name. Lower position numbers show first. New platforms (Software → Platforms) appear here automatically.', 'softdock' ); ?></p>
			</td>
		</tr>
	</tbody></table>
	<p class="description">
		<?php
		/* translators: %s: link to the Right sidebar page */
		printf( esc_html__( 'The blocks on the right of the homepage are set on the %s page.', 'softdock' ), '<a href="' . esc_url( admin_url( 'edit.php?post_type=software&page=softdock-sidebar' ) ) . '">' . esc_html__( 'Right sidebar', 'softdock' ) . '</a>' );
		?>
	</p>
	<?php
	softdock_cp_close();
}

/* ---------- Header ---------- */
function softdock_render_header_page() {
	softdock_cp_open( __( 'Header', 'softdock' ), __( 'The bar at the top of every page: logo, menu and buttons.', 'softdock' ) );
	echo '<table class="form-table" role="presentation"><tbody>';
	softdock_cp_row( __( 'Logo', 'softdock' ), function () {
		echo '<p>' . esc_html__( 'Upload your logo and site icon in Appearance → Customize → Site Identity. Without a logo, the first letter of the site name is shown.', 'softdock' ) . '</p>';
		echo '<p><a class="button" href="' . esc_url( admin_url( 'customize.php?autofocus[section]=title_tagline' ) ) . '">' . esc_html__( 'Change logo', 'softdock' ) . '</a></p><p>';
		softdock_cp_check( 'logo_text_show', __( 'Show the site name next to the logo', 'softdock' ) );
		echo '</p>';
	} );
	softdock_cp_row( __( 'Menu', 'softdock' ), function () {
		echo '<p>' . ( has_nav_menu( 'header' ) ? esc_html__( 'The header shows your own menu.', 'softdock' ) : esc_html__( 'The header shows the platform buttons (Windows, macOS…).', 'softdock' ) ) . '</p>';
		echo '<p class="description">' . esc_html__( 'To add, remove, rename or reorder menu items, make a menu and tick "Header menu" as its location. Without one, the platform buttons are shown.', 'softdock' ) . '</p>';
		echo '<p><a class="button" href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Edit the header menu', 'softdock' ) . '</a></p>';
	} );
	softdock_cp_row( __( 'Buttons', 'softdock' ), function () {
		echo '<p>';
		softdock_cp_check( 'show_cats', __( 'Categories button', 'softdock' ) );
		echo '</p>';
		softdock_cp_text( 'cats_label', __( 'Categories button text', 'softdock' ) );
		echo '<p>';
		softdock_cp_check( 'show_theme_btn', __( 'Light / dark mode button', 'softdock' ) );
		echo '</p><p class="description">' . esc_html__( 'The search button is set on the Search bar page.', 'softdock' ) . '</p>';
	} );
	softdock_cp_row( __( 'Scrolling', 'softdock' ), function () {
		softdock_cp_check( 'header_sticky', __( 'Keep the header at the top while scrolling', 'softdock' ) );
	} );
	echo '</tbody></table>';
	softdock_cp_close();
}

/* ---------- Search bar ---------- */
function softdock_render_search_page() {
	softdock_cp_open( __( 'Search bar', 'softdock' ), __( 'How visitors search for programs.', 'softdock' ) );
	echo '<table class="form-table" role="presentation"><tbody>';
	softdock_cp_row( __( 'Search', 'softdock' ), function () {
		echo '<p>';
		softdock_cp_check( 'show_search', __( 'Show search', 'softdock' ) );
		echo '</p><p><label>' . esc_html__( 'Style', 'softdock' ) . ' ';
		softdock_cp_select( 'search_mode', array( 'icon' => __( 'Search icon that opens the search box', 'softdock' ), 'bar' => __( 'Search box always visible under the header', 'softdock' ) ) );
		echo '</label></p>';
		softdock_cp_text( 'search_placeholder', __( 'Text inside the empty search box', 'softdock' ) );
	} );
	softdock_cp_row( __( 'Suggestions while typing', 'softdock' ), function () {
		echo '<p>';
		softdock_cp_check( 'search_suggest', __( 'Show suggestions as visitors type', 'softdock' ) );
		echo '</p>';
		softdock_cp_number( 'search_suggest_count', __( 'How many programs to suggest', 'softdock' ), 3, 15 );
		echo '<p>';
		softdock_cp_check( 'search_suggest_terms', __( 'Also suggest matching categories and platforms', 'softdock' ) );
		echo '</p>';
	} );
	echo '</tbody></table>';
	softdock_cp_close();
}

/* ---------- Right sidebar ---------- */
function softdock_render_sidebar_page() {
	softdock_cp_open( __( 'Right sidebar', 'softdock' ), __( 'Blocks on the right of the homepage: the Popular list, a Categories box, a banner and up to three blocks of your own content. Choose which ones show and their order. On phones they show below the programs.', 'softdock' ) );
	$cat_opts = array( '0' => __( 'All categories', 'softdock' ) );
	foreach ( get_terms( array( 'taxonomy' => 'software_cat', 'hide_empty' => false ) ) as $t ) {
		if ( $t instanceof WP_Term ) {
			$cat_opts[ (string) $t->term_id ] = $t->name;
		}
	}
	echo '<table class="form-table" role="presentation"><tbody>';
	softdock_cp_row( __( 'Popular list', 'softdock' ), function () use ( $cat_opts ) {
		echo '<p>';
		softdock_cp_check( 'popular_show', __( 'Show the list', 'softdock' ) );
		echo ' &nbsp; ';
		softdock_cp_position( 'order_popular' );
		echo '</p>';
		softdock_cp_text( 'popular_title', __( 'Heading', 'softdock' ) );
		echo '<p><label>' . esc_html__( 'Show', 'softdock' ) . ' ';
		softdock_cp_select( 'popular_by', array( 'downloads' => __( 'Most downloaded', 'softdock' ), 'views' => __( 'Most viewed', 'softdock' ), 'rating' => __( 'Top rated', 'softdock' ), 'latest' => __( 'Latest uploads', 'softdock' ) ) );
		echo '</label> &nbsp; <label>' . esc_html__( 'from', 'softdock' ) . ' ';
		softdock_cp_select( 'popular_cat', $cat_opts );
		echo '</label></p>';
		softdock_cp_number( 'popular_count', __( 'How many programs', 'softdock' ), 1, 20 );
	} );
	softdock_cp_row( __( 'Categories box', 'softdock' ), function () {
		echo '<p>';
		softdock_cp_check( 'cats_show', __( 'Show the box', 'softdock' ) );
		echo ' &nbsp; ';
		softdock_cp_position( 'order_cats' );
		echo '</p>';
		softdock_cp_text( 'cats_title', __( 'Heading', 'softdock' ) );
		softdock_cp_number( 'cats_count', __( 'How many categories', 'softdock' ), 1, 50 );
		echo '<p class="description">' . esc_html__( 'Shows the categories with the most programs, with their program counts.', 'softdock' ) . '</p>';
	} );
	softdock_cp_row( __( 'Banner', 'softdock' ), function () {
		$img = (int) softdock_home( 'banner_image' );
		echo '<p>';
		softdock_cp_check( 'banner_show', __( 'Show the banner', 'softdock' ) );
		echo ' &nbsp; ';
		softdock_cp_position( 'order_banner' );
		echo '</p><div class="sd-banner-pick"><input type="hidden" name="softdock_home[banner_image]" id="sd_banner_image" value="' . ( $img ? (int) $img : '' ) . '">';
		echo '<div class="sd-banner-preview">' . ( $img ? wp_get_attachment_image( $img, 'medium' ) : '<span>' . esc_html__( 'No image yet', 'softdock' ) . '</span>' ) . '</div>';
		echo '<p><button type="button" class="button sd-banner-upload">' . esc_html__( 'Choose banner image', 'softdock' ) . '</button> <button type="button" class="button-link sd-banner-remove"' . ( $img ? '' : ' hidden' ) . '>' . esc_html__( 'Remove', 'softdock' ) . '</button></p></div>';
		echo '<p><label>' . esc_html__( 'Link when clicked (optional)', 'softdock' ) . '<br><input type="url" class="large-text" name="softdock_home[banner_link]" value="' . esc_attr( softdock_home( 'banner_link' ) ) . '" placeholder="https://"></label></p><p>';
		softdock_cp_check( 'banner_newtab', __( 'Open the link in a new tab', 'softdock' ) );
		echo '</p><p class="description">' . esc_html__( 'About 300 px wide works best, for example 300×250 or 300×600.', 'softdock' ) . '</p>';
	} );
	for ( $n = 1; $n <= 3; $n++ ) {
		/* translators: %d: block number */
		softdock_cp_row( sprintf( __( 'Your content %d', 'softdock' ), $n ), function () use ( $n ) {
			echo '<p>';
			softdock_cp_check( 'custom' . $n . '_show', __( 'Show this block', 'softdock' ) );
			echo ' &nbsp; ';
			softdock_cp_position( 'order_custom' . $n );
			echo '</p>';
			softdock_cp_text( 'custom' . $n . '_title', __( 'Heading (optional)', 'softdock' ) );
			echo '<div style="max-width:640px">';
			wp_editor( (string) softdock_home( 'custom' . $n . '_body' ), 'sd_custom' . $n, array(
				'textarea_name' => 'softdock_home[custom' . $n . '_body]',
				'textarea_rows' => 6,
				'media_buttons' => true,
				'teeny'         => false,
			) );
			echo '</div><p class="description">' . esc_html__( 'Text, links, images, lists or embed code from Add Media. Good for an announcement, an ad, social links or a newsletter box.', 'softdock' ) . '</p>';
		} );
	}
	softdock_cp_row( __( 'Where', 'softdock' ), function () {
		softdock_cp_select( 'popular_pages', array( 'home' => __( 'Homepage only', 'softdock' ), 'all' => __( 'Homepage and list pages (platforms, categories, search)', 'softdock' ) ) );
	} );
	echo '</tbody></table>';
	softdock_cp_close();
}

/* ---------- Footer ---------- */
function softdock_render_footer_page() {
	softdock_cp_open( __( 'Footer', 'softdock' ), __( 'The strip at the bottom of every page.', 'softdock' ) );
	echo '<table class="form-table" role="presentation"><tbody>';
	softdock_cp_row( __( 'Footer', 'softdock' ), function () {
		softdock_cp_check( 'footer_show', __( 'Show the footer', 'softdock' ) );
	} );
	softdock_cp_row( __( 'Text', 'softdock' ), function () {
		echo '<p><label>' . esc_html__( 'Footer text', 'softdock' ) . '<br><textarea class="large-text" rows="2" name="softdock_home[footer_text]" placeholder="' . esc_attr( get_bloginfo( 'description' ) ) . '">' . esc_textarea( softdock_home( 'footer_text' ) ) . '</textarea></label></p>';
		echo '<p class="description">' . esc_html__( 'Leave empty to use the site tagline (Settings → General). Links are allowed.', 'softdock' ) . '</p>';
		softdock_cp_text( 'footer_copyright', __( 'Copyright line', 'softdock' ), 'regular-text', '© {year} {site}' );
		echo '<p class="description">' . esc_html__( '{year} becomes the current year and {site} the site name. Leave empty to hide it.', 'softdock' ) . '</p>';
	} );
	softdock_cp_row( __( 'Menu', 'softdock' ), function () {
		echo '<p>';
		softdock_cp_check( 'footer_menu_show', __( 'Show the footer menu (About, Contact, Privacy…)', 'softdock' ) );
		echo '</p><p><a class="button" href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Edit the footer menu', 'softdock' ) . '</a></p>';
		echo '<p class="description">' . esc_html__( 'Make a menu and tick "Footer menu" as its location.', 'softdock' ) . '</p>';
	} );
	echo '</tbody></table>';
	softdock_cp_close();
}

/* ---------- Ratings ---------- */
function softdock_render_ratings_page() {
	softdock_cp_open( __( 'Ratings', 'softdock' ), __( 'Star ratings from visitors.', 'softdock' ) );
	echo '<table class="form-table" role="presentation"><tbody>';
	softdock_cp_row( __( 'Ratings', 'softdock' ), function () {
		echo '<p>';
		softdock_cp_check( 'ratings_show', __( 'Show star ratings on the site', 'softdock' ) );
		echo '</p><p>';
		softdock_cp_check( 'ratings_vote', __( 'Let visitors rate programs ("Rate it" stars on each program page)', 'softdock' ) );
		echo '</p><p>';
		softdock_cp_check( 'ratings_in_lists', __( 'Show the stars in program lists (homepage, platforms, categories)', 'softdock' ) );
		echo '</p><p>';
		softdock_cp_check( 'ratings_count', __( 'Show the average and number of votes, for example "4.8 (20)"', 'softdock' ) );
		echo '</p><p class="description">' . esc_html__( 'Each visitor can rate a program once. Turning ratings off only hides them; votes already given are kept.', 'softdock' ) . '</p>';
	} );
	echo '</tbody></table>';
	softdock_cp_close();
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false === strpos( (string) $hook, 'softdock-sidebar' ) ) {
		return;
	}
	wp_enqueue_media();
	wp_add_inline_style( 'common', '.sd-banner-preview{max-width:300px;min-height:60px;border:1px dashed #c3c4c7;border-radius:6px;display:grid;place-items:center;overflow:hidden;background:#f6f7f7;color:#646970}.sd-banner-preview img{display:block;width:100%;height:auto}' );
	wp_add_inline_script( 'media-editor', 'jQuery(function($){var f;$(".sd-banner-upload").on("click",function(e){e.preventDefault();if(!f){f=wp.media({title:"Banner image",button:{text:"Use this image"},library:{type:"image"},multiple:false});f.on("select",function(){var a=f.state().get("selection").first().toJSON();$("#sd_banner_image").val(a.id);$(".sd-banner-preview").html($("<img alt=\"\">").attr("src",(a.sizes&&a.sizes.medium?a.sizes.medium:a).url));$(".sd-banner-remove").prop("hidden",false);});}f.open();});$(".sd-banner-remove").on("click",function(e){e.preventDefault();$("#sd_banner_image").val("");$(".sd-banner-preview").html("<span>No image yet</span>");$(this).prop("hidden",true);});});' );
} );
