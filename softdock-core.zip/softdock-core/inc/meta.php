<?php
/**
 * Program details: fields, meta box and saving.
 */

defined( 'ABSPATH' ) || exit;

/** Field definitions: meta key => [label, type, help]. */
function softdock_fields() {
	return array(
		'sd_version'      => array( __( 'Version', 'softdock' ), 'text', __( 'For example 3.0.21', 'softdock' ) ),
		'sd_tagline'      => array( __( 'Tagline', 'softdock' ), 'text', __( 'One line shown under the name in lists.', 'softdock' ) ),
		'sd_size_mb'      => array( __( 'File size (MB)', 'softdock' ), 'number', __( 'Size of the installer in megabytes. 1024 MB or more shows as GB.', 'softdock' ) ),
		'sd_license'      => array( __( 'License', 'softdock' ), 'text', __( 'For example GPL-3.0, MIT, Freeware.', 'softdock' ) ),
		'sd_official_url' => array( __( 'Official website', 'softdock' ), 'url', __( 'Optional link to the developer\'s site, shown under the download buttons.', 'softdock' ) ),
		'sd_magnet_url'   => array( __( 'Magnet download link', 'softdock' ), 'magnet', __( 'A magnet: link, for example from the developer\'s release page.', 'softdock' ) ),
		'sd_fast_url'     => array( __( 'Fast download link', 'softdock' ), 'url', __( 'For example a mirror or CDN link.', 'softdock' ) ),
		'sd_direct_url'   => array( __( 'Direct download link', 'softdock' ), 'url', __( 'A direct link to the installer. An uploaded file is used when this is empty.', 'softdock' ) ),
		'sd_file'         => array( __( 'Download file (optional)', 'softdock' ), 'file', __( 'Upload the installer to your Media Library to host it yourself. Only upload files you have the right to distribute. When set, the Download button uses this file instead of the official page.', 'softdock' ) ),
		'sd_developer'    => array( __( 'Developer', 'softdock' ), 'text', '' ),
		'sd_color'        => array( __( 'Icon color', 'softdock' ), 'color', __( 'Used for the letter icon when no featured image is set.', 'softdock' ) ),
		'sd_features'     => array( __( 'Features', 'softdock' ), 'lines', __( 'One feature per line.', 'softdock' ) ),
		'sd_requirements' => array( __( 'System requirements', 'softdock' ), 'lines', __( 'One requirement per line, for example "RAM: 4 GB".', 'softdock' ) ),
		'sd_versions'     => array( __( 'Previous versions', 'softdock' ), 'lines', __( 'One per line: date | version | size MB | link (optional). Example: 2026-09-10 | 3.0.20 | 41 | https://…', 'softdock' ) ),
		'sd_screenshots'  => array( __( 'Screenshots', 'softdock' ), 'gallery', __( 'Shown in the slider on the program page.', 'softdock' ) ),
	);
}

add_action( 'init', function () {
	foreach ( softdock_fields() as $key => $f ) {
		$type = $f[1];
		register_post_meta( 'software', $key, array(
			'type'              => 'number' === $type ? 'number' : 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) use ( $type ) {
				return softdock_clean_field( $value, $type );
			},
			'auth_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
		) );
	}
	foreach ( array( 'sd_downloads', 'sd_views', 'sd_rating', 'sd_rating_count' ) as $key ) {
		register_post_meta( 'software', $key, array(
			'type'              => 'number',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) {
				return softdock_clean_field( $value, 'number' );
			},
			'auth_callback'     => function () {
				return current_user_can( 'edit_others_posts' );
			},
		) );
	}
} );

/** Cleans a field value by type. Used by the edit screen, the REST API and importers. */
function softdock_clean_field( $raw, $type ) {
	$raw = is_scalar( $raw ) ? (string) $raw : '';
	switch ( $type ) {
		case 'url':
			return esc_url_raw( $raw, array( 'http', 'https' ) );
		case 'magnet':
			$raw = trim( $raw );
			return 0 === stripos( $raw, 'magnet:?' ) ? esc_url_raw( $raw, array( 'magnet' ) ) : '';
		case 'number':
			return '' === $raw ? '' : max( 0, (float) $raw );
		case 'color':
			$c = sanitize_hex_color( $raw );
			return $c ? $c : '';
		case 'lines':
			return sanitize_textarea_field( $raw );
		case 'file':
			$id = absint( $raw );
			return ( $id && 'attachment' === get_post_type( $id ) ) ? (string) $id : '';
		case 'gallery':
			return implode( ',', array_filter( array_map( 'absint', explode( ',', $raw ) ) ) );
		default:
			return sanitize_text_field( $raw );
	}
}

add_action( 'add_meta_boxes_software', function () {
	add_meta_box( 'softdock-details', __( 'Program details', 'softdock' ), 'softdock_render_meta_box', 'software', 'normal', 'high' );
} );

function softdock_render_meta_box( $post ) {
	wp_nonce_field( 'softdock_save', 'softdock_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( softdock_fields() as $key => $f ) {
		list( $label, $type, $help ) = $f;
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		switch ( $type ) {
			case 'lines':
				echo '<textarea class="large-text" rows="5" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
				break;
			case 'number':
				echo '<input type="number" step="any" min="0" class="regular-text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
				break;
			case 'color':
				echo '<input type="color" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ? $value : '#0f7b5f' ) . '">';
				break;
			case 'file':
				$fid = absint( $value );
				echo '<input type="hidden" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $fid ? $fid : '' ) . '">';
				echo '<span class="softdock-file-name" style="margin-right:8px">' . esc_html( $fid ? basename( (string) get_attached_file( $fid ) ) : __( 'No file chosen', 'softdock' ) ) . '</span>';
				echo '<button type="button" class="button softdock-pick-file">' . esc_html__( 'Choose file', 'softdock' ) . '</button> ';
				echo '<button type="button" class="button-link softdock-clear-file">' . esc_html__( 'Remove', 'softdock' ) . '</button>';
				break;
			case 'gallery':
				$ids = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );
				echo '<input type="hidden" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( implode( ',', $ids ) ) . '">';
				echo '<div class="softdock-shots" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px">';
				foreach ( $ids as $id ) {
					echo wp_get_attachment_image( $id, 'thumbnail', false, array( 'style' => 'width:80px;height:80px;object-fit:cover;border-radius:4px' ) );
				}
				echo '</div><button type="button" class="button softdock-pick">' . esc_html__( 'Choose screenshots', 'softdock' ) . '</button> ';
				echo '<button type="button" class="button-link softdock-clear">' . esc_html__( 'Remove all', 'softdock' ) . '</button>';
				break;
			default:
				echo '<input type="' . ( 'url' === $type ? 'url' : 'text' ) . '" class="regular-text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
		}
		if ( $help ) {
			echo '<p class="description">' . esc_html( $help ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '<tr><th scope="row">' . esc_html__( 'Downloads', 'softdock' ) . '</th><td>' . esc_html( number_format_i18n( (int) get_post_meta( $post->ID, 'sd_downloads', true ) ) ) . '<p class="description">' . esc_html__( 'Counted automatically when visitors click Download.', 'softdock' ) . '</p></td></tr>';
	$rating = (float) get_post_meta( $post->ID, 'sd_rating', true );
	$count  = (int) get_post_meta( $post->ID, 'sd_rating_count', true );
	echo '<tr><th scope="row">' . esc_html__( 'Visitor rating', 'softdock' ) . '</th><td>';
	/* translators: 1: average rating, 2: number of votes */
	echo esc_html( sprintf( __( '%1$s out of 5 from %2$d votes', 'softdock' ), number_format_i18n( $rating, 1 ), $count ) );
	echo '</td></tr></tbody></table>';
}

add_action( 'save_post_software', function ( $post_id ) {
	if ( ! isset( $_POST['softdock_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['softdock_nonce'] ), 'softdock_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( softdock_fields() as $key => $f ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$value = softdock_clean_field( wp_unslash( $_POST[ $key ] ), $f[1] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		// The size box can be in GB; it is always stored in MB.
		if ( 'sd_size_mb' === $key && '' !== $value && isset( $_POST['sd_size_unit'] ) && 'GB' === $_POST['sd_size_unit'] ) {
			$value = round( $value * 1024, 2 );
		}
		update_post_meta( $post_id, $key, $value );
	}
} );

/**
 * Every program gets numeric counters, so lists ordered by downloads, rating or size never drop it.
 * Runs for programs made in the editor, through the REST API or by an importer.
 */
add_action( 'wp_after_insert_post', function ( $post_id, $post ) {
	if ( 'software' !== $post->post_type || wp_is_post_revision( $post_id ) ) {
		return;
	}
	foreach ( array( 'sd_downloads', 'sd_views', 'sd_rating', 'sd_rating_count', 'sd_size_mb' ) as $key ) {
		if ( '' === (string) get_post_meta( $post_id, $key, true ) ) {
			update_post_meta( $post_id, $key, 0 );
		}
	}
}, 10, 2 );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screen = get_current_screen();
	if ( $screen && 'software' === $screen->post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		wp_enqueue_script( 'softdock-admin', SOFTDOCK_CORE_URL . 'assets/admin.js', array( 'jquery' ), SOFTDOCK_CORE_VERSION, true );
	}
} );

/** Admin list columns: version and downloads. */
add_filter( 'manage_software_posts_columns', function ( $cols ) {
	$cols['sd_version']   = __( 'Version', 'softdock' );
	$cols['sd_downloads'] = __( 'Downloads', 'softdock' );
	return $cols;
} );
add_action( 'manage_software_posts_custom_column', function ( $col, $post_id ) {
	if ( 'sd_version' === $col ) {
		echo esc_html( get_post_meta( $post_id, 'sd_version', true ) );
	} elseif ( 'sd_downloads' === $col ) {
		echo esc_html( number_format_i18n( (int) get_post_meta( $post_id, 'sd_downloads', true ) ) );
	}
}, 10, 2 );
add_filter( 'manage_edit-software_sortable_columns', function ( $cols ) {
	$cols['sd_downloads'] = 'sd_downloads';
	return $cols;
} );
