<?php
/**
 * Add / edit program screen laid out like the public program page:
 * green title band, main card with name, tagline, screenshots and overview,
 * and a side card with the icon, facts and download link.
 *
 * Uses the classic edit form, so WordPress still saves the title, content,
 * excerpt, platforms and categories. Program details are saved in meta.php.
 */

defined( 'ABSPATH' ) || exit;

/** Post types that use this layout: programs, and blog posts (see post-editor.php). */
function softdock_editor_types() {
	return array( 'software', 'post' );
}

/** These post types use this screen instead of the block editor. */
add_filter( 'use_block_editor_for_post_type', function ( $use, $post_type ) {
	return in_array( $post_type, softdock_editor_types(), true ) ? false : $use;
}, 10, 2 );

/** True on an add or edit screen that uses this layout. */
function softdock_is_program_screen() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	return $screen && in_array( $screen->post_type, softdock_editor_types(), true ) && 'post' === $screen->base;
}

/** Hide the default title, editor and boxes on this screen: the layout below has its own. */
function softdock_editor_setup() {
	global $typenow;
	$type = $typenow ? $typenow : ( isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $type && ! isset( $_GET['post'] ) && 'load-post-new.php' === current_action() ) { // phpcs:ignore WordPress.Security.NonceVerification
		$type = 'post';
	}
	if ( ! $type && isset( $_GET['post'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$type = get_post_type( absint( $_GET['post'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}
	if ( ! in_array( $type, softdock_editor_types(), true ) ) {
		return;
	}
	foreach ( array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ) as $feature ) {
		remove_post_type_support( $type, $feature );
	}
}
add_action( 'load-post.php', 'softdock_editor_setup' );
add_action( 'load-post-new.php', 'softdock_editor_setup' );

add_action( 'add_meta_boxes_software', function () {
	foreach ( array( 'platformdiv', 'software_catdiv', 'postexcerpt', 'postimagediv', 'postcustom', 'softdock-details', 'submitdiv', 'slugdiv', 'commentstatusdiv' ) as $box ) {
		remove_meta_box( $box, 'software', 'normal' );
		remove_meta_box( $box, 'software', 'side' );
		remove_meta_box( $box, 'software', 'advanced' );
	}
}, 99 );

add_filter( 'admin_body_class', function ( $classes ) {
	return softdock_is_program_screen() ? $classes . ' sd-editor' : $classes;
} );

add_action( 'admin_enqueue_scripts', function () {
	if ( ! softdock_is_program_screen() ) {
		return;
	}
	global $post;
	wp_enqueue_media( $post ? array( 'post' => $post->ID ) : array() );
	wp_enqueue_style( 'softdock-fonts', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap', array(), null );
	wp_enqueue_style( 'softdock-editor', SOFTDOCK_CORE_URL . 'assets/editor.css', array( 'softdock-fonts' ), SOFTDOCK_CORE_VERSION . '.' . filemtime( dirname( __DIR__ ) . '/assets/editor.css' ) );
	wp_enqueue_script( 'softdock-editor', SOFTDOCK_CORE_URL . 'assets/editor.js', array( 'jquery' ), SOFTDOCK_CORE_VERSION . '.' . filemtime( dirname( __DIR__ ) . '/assets/editor.js' ), true );
	wp_localize_script( 'softdock-editor', 'softdockEditor', array(
		'noFile'  => __( 'No file chosen', 'softdock' ),
		'program' => __( 'Program name', 'softdock' ),
	) );
}, 20 );

/** Hidden checkbox list for a taxonomy, shown as chips. */
function softdock_editor_terms( $post, $taxonomy, $terms ) {
	$checked = wp_get_object_terms( $post->ID, $taxonomy, array( 'fields' => 'ids' ) );
	$checked = is_wp_error( $checked ) ? array() : array_map( 'intval', $checked );
	// Ticked categories first, so they are visible without scrolling.
	'software_cat' === $taxonomy && usort( $terms, function ( $a, $b ) use ( $checked ) {
		return (int) in_array( (int) $b->term_id, $checked, true ) - (int) in_array( (int) $a->term_id, $checked, true );
	} );
	echo '<input type="hidden" name="tax_input[' . esc_attr( $taxonomy ) . '][]" value="0">';
	echo '<div class="sd-chips" data-tax="' . esc_attr( $taxonomy ) . '">';
	foreach ( $terms as $t ) {
		$on = in_array( (int) $t->term_id, $checked, true );
		echo '<label class="sd-chip"><input type="checkbox" name="tax_input[' . esc_attr( $taxonomy ) . '][]" value="' . (int) $t->term_id . '" data-name="' . esc_attr( $t->name ) . '"' . checked( $on, true, false ) . '><span>' . esc_html( $t->name ) . '</span></label>';
	}
	if ( ! $terms ) {
		echo '<span class="sd-muted">' . esc_html__( 'None yet.', 'softdock' ) . '</span>';
	}
	echo '</div>';
}

add_action( 'edit_form_top', function ( $post ) {
	if ( 'software' !== $post->post_type ) {
		return;
	}
	$m = function ( $key ) use ( $post ) {
		return (string) get_post_meta( $post->ID, $key, true );
	};
	$title     = 'auto-draft' === $post->post_status ? '' : $post->post_title;
	$color     = $m( 'sd_color' ) ? $m( 'sd_color' ) : '#0f7b5f';
	$thumb_id  = (int) get_post_thumbnail_id( $post->ID );
	$shots     = array_filter( array_map( 'absint', explode( ',', $m( 'sd_screenshots' ) ) ) );
	$file_id   = absint( $m( 'sd_file' ) );
	$rating    = (float) $m( 'sd_rating' );
	$votes     = (int) $m( 'sd_rating_count' );
	$published = in_array( $post->post_status, array( 'publish', 'future', 'private' ), true );
	$platforms = function_exists( 'softdock_platforms' ) ? softdock_platforms() : array();
	$cats      = get_terms( array( 'taxonomy' => 'software_cat', 'hide_empty' => false ) );
	$cats      = is_wp_error( $cats ) ? array() : $cats;
	$letter    = $title ? ( function_exists( 'mb_substr' ) ? mb_substr( $title, 0, 1 ) : substr( $title, 0, 1 ) ) : 'S';

	wp_nonce_field( 'softdock_save', 'softdock_nonce', false );
	?>
	<div class="sd-app">
		<div class="sd-band">
			<h1><span class="sd-live-title"><?php echo esc_html( $title ? $title : __( 'Program name', 'softdock' ) ); ?></span> <span class="sd-live-version"><?php echo esc_html( $m( 'sd_version' ) ); ?></span></h1>
			<nav class="sd-crumbs"><span><?php esc_html_e( 'Home', 'softdock' ); ?></span>›<span class="sd-live-platform"><?php esc_html_e( 'Platform', 'softdock' ); ?></span>›<span class="sd-live-cat"><?php esc_html_e( 'Category', 'softdock' ); ?></span></nav>
		</div>

		<div class="sd-detail">
			<div class="sd-card sd-main">
				<div class="sd-h2">
					<textarea name="post_title" id="title" class="sd-title" rows="1" placeholder="<?php esc_attr_e( 'Program name', 'softdock' ); ?>" autocomplete="off" spellcheck="true"><?php echo esc_textarea( $title ); ?></textarea>
				</div>
				<input type="text" name="sd_tagline" id="sd_tagline" class="sd-lead" value="<?php echo esc_attr( $m( 'sd_tagline' ) ); ?>" placeholder="<?php esc_attr_e( 'Tagline, for example: File archiver with a high compression ratio', 'softdock' ); ?>">

				<input type="hidden" name="sd_screenshots" id="sd_screenshots" value="<?php echo esc_attr( implode( ',', $shots ) ); ?>">
				<div class="sd-gallery<?php echo $shots ? ' has-shots' : ''; ?>">
					<div class="sd-shots">
						<?php foreach ( array_values( $shots ) as $i => $id ) : ?>
							<div class="sd-shot<?php echo 0 === $i ? ' on' : ''; ?>"><?php echo wp_get_attachment_image( $id, 'large' ); ?></div>
						<?php endforeach; ?>
					</div>
					<div class="sd-mock" aria-hidden="true"><div class="sd-win"><div class="sd-tb"><i></i><i></i><i></i>&nbsp;<span class="sd-live-title"><?php echo esc_html( $title ? $title : __( 'Program name', 'softdock' ) ); ?></span> — <?php esc_html_e( 'Main window', 'softdock' ); ?></div><div class="sd-bd"><div class="sd-side"></div><div class="sd-pane" style="background:linear-gradient(120deg,<?php echo esc_attr( $color ); ?>cc,<?php echo esc_attr( $color ); ?>22)"></div></div></div></div>
					<button type="button" class="sd-arrow l" data-shot="-1" aria-label="<?php esc_attr_e( 'Previous screenshot', 'softdock' ); ?>">‹</button>
					<button type="button" class="sd-arrow r" data-shot="1" aria-label="<?php esc_attr_e( 'Next screenshot', 'softdock' ); ?>">›</button>
					<div class="sd-dots"></div>
					<div class="sd-gallery-actions">
						<button type="button" class="sd-btn sd-pick-shots"><?php esc_html_e( 'Upload screenshots', 'softdock' ); ?></button>
						<button type="button" class="sd-btn sd-btn-ghost sd-clear-shots"><?php esc_html_e( 'Remove all', 'softdock' ); ?></button>
					</div>
				</div>

				<h3><?php esc_html_e( 'Overview of', 'softdock' ); ?> <span class="sd-live-title"><?php echo esc_html( $title ? $title : __( 'Program name', 'softdock' ) ); ?></span></h3>
				<div class="sd-entry"><?php wp_editor( $post->post_content, 'content', array( 'textarea_rows' => 10, 'media_buttons' => true ) ); ?></div>

				<h3><?php esc_html_e( 'Features', 'softdock' ); ?></h3>
				<textarea name="sd_features" id="sd_features" rows="5" placeholder="<?php esc_attr_e( 'One feature per line', 'softdock' ); ?>"><?php echo esc_textarea( $m( 'sd_features' ) ); ?></textarea>

				<h3><?php esc_html_e( 'System requirements', 'softdock' ); ?></h3>
				<textarea name="sd_requirements" id="sd_requirements" rows="4" placeholder="<?php esc_attr_e( 'One per line, for example: RAM: 4 GB', 'softdock' ); ?>"><?php echo esc_textarea( $m( 'sd_requirements' ) ); ?></textarea>

				<h3><?php esc_html_e( 'Previous versions', 'softdock' ); ?></h3>
				<textarea name="sd_versions" id="sd_versions" rows="4" class="sd-mono" placeholder="2026-09-10 | 3.0.20 | 41 | https://…"><?php echo esc_textarea( $m( 'sd_versions' ) ); ?></textarea>
				<p class="sd-help"><?php esc_html_e( 'One per line: date | version | size MB | link (optional).', 'softdock' ); ?></p>

				<h3><?php esc_html_e( 'Excerpt', 'softdock' ); ?> <small class="sd-muted"><?php esc_html_e( '(optional)', 'softdock' ); ?></small></h3>
				<textarea name="excerpt" id="excerpt" rows="2"><?php echo esc_textarea( $post->post_excerpt ); ?></textarea>
			</div>

			<aside class="sd-aside">
				<div class="sd-card sd-side-card">
					<div class="sd-head">
						<input type="hidden" name="sd_icon" id="sd_icon" value="<?php echo $thumb_id ? (int) $thumb_id : ''; ?>">
						<button type="button" class="sd-ico sd-pick-icon" style="background:<?php echo esc_attr( $color ); ?>" title="<?php esc_attr_e( 'Upload icon', 'softdock' ); ?>">
							<?php if ( $thumb_id ) : ?>
								<?php echo wp_get_attachment_image( $thumb_id, 'thumbnail', false, array( 'alt' => '' ) ); ?>
							<?php else : ?>
								<span class="sd-letter"><?php echo esc_html( $letter ); ?></span>
							<?php endif; ?>
							<span class="sd-ico-hint"><?php esc_html_e( 'Upload', 'softdock' ); ?></span>
						</button>
						<div class="sd-head-text">
							<b class="sd-live-title"><?php echo esc_html( $title ? $title : __( 'Program name', 'softdock' ) ); ?></b>
							<div class="sd-stars" title="<?php esc_attr_e( 'Visitor rating', 'softdock' ); ?>">
								<?php for ( $i = 1; $i <= 5; $i++ ) : ?><span class="<?php echo $i <= round( $rating ) ? 'on' : ''; ?>">★</span><?php endfor; ?>
								<span class="sd-num"><?php echo esc_html( number_format_i18n( $rating, 1 ) . ' (' . number_format_i18n( $votes ) . ')' ); ?></span>
							</div>
							<div class="sd-icon-links">
								<label class="sd-color"><input type="color" name="sd_color" id="sd_color" value="<?php echo esc_attr( $color ); ?>"> <?php esc_html_e( 'Color', 'softdock' ); ?></label>
								<button type="button" class="button-link sd-clear-icon"<?php echo $thumb_id ? '' : ' hidden'; ?>><?php esc_html_e( 'Remove icon', 'softdock' ); ?></button>
							</div>
						</div>
					</div>

					<dl class="sd-facts">
						<dt><label for="sd_version"><?php esc_html_e( 'Version', 'softdock' ); ?></label></dt>
						<dd><input type="text" name="sd_version" id="sd_version" class="sd-num" value="<?php echo esc_attr( $m( 'sd_version' ) ); ?>" placeholder="3.0.21"></dd>
						<dt><label for="sd_size_mb"><?php esc_html_e( 'Size', 'softdock' ); ?></label></dt>
						<?php
						$size_mb = (float) $m( 'sd_size_mb' );
						$in_gb   = $size_mb >= 1024;
						$size_v  = $size_mb > 0 ? ( $in_gb ? round( $size_mb / 1024, 2 ) : $size_mb ) : '';
						?>
						<dd class="sd-unit"><input type="number" step="any" min="0" name="sd_size_mb" id="sd_size_mb" class="sd-num" value="<?php echo esc_attr( $size_v ); ?>" placeholder="0">
							<select name="sd_size_unit" id="sd_size_unit" aria-label="<?php esc_attr_e( 'Size unit', 'softdock' ); ?>"><option value="MB"<?php selected( ! $in_gb ); ?>>MB</option><option value="GB"<?php selected( $in_gb ); ?>>GB</option></select></dd>
						<dt><label for="sd_license"><?php esc_html_e( 'License', 'softdock' ); ?></label></dt>
						<dd><input type="text" name="sd_license" id="sd_license" value="<?php echo esc_attr( $m( 'sd_license' ) ); ?>" placeholder="GPL-3.0"></dd>
						<dt><label for="sd_developer"><?php esc_html_e( 'Developer', 'softdock' ); ?></label></dt>
						<dd><input type="text" name="sd_developer" id="sd_developer" value="<?php echo esc_attr( $m( 'sd_developer' ) ); ?>" placeholder="<?php esc_attr_e( 'Name', 'softdock' ); ?>"></dd>
						<dt><?php esc_html_e( 'Updated', 'softdock' ); ?></dt>
						<dd><?php echo esc_html( 'auto-draft' === $post->post_status ? __( 'Now', 'softdock' ) : get_the_modified_date( '', $post ) ); ?></dd>
						<dt><?php esc_html_e( 'Downloads', 'softdock' ); ?></dt>
						<dd class="sd-num"><?php echo esc_html( number_format_i18n( (int) $m( 'sd_downloads' ) ) ); ?></dd>
						<dt><?php esc_html_e( 'Views', 'softdock' ); ?></dt>
						<dd class="sd-num"><?php echo esc_html( number_format_i18n( (int) $m( 'sd_views' ) ) ); ?></dd>
					</dl>

					<div class="sd-block">
						<label class="sd-label" for="post_name"><?php esc_html_e( 'Page URL', 'softdock' ); ?></label>
						<div class="sd-url">
							<span class="sd-url-base"><?php echo esc_html( wp_make_link_relative( home_url( '/software/' ) ) ); ?></span>
							<input type="text" name="post_name" id="post_name" value="<?php echo esc_attr( 'auto-draft' === $post->post_status ? '' : urldecode( $post->post_name ) ); ?>" placeholder="<?php esc_attr_e( 'program-name', 'softdock' ); ?>" autocomplete="off">
						</div>
						<p class="sd-note"><?php esc_html_e( 'Leave empty to make it from the program name.', 'softdock' ); ?></p>
					</div>

					<div class="sd-block">
						<span class="sd-label"><?php esc_html_e( 'Platform', 'softdock' ); ?></span>
						<?php softdock_editor_terms( $post, 'platform', $platforms ); ?>
					</div>
					<div class="sd-block">
						<span class="sd-label"><?php esc_html_e( 'Category', 'softdock' ); ?> <a class="sd-add-link" href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=software_cat&post_type=software' ) ); ?>" target="_blank"><?php esc_html_e( 'Add new', 'softdock' ); ?></a></span>
						<?php softdock_editor_terms( $post, 'software_cat', $cats ); ?>
					</div>

					<div class="sd-dls">
						<div class="sd-dl sd-dl-magnet" style="<?php echo esc_attr( softdock_button_style( 'magnet' ) . 'order:' . (int) softdock_setting( 'magnet_order' ) ); ?>">
							<span><?php echo esc_html( softdock_setting( 'magnet_label' ) ); ?></span>
							<input type="text" name="sd_magnet_url" id="sd_magnet_url" value="<?php echo esc_attr( $m( 'sd_magnet_url' ) ); ?>" placeholder="magnet:?xt=urn:btih:…" spellcheck="false">
						</div>
						<div class="sd-dl sd-dl-fast" style="<?php echo esc_attr( softdock_button_style( 'fast' ) . 'order:' . (int) softdock_setting( 'fast_order' ) ); ?>">
							<span><?php echo esc_html( softdock_setting( 'fast_label' ) ); ?></span>
							<?php if ( softdock_setting( 'fast_url' ) ) : ?>
								<small class="sd-global"><?php esc_html_e( 'Using the shared link from Software → Download links.', 'softdock' ); ?> <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=software&page=softdock-links' ) ); ?>"><?php esc_html_e( 'Change', 'softdock' ); ?></a></small>
							<?php endif; ?>
							<input type="url" name="sd_fast_url" id="sd_fast_url" value="<?php echo esc_attr( $m( 'sd_fast_url' ) ); ?>" placeholder="https://mirror.example.org/file.zip">
						</div>
						<div class="sd-dl sd-dl-direct" style="<?php echo esc_attr( softdock_button_style( 'direct' ) . 'order:' . (int) softdock_setting( 'direct_order' ) ); ?>">
							<span><?php echo esc_html( softdock_setting( 'direct_label' ) ); ?></span>
							<?php if ( softdock_setting( 'direct_url' ) ) : ?>
								<small class="sd-global"><?php esc_html_e( 'Using the shared link from Software → Download links.', 'softdock' ); ?> <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=software&page=softdock-links' ) ); ?>"><?php esc_html_e( 'Change', 'softdock' ); ?></a></small>
							<?php endif; ?>
							<input type="url" name="sd_direct_url" id="sd_direct_url" value="<?php echo esc_attr( $m( 'sd_direct_url' ) ); ?>" placeholder="https://example.org/setup.exe">
						</div>
					</div>
					<p class="sd-note"><?php esc_html_e( 'A button with no link here uses the uploaded file or official website. Turn buttons on or off in Software → Download links.', 'softdock' ); ?></p>

					<div class="sd-file">
						<input type="hidden" name="sd_file" id="sd_file" value="<?php echo $file_id ? (int) $file_id : ''; ?>">
						<button type="button" class="sd-btn sd-btn-ghost sd-pick-file"><?php esc_html_e( 'Upload download file', 'softdock' ); ?></button>
						<span class="sd-file-name"><?php echo esc_html( $file_id ? wp_basename( (string) get_attached_file( $file_id ) ) : __( 'No file chosen', 'softdock' ) ); ?></span>
						<button type="button" class="button-link sd-clear-file"<?php echo $file_id ? '' : ' hidden'; ?>><?php esc_html_e( 'Remove', 'softdock' ); ?></button>
					</div>
					<p class="sd-note"><?php esc_html_e( 'Optional. Used by Direct download when its link is empty. Only upload files you have the right to share.', 'softdock' ); ?></p>

					<div class="sd-block">
						<label class="sd-label" for="sd_official_url"><?php esc_html_e( 'Official website (optional)', 'softdock' ); ?></label>
						<input type="url" name="sd_official_url" id="sd_official_url" class="sd-boxed" value="<?php echo esc_attr( $m( 'sd_official_url' ) ); ?>" placeholder="https://example.org">
					</div>
				</div>

				<div class="sd-card sd-publish">
					<div class="sd-status"><?php esc_html_e( 'Status:', 'softdock' ); ?> <b><?php echo esc_html( $published ? __( 'Published', 'softdock' ) : __( 'Draft', 'softdock' ) ); ?></b>
						<?php if ( $published ) : ?> · <a href="<?php echo esc_url( get_permalink( $post ) ); ?>" target="_blank"><?php esc_html_e( 'View program ↗', 'softdock' ); ?></a><?php endif; ?>
					</div>
					<div class="sd-actions">
						<?php if ( $published ) : ?>
							<input type="submit" name="save" id="publish" class="sd-btn sd-btn-primary" value="<?php esc_attr_e( 'Update', 'softdock' ); ?>">
						<?php else : ?>
							<input type="submit" name="save" id="save-post" class="sd-btn sd-btn-ghost" value="<?php esc_attr_e( 'Save draft', 'softdock' ); ?>">
							<input type="hidden" name="post_status" value="draft">
							<?php if ( current_user_can( get_post_type_object( 'software' )->cap->publish_posts ) ) : ?>
								<input type="submit" name="publish" id="publish" class="sd-btn sd-btn-primary" value="<?php esc_attr_e( 'Publish', 'softdock' ); ?>">
							<?php else : ?>
								<input type="submit" name="publish" id="publish" class="sd-btn sd-btn-primary" value="<?php esc_attr_e( 'Submit for review', 'softdock' ); ?>">
							<?php endif; ?>
						<?php endif; ?>
					</div>
					<label class="sd-check"><input type="checkbox" name="comment_status" value="open"<?php checked( 'open', $post->comment_status ); ?>> <?php esc_html_e( 'Allow comments', 'softdock' ); ?></label>
					<input type="hidden" name="ping_status" value="<?php echo esc_attr( $post->ping_status ); ?>">
					<?php if ( 'auto-draft' !== $post->post_status && current_user_can( 'delete_post', $post->ID ) ) : ?>
						<a class="sd-trash" href="<?php echo esc_url( get_delete_post_link( $post->ID ) ); ?>"><?php esc_html_e( 'Move to Trash', 'softdock' ); ?></a>
					<?php endif; ?>
				</div>
			</aside>
		</div>
	</div>
	<?php
} );

/** Save the icon (programs) or featured image (posts). Other program details are saved in meta.php. */
add_action( 'save_post', function ( $post_id, $post ) {
	if ( ! in_array( $post->post_type, softdock_editor_types(), true ) ) {
		return;
	}
	if ( ! isset( $_POST['softdock_nonce'], $_POST['sd_icon'] ) || ! wp_verify_nonce( sanitize_key( $_POST['softdock_nonce'] ), 'softdock_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$id = absint( $_POST['sd_icon'] );
	if ( $id && wp_attachment_is_image( $id ) ) {
		set_post_thumbnail( $post_id, $id );
	} else {
		delete_post_thumbnail( $post_id );
	}
}, 10, 2 );


/** The name box can wrap onto several lines, but a name is always saved as one line. */
add_filter( 'wp_insert_post_data', function ( $data ) {
	if ( in_array( $data['post_type'], softdock_editor_types(), true ) ) {
		$data['post_title'] = trim( preg_replace( '/\s*[\r\n]+\s*/', ' ', $data['post_title'] ) );
	}
	return $data;
} );
