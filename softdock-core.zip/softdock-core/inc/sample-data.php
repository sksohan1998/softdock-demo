<?php
/**
 * Tools > Softdock sample data: imports example programs so the site is not empty.
 */

defined( 'ABSPATH' ) || exit;

/** id, name, version, tagline, category, platforms, downloads, rating, size MB, license, official URL, icon color. */
function softdock_sample_programs() {
	return array(
		array( 'vlc', 'VLC media player', '3.0.21', 'Plays almost every audio and video format', 'Multimedia', 'windows mac android linux', 1820440, 4.8, 42, 'GPL-2.0', 'https://www.videolan.org/vlc/', '#e8700e' ),
		array( 'gimp', 'GIMP', '2.10.38', 'Raster image editor with layers, masks and plug-ins', 'Graphics Editors', 'windows mac linux', 964210, 4.5, 312, 'GPL-3.0', 'https://www.gimp.org/', '#6b5a48' ),
		array( 'blender', 'Blender', '4.2.3 LTS', '3D modeling, animation, simulation and rendering', 'Engineering & 3D', 'windows mac linux', 1213077, 4.9, 330, 'GPL-3.0', 'https://www.blender.org/', '#e87d0d' ),
		array( 'libreoffice', 'LibreOffice', '24.8.2', 'Writer, Calc, Impress and more in one office suite', 'Office & PDF', 'windows mac linux', 1102331, 4.6, 340, 'MPL-2.0', 'https://www.libreoffice.org/', '#18a303' ),
		array( '7zip', '7-Zip', '24.08', 'File archiver with a high compression ratio', 'Tools & Utilities', 'windows', 2210983, 4.8, 1.6, 'LGPL', 'https://www.7-zip.org/', '#2b2b2b' ),
		array( 'audacity', 'Audacity', '3.6.4', 'Multi-track audio recorder and editor', 'Audio', 'windows mac linux', 788421, 4.6, 40, 'GPL-3.0', 'https://www.audacityteam.org/', '#1a5fd0' ),
		array( 'obs', 'OBS Studio', '30.2.3', 'Screen recording and live streaming', 'Video Editors', 'windows mac linux', 1450912, 4.8, 140, 'GPL-2.0', 'https://obsproject.com/', '#302e31' ),
		array( 'inkscape', 'Inkscape', '1.4', 'Vector graphics editor for SVG illustration', 'Graphics Editors', 'windows mac linux', 512301, 4.5, 120, 'GPL-3.0', 'https://inkscape.org/', '#000000' ),
		array( 'krita', 'Krita', '5.2.6', 'Digital painting for concept art and comics', 'Graphics Editors', 'windows mac linux android', 433870, 4.7, 180, 'GPL-3.0', 'https://krita.org/', '#4b6cc7' ),
		array( 'vscode', 'Visual Studio Code', '1.94', 'Lightweight code editor with extensions', 'Developer Tools', 'windows mac linux', 1690554, 4.8, 95, 'Freeware', 'https://code.visualstudio.com/', '#0a78d4' ),
		array( 'notepadpp', 'Notepad++', '8.7', 'Fast source code and text editor', 'Developer Tools', 'windows', 995402, 4.7, 5.5, 'GPL-3.0', 'https://notepad-plus-plus.org/', '#76b82a' ),
		array( 'handbrake', 'HandBrake', '1.8.2', 'Convert video to modern, widely supported codecs', 'Video Editors', 'windows mac linux', 602118, 4.6, 30, 'GPL-2.0', 'https://handbrake.fr/', '#c3342d' ),
		array( 'shotcut', 'Shotcut', '24.09', 'Cross-platform non-linear video editor', 'Video Editors', 'windows mac linux', 289744, 4.4, 110, 'GPL-3.0', 'https://shotcut.org/', '#2f6b8c' ),
		array( 'kdenlive', 'Kdenlive', '24.08.2', 'Multi-track video editing with effects and titles', 'Video Editors', 'windows mac linux', 246011, 4.5, 120, 'GPL-3.0', 'https://kdenlive.org/', '#3384d7' ),
		array( 'keepassxc', 'KeePassXC', '2.7.9', 'Offline password manager with encrypted vaults', 'Security', 'windows mac linux', 371290, 4.8, 40, 'GPL-3.0', 'https://keepassxc.org/', '#4b9e3d' ),
		array( 'firefox', 'Firefox', '131.0', 'Private, independent web browser', 'Internet', 'windows mac linux android', 1980223, 4.6, 60, 'MPL-2.0', 'https://www.mozilla.org/firefox/', '#ff7139' ),
		array( 'thunderbird', 'Thunderbird', '128.3 ESR', 'Email, calendar and contacts in one app', 'Internet', 'windows mac linux android', 420387, 4.4, 70, 'MPL-2.0', 'https://www.thunderbird.net/', '#0a84ff' ),
		array( 'qbittorrent', 'qBittorrent', '5.0.0', 'Ad-free BitTorrent client', 'Download Managers', 'windows mac linux', 811502, 4.6, 35, 'GPL-2.0', 'https://www.qbittorrent.org/', '#3b74c4' ),
		array( 'freecad', 'FreeCAD', '1.0', 'Parametric 3D CAD modeler', 'Engineering & 3D', 'windows mac linux', 198440, 4.3, 480, 'LGPL', 'https://www.freecad.org/', '#c4262e' ),
		array( 'godot', 'Godot Engine', '4.3', '2D and 3D game engine', 'Developer Tools', 'windows mac linux', 344009, 4.8, 60, 'MIT', 'https://godotengine.org/', '#478cbf' ),
		array( 'iina', 'IINA', '1.3.5', 'Modern media player designed for macOS', 'Multimedia', 'mac', 265302, 4.7, 90, 'GPL-3.0', 'https://iina.io/', '#5b3fd0' ),
		array( 'rectangle', 'Rectangle', '0.84', 'Move and resize windows with shortcuts', 'Tools & Utilities', 'mac', 198270, 4.8, 4, 'MIT', 'https://rectangleapp.com/', '#2a2a2a' ),
		array( 'stats', 'Stats', '2.11', 'System monitor in your menu bar', 'Tools & Utilities', 'mac', 112983, 4.6, 12, 'MIT', 'https://github.com/exelban/stats', '#3d86f5' ),
		array( 'newpipe', 'NewPipe', '0.27.2', 'Lightweight front end for online video', 'Entertainment', 'android', 543711, 4.6, 12, 'GPL-3.0', 'https://newpipe.net/', '#cd201f' ),
		array( 'organicmaps', 'Organic Maps', '2024.10', 'Offline maps for hiking, cycling and driving', 'Travel & Maps', 'android', 201445, 4.7, 90, 'Apache-2.0', 'https://organicmaps.app/', '#2b8a4e' ),
		array( 'signal', 'Signal', '7.20', 'Private messenger with end-to-end encryption', 'Communication', 'android windows mac linux', 1230998, 4.7, 60, 'AGPL-3.0', 'https://signal.org/', '#3a76f0' ),
		array( 'termux', 'Termux', '0.118.1', 'Linux terminal environment on Android', 'Developer Tools', 'android', 301254, 4.7, 100, 'GPL-3.0', 'https://termux.dev/', '#1d1d1d' ),
		array( 'antennapod', 'AntennaPod', '3.5', 'Open podcast player and manager', 'Audio', 'android', 158320, 4.7, 15, 'GPL-3.0', 'https://antennapod.org/', '#1e6fb8' ),
		array( '0ad', '0 A.D.', '0.26', 'Historical real-time strategy game', 'Strategy', 'games windows mac linux', 219003, 4.5, 1500, 'GPL-2.0', 'https://play0ad.com/', '#9b6a2c' ),
		array( 'supertuxkart', 'SuperTuxKart', '1.4', '3D kart racer with online multiplayer', 'Racing', 'games windows mac linux android', 388251, 4.6, 640, 'GPL-3.0', 'https://supertuxkart.net/', '#d93a2b' ),
		array( 'mindustry', 'Mindustry', 'v146', 'Factory-building tower defense', 'Strategy', 'games windows mac linux android', 274402, 4.8, 120, 'GPL-3.0', 'https://mindustrygame.github.io/', '#c9a227' ),
		array( 'luanti', 'Luanti', '5.9.1', 'Voxel sandbox engine, formerly Minetest', 'Sandbox', 'games windows mac linux android', 246188, 4.5, 40, 'LGPL', 'https://www.luanti.org/', '#5a8f3a' ),
		array( 'wesnoth', 'Battle for Wesnoth', '1.18.2', 'Turn-based fantasy strategy', 'Strategy', 'games windows mac linux', 182640, 4.6, 480, 'GPL-2.0', 'https://www.wesnoth.org/', '#7a2f1f' ),
		array( 'ubuntu', 'Ubuntu Desktop', '24.04.1 LTS', 'Popular Linux distribution for desktops', 'Operating Systems', 'linux', 901220, 4.5, 5900, 'Free', 'https://ubuntu.com/download/desktop', '#e95420' ),
		array( 'fedora', 'Fedora Workstation', '41', 'Linux workstation with recent GNOME', 'Operating Systems', 'linux', 402108, 4.6, 2300, 'Free', 'https://fedoraproject.org/workstation/', '#51a2da' ),
	);
}

add_action( 'admin_menu', function () {
	add_management_page( __( 'Softdock sample data', 'softdock' ), __( 'Softdock sample data', 'softdock' ), 'manage_options', 'softdock-sample', 'softdock_sample_page' );
} );

function softdock_sample_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$done    = null;
	$removed = null;
	if ( isset( $_POST['softdock_import'] ) && check_admin_referer( 'softdock_import' ) ) {
		$done = softdock_import_samples();
	}
	if ( isset( $_POST['softdock_remove'] ) && check_admin_referer( 'softdock_remove' ) ) {
		$removed = softdock_remove_samples();
	}
	echo '<div class="wrap"><h1>' . esc_html__( 'Softdock sample data', 'softdock' ) . '</h1>';
	if ( null !== $done ) {
		/* translators: 1: created count, 2: skipped count */
		echo '<div class="notice notice-success"><p>' . esc_html( sprintf( __( 'Added %1$d programs. Skipped %2$d that already existed.', 'softdock' ), $done[0], $done[1] ) ) . ' <a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'View site', 'softdock' ) . '</a></p></div>';
	}
	if ( null !== $removed ) {
		/* translators: %d: number of programs */
		echo '<div class="notice notice-success"><p>' . esc_html( sprintf( __( 'Moved %d sample programs to the Trash. Programs you added yourself were not touched.', 'softdock' ), $removed ) ) . '</p></div>';
	}
	$existing = softdock_sample_ids();
	if ( $existing ) {
		echo '<h2>' . esc_html__( 'Remove sample programs', 'softdock' ) . '</h2>';
		/* translators: %d: number of programs */
		echo '<p>' . esc_html( sprintf( __( '%d sample programs are on this site. Removing them moves only the samples to the Trash; your own programs stay.', 'softdock' ), count( $existing ) ) ) . '</p>';
		echo '<form method="post">';
		wp_nonce_field( 'softdock_remove' );
		submit_button( __( 'Remove sample programs', 'softdock' ), 'delete', 'softdock_remove' );
		echo '</form><hr>';
	}
	echo '<h2>' . esc_html__( 'Add sample programs', 'softdock' ) . '</h2>';
	echo '<p>' . esc_html( sprintf(
		/* translators: %d: number of programs */
		__( 'Adds %d free and open-source programs with platforms, categories, features, previous versions and official download links. Download counts, ratings and sizes are example values you can edit or delete. Programs that already exist are skipped.', 'softdock' ),
		count( softdock_sample_programs() )
	) ) . '</p>';
	echo '<form method="post">';
	wp_nonce_field( 'softdock_import' );
	submit_button( __( 'Import sample programs', 'softdock' ), 'primary', 'softdock_import' );
	echo '</form></div>';
}

function softdock_import_samples() {
	softdock_ensure_platforms();
	$made    = 0;
	$skipped = 0;
	$os_req  = array(
		'windows' => 'Windows 11 or Windows 10 (64-bit)',
		'mac'     => 'macOS 12 Monterey or later',
		'linux'   => '64-bit Linux with a recent desktop',
		'android' => 'Android 8.0 or later',
	);
	foreach ( softdock_sample_programs() as $p ) {
		list( $slug, $name, $ver, $tag, $cat, $plats, $dl, $rating, $size, $lic, $site, $color ) = $p;
		if ( get_page_by_path( $slug, OBJECT, 'software' ) ) {
			++$skipped;
			continue;
		}
		$plats   = explode( ' ', $plats );
		$os      = array_values( array_intersect( array_keys( $os_req ), $plats ) );
		$os_name = array_map( function ( $k ) {
			$all = softdock_default_platforms();
			return $all[ $k ];
		}, $os );
		$free    = in_array( $lic, array( 'Freeware', 'Free' ), true ) ? 'free' : 'free and open-source';
		$content = sprintf(
			'<!-- wp:paragraph --><p>%1$s is %2$s software: %3$s. It runs on %4$s.</p><!-- /wp:paragraph -->' . "\n\n" . '<!-- wp:paragraph --><p>It is released under the %5$s license, so you can use it at home or at work without paying. The download button sends you to the developer&#8217;s own site, so you always get the original installer.</p><!-- /wp:paragraph -->',
			esc_html( $name ),
			$free,
			esc_html( lcfirst( $tag ) ),
			esc_html( implode( ', ', $os_name ) ),
			esc_html( $lic )
		);
		$post_id = wp_insert_post( array(
			'post_type'    => 'software',
			'post_status'  => 'publish',
			'post_title'   => $name,
			'post_name'    => $slug,
			'post_content' => $content,
			'post_excerpt' => $tag,
		), true );
		if ( is_wp_error( $post_id ) ) {
			continue;
		}
		update_post_meta( $post_id, '_softdock_sample', 1 );
		wp_set_object_terms( $post_id, $plats, 'platform' );
		wp_set_object_terms( $post_id, $cat, 'software_cat' );

		$versions = array();
		$parts    = preg_split( '/(\d+)(?!.*\d)/', $ver, 2, PREG_SPLIT_DELIM_CAPTURE );
		for ( $i = 1; $i <= 5; $i++ ) {
			$prev = ( 3 === count( $parts ) && (int) $parts[1] - $i >= 0 ) ? $parts[0] . ( (int) $parts[1] - $i ) . $parts[2] : $ver . ' (build ' . $i . ')';
			$date = gmdate( 'Y-m-d', strtotime( '-' . ( $i * 41 ) . ' days' ) );
			$versions[] = $date . ' | ' . $prev . ' | ' . round( $size * ( 1 - $i * 0.015 ), 1 );
		}
		$reqs = array();
		foreach ( $os as $k ) {
			$reqs[] = $os_req[ $k ];
		}
		$reqs[] = 'Memory: 4 GB RAM (8 GB recommended)';
		$reqs[] = 'Free disk space: ' . (int) ceil( $size * 3 ) . ' MB or more';

		$meta = array(
			'sd_version'      => $ver,
			'sd_tagline'      => $tag,
			'sd_size_mb'      => $size,
			'sd_license'      => $lic,
			'sd_official_url' => $site,
			'sd_color'        => $color,
			'sd_downloads'    => $dl,
			'sd_rating'       => $rating,
			'sd_rating_count' => 20,
			'sd_features'     => implode( "\n", array( $tag, 'Regular updates from an active community', 'No ads and no bundled offers', 'Runs on ' . implode( ', ', $os_name ), 'Extensions and plug-ins supported', 'Translated into many languages' ) ),
			'sd_requirements' => implode( "\n", $reqs ),
			'sd_versions'     => implode( "\n", $versions ),
		);
		foreach ( $meta as $k => $v ) {
			update_post_meta( $post_id, $k, $v );
		}
		++$made;
	}
	return array( $made, $skipped );
}

/** IDs of programs created by the sample importer, in any status except Trash. */
function softdock_sample_ids() {
	return get_posts( array(
		'post_type'      => 'software',
		'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'meta_key'       => '_softdock_sample',
		'meta_value'     => 1,
	) );
}

function softdock_remove_samples() {
	$n = 0;
	foreach ( softdock_sample_ids() as $id ) {
		if ( wp_trash_post( $id ) ) {
			++$n;
		}
	}
	return $n;
}
