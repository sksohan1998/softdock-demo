<?php
/**
 * Search suggestions: as visitors type in the search box, matching programs and categories
 * appear under it. Names that start with the typed text come first.
 */

defined( 'ABSPATH' ) || exit;

function softdock_suggest() {
	$term = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$term = trim( $term );
	if ( '' === $term || mb_strlen( $term ) > 80 || ! softdock_home( 'search_suggest' ) ) {
		wp_send_json_success( array( 'items' => array() ) );
	}

	global $wpdb;
	$like_start = $wpdb->esc_like( $term ) . '%';
	$like_any   = '%' . $wpdb->esc_like( $term ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$ids = $wpdb->get_col( $wpdb->prepare(
		"SELECT ID FROM {$wpdb->posts}
		WHERE post_type = 'software' AND post_status = 'publish' AND post_title LIKE %s
		ORDER BY ( post_title LIKE %s ) DESC, post_title ASC
		LIMIT %d",
		$like_any,
		$like_start,
		(int) softdock_home( 'search_suggest_count' )
	) );

	$items = array();
	foreach ( $ids as $id ) {
		$id    = (int) $id;
		$thumb = get_the_post_thumbnail_url( $id, 'thumbnail' );
		$logo  = function_exists( 'softdock_logo_url' ) ? softdock_logo_url( $id ) : '';
		$color = get_post_meta( $id, 'sd_color', true );
		$title = get_the_title( $id );
		$items[] = array(
			'type'    => 'program',
			'title'   => html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ),
			'version' => (string) get_post_meta( $id, 'sd_version', true ),
			'url'     => get_permalink( $id ),
			'icon'    => $thumb ? $thumb : $logo,
			'svg'     => ! $thumb && $logo && '.svg' === substr( $logo, -4 ),
			'letter'  => function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $title, 0, 1 ) ) : strtoupper( substr( $title, 0, 1 ) ),
			'color'   => $color ? $color : '#0f7b5f',
		);
	}

	$cats = ! softdock_home( 'search_suggest_terms' ) ? array() : get_terms( array(
		'taxonomy'   => array( 'software_cat', 'platform' ),
		'hide_empty' => true,
		'name__like' => $term,
		'number'     => 3,
	) );
	if ( ! is_wp_error( $cats ) ) {
		foreach ( $cats as $c ) {
			$items[] = array(
				'type'  => 'platform' === $c->taxonomy ? 'platform' : 'category',
				'title' => html_entity_decode( $c->name, ENT_QUOTES, 'UTF-8' ),
				'count' => (int) $c->count,
				'url'   => get_term_link( $c ),
			);
		}
	}

	wp_send_json_success( array( 'items' => $items ) );
}
add_action( 'wp_ajax_softdock_suggest', 'softdock_suggest' );
add_action( 'wp_ajax_nopriv_softdock_suggest', 'softdock_suggest' );
