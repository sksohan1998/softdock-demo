<?php
/**
 * Visitor star ratings, one vote per visitor per program.
 *
 * No nonce: pages are often served from a page cache, where a nonce would expire and
 * break voting. Abuse is limited by the one-vote-per-visitor check below.
 */

defined( 'ABSPATH' ) || exit;

function softdock_rate() {
	$post_id = isset( $_POST['post'] ) ? absint( $_POST['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$stars   = isset( $_POST['stars'] ) ? absint( $_POST['stars'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( 'software' !== get_post_type( $post_id ) || 'publish' !== get_post_status( $post_id ) || $stars < 1 || $stars > 5 ) {
		wp_send_json_error( array( 'message' => __( 'Pick between 1 and 5 stars.', 'softdock' ) ), 400 );
	}
	$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$voter = wp_hash( $ip . '|' . get_current_user_id() );
	$key   = 'sd_vote_' . $post_id . '_' . substr( $voter, 0, 20 );
	if ( get_transient( $key ) ) {
		wp_send_json_error( array( 'message' => __( 'You already rated this program.', 'softdock' ) ), 409 );
	}
	set_transient( $key, 1, YEAR_IN_SECONDS );

	$count  = (int) get_post_meta( $post_id, 'sd_rating_count', true );
	$avg    = (float) get_post_meta( $post_id, 'sd_rating', true );
	$newavg = round( ( $avg * $count + $stars ) / ( $count + 1 ), 2 );
	update_post_meta( $post_id, 'sd_rating', $newavg );
	update_post_meta( $post_id, 'sd_rating_count', $count + 1 );
	wp_send_json_success( array(
		'rating' => $newavg,
		'count'  => $count + 1,
	) );
}
add_action( 'wp_ajax_softdock_rate', 'softdock_rate' );
add_action( 'wp_ajax_nopriv_softdock_rate', 'softdock_rate' );
