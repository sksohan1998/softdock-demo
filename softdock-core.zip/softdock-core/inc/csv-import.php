<?php
/**
 * Tools > Import programs (CSV): add or update many programs at once from a spreadsheet,
 * including icons and screenshots downloaded from links.
 */

defined( 'ABSPATH' ) || exit;

const SOFTDOCK_CSV_BATCH = 10;

/** Columns: name => description shown on the import page. Only "title" is required. */
function softdock_csv_columns() {
	return array(
		'title'             => __( 'Program name (required)', 'softdock' ),
		'slug'              => __( 'URL name, e.g. vlc. Used to find and update an existing program.', 'softdock' ),
		'status'            => __( 'publish or draft. Default: publish', 'softdock' ),
		'description'       => __( 'Overview text. HTML allowed.', 'softdock' ),
		'version'           => __( 'e.g. 3.0.21', 'softdock' ),
		'tagline'           => __( 'One line for lists', 'softdock' ),
		'size'              => __( 'e.g. 42 MB or 2.6 GB', 'softdock' ),
		'license'           => __( 'e.g. GPL-3.0, Freeware', 'softdock' ),
		'developer'         => '',
		'file_type'         => __( 'e.g. EXE, ZIP, DMG', 'softdock' ),
		'official_url'      => __( 'Official website', 'softdock' ),
		'magnet_url'        => __( 'Magnet link for the Magnet download button (optional)', 'softdock' ),
		'file_url'          => __( 'Link to an installer to copy into your Media Library (optional; only files you may distribute)', 'softdock' ),
		'platforms'         => __( 'Comma-separated, e.g. Windows, macOS', 'softdock' ),
		'categories'        => __( 'Comma-separated. New categories are created.', 'softdock' ),
		'features'          => __( 'One per line, or separated by ;', 'softdock' ),
		'requirements'      => __( 'One per line, or separated by ;', 'softdock' ),
		'installation'      => __( 'Installation steps: one per line, or separated by ;', 'softdock' ),
		'previous_versions' => __( 'One per line: name | version | file size | download link', 'softdock' ),
		'icon_url'          => __( 'Link to the icon image', 'softdock' ),
		'screenshot_urls'   => __( 'Links to screenshots, separated by spaces or commas', 'softdock' ),
		'color'             => __( 'Icon color, e.g. #e8700e', 'softdock' ),
		'downloads'         => __( 'Starting download count', 'softdock' ),
	);
}

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Import programs', 'softdock' ), __( 'Import (CSV)', 'softdock' ), 'manage_options', 'softdock-csv', 'softdock_csv_page' );
} );

/** Where uploaded CSV files wait while they are imported. Not publicly listable. */
function softdock_csv_dir() {
	$up  = wp_upload_dir();
	$dir = trailingslashit( $up['basedir'] ) . 'softdock-import';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
		file_put_contents( $dir . '/index.php', "<?php // Silence.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	return $dir;
}

/** Template download. */
add_action( 'admin_post_softdock_csv_template', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do this.', 'softdock' ) );
	}
	check_admin_referer( 'softdock_csv_template' );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=softdock-programs-template.csv' );
	$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- BOM so Excel reads UTF-8.
	fputcsv( $out, array_keys( softdock_csv_columns() ) );
	fputcsv( $out, array(
		'VLC media player', 'vlc', 'publish', 'VLC plays almost every audio and video format.', '3.0.21', 'Plays almost every audio and video format',
		'42 MB', 'GPL-2.0', 'VideoLAN', 'https://www.videolan.org/vlc/', '', 'Windows, macOS, Linux, Android', 'Multimedia',
		"Plays most formats\nNo ads", "Windows 10 or later\n4 GB RAM", "2026-08-01 | 3.0.20 | 41 | https://www.videolan.org/vlc/",
		'', '', '#e8700e', '0',
	) );
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

function softdock_csv_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$error = '';
	$job   = null;
	if ( isset( $_POST['softdock_csv_upload'] ) && check_admin_referer( 'softdock_csv_upload' ) ) {
		$job = softdock_csv_start( $error );
	}
	?>
	<div class="wrap" id="softdock-csv">
		<h1><?php esc_html_e( 'Import programs', 'softdock' ); ?></h1>
		<p style="max-width:780px"><?php esc_html_e( 'Add many programs at once from a spreadsheet. Fill in the template in Excel, Google Sheets or Numbers, save it as CSV (UTF-8), and upload it here. Each row becomes one program. Icons and screenshots are downloaded from the links you give.', 'softdock' ); ?></p>
		<p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=softdock_csv_template' ), 'softdock_csv_template' ) ); ?>"><?php esc_html_e( 'Download the template', 'softdock' ); ?></a></p>

		<?php if ( $error ) : ?><div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div><?php endif; ?>

		<?php if ( $job ) : ?>
			<div class="card" style="max-width:780px" id="sd-csv-job" data-job="<?php echo esc_attr( $job['id'] ); ?>" data-total="<?php echo (int) $job['total']; ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'softdock_csv_run' ) ); ?>">
				<?php /* translators: %d: number of rows */ ?>
				<h2><?php echo esc_html( sprintf( _n( 'Importing %d row', 'Importing %d rows', $job['total'], 'softdock' ), $job['total'] ) ); ?></h2>
				<?php if ( $job['unknown'] ) : ?>
					<?php /* translators: %s: column names */ ?>
					<p class="description"><?php echo esc_html( sprintf( __( 'These columns are not recognised and will be skipped: %s', 'softdock' ), implode( ', ', $job['unknown'] ) ) ); ?></p>
				<?php endif; ?>
				<div style="height:12px;background:#dcdcde;border-radius:6px;overflow:hidden"><div id="sd-csv-bar" style="height:100%;width:0;background:#2271b1;transition:width .2s"></div></div>
				<p id="sd-csv-status" role="status"><?php esc_html_e( 'Starting…', 'softdock' ); ?></p>
				<ul id="sd-csv-errors" style="color:#b32d2e"></ul>
			</div>
		<?php else : ?>
			<form method="post" enctype="multipart/form-data" class="card" style="max-width:780px">
				<?php wp_nonce_field( 'softdock_csv_upload' ); ?>
				<p><label for="sd-csv-file"><strong><?php esc_html_e( 'CSV file', 'softdock' ); ?></strong></label><br><input type="file" id="sd-csv-file" name="csv" accept=".csv,text/csv" required></p>
				<p><label><input type="checkbox" name="update_existing" value="1" checked> <?php esc_html_e( 'Update programs that already exist (matched by slug, then by exact name) instead of adding duplicates', 'softdock' ); ?></label></p>
				<p><label><input type="checkbox" name="download_images" value="1" checked> <?php esc_html_e( 'Download icons and screenshots from their links', 'softdock' ); ?></label></p>
				<?php submit_button( __( 'Upload and import', 'softdock' ), 'primary', 'softdock_csv_upload', false ); ?>
			</form>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Columns', 'softdock' ); ?></h2>
		<p><?php esc_html_e( 'Only "title" is required. Leave out columns you do not need; their order does not matter.', 'softdock' ); ?></p>
		<table class="widefat striped" style="max-width:780px"><tbody>
			<?php foreach ( softdock_csv_columns() as $col => $help ) : ?>
				<tr><td style="width:180px"><code><?php echo esc_html( $col ); ?></code></td><td><?php echo esc_html( $help ); ?></td></tr>
			<?php endforeach; ?>
		</tbody></table>
	</div>
	<?php
}

/** Saves the uploaded file and reads its header. Returns the job, or null with $error set. */
function softdock_csv_start( &$error ) {
	if ( empty( $_FILES['csv']['tmp_name'] ) || ! empty( $_FILES['csv']['error'] ) ) {
		$error = __( 'The file did not upload. Choose a CSV file and try again. Large files may exceed your host\'s upload limit.', 'softdock' );
		return null;
	}
	$name = sanitize_file_name( wp_unslash( $_FILES['csv']['name'] ) );
	if ( ! preg_match( '/\.(csv|txt)$/i', $name ) ) {
		$error = __( 'That is not a CSV file. In your spreadsheet app, use File → Save As (or Download) → CSV.', 'softdock' );
		return null;
	}
	$id   = wp_generate_password( 20, false );
	$path = softdock_csv_dir() . '/' . $id . '.csv';
	if ( ! move_uploaded_file( $_FILES['csv']['tmp_name'], $path ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$error = __( 'The file could not be saved. Check that the uploads folder is writable.', 'softdock' );
		return null;
	}
	$rows = softdock_csv_read( $path );
	if ( ! $rows || ! in_array( 'title', $rows['header'], true ) ) {
		wp_delete_file( $path );
		$error = __( 'The first row must hold the column names, and one of them must be "title". Start from the template.', 'softdock' );
		return null;
	}
	$job = array(
		'id'      => $id,
		'path'    => $path,
		'total'   => count( $rows['rows'] ),
		'offset'  => 0,
		'update'  => ! empty( $_POST['update_existing'] ), // phpcs:ignore WordPress.Security.NonceVerification
		'images'  => ! empty( $_POST['download_images'] ), // phpcs:ignore WordPress.Security.NonceVerification
		'unknown' => array_values( array_diff( array_filter( $rows['header'] ), array_keys( softdock_csv_columns() ) ) ),
		'stats'   => array( 'added' => 0, 'updated' => 0, 'failed' => 0 ),
	);
	set_transient( 'softdock_csv_' . $id, $job, DAY_IN_SECONDS );
	return $job;
}

/** Reads a CSV file into header + rows. Handles Excel's BOM, ; separators and line breaks inside cells. */
function softdock_csv_read( $path ) {
	$fh = fopen( $path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! $fh ) {
		return null;
	}
	$first = (string) fgets( $fh );
	rewind( $fh );
	$sep    = substr_count( $first, ';' ) > substr_count( $first, ',' ) ? ';' : ',';
	$header = fgetcsv( $fh, 0, $sep, '"', '\\' );
	if ( ! $header ) {
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return null;
	}
	$header[0] = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $header[0] );
	$header    = array_map( function ( $h ) {
		return str_replace( array( ' ', '-' ), '_', strtolower( trim( (string) $h ) ) );
	}, $header );
	$rows = array();
	while ( false !== ( $r = fgetcsv( $fh, 0, $sep, '"', '\\' ) ) ) {
		if ( ! array_filter( $r, 'strlen' ) ) {
			continue;
		}
		$rows[] = array_combine( $header, array_pad( array_slice( $r, 0, count( $header ) ), count( $header ), '' ) );
	}
	fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	return array( 'header' => $header, 'rows' => $rows );
}

/** Splits "a, b; c" or lines into a list. */
function softdock_csv_list( $value, $allow_comma = true ) {
	$re = $allow_comma ? '/\R|;|,/' : '/\R|;/';
	return array_values( array_filter( array_map( 'trim', preg_split( $re, (string) $value ) ) ) );
}

/** Matches a platform by slug or name, e.g. "macOS", "mac", "Windows". */
function softdock_csv_platform( $name ) {
	$guess = softdock_guess_platform( $name );
	foreach ( softdock_platforms() as $p ) {
		if ( 0 === strcasecmp( $p->name, $name ) || 0 === strcasecmp( $p->slug, $name ) || $p->slug === $guess ) {
			return $p->term_id;
		}
	}
	$new = wp_insert_term( $name, 'platform' );
	return is_wp_error( $new ) ? 0 : (int) $new['term_id'];
}

/** Copies an image or file from a link into the Media Library. Returns the attachment ID or 0. */
function softdock_csv_sideload( $url, $post_id ) {
	$url = esc_url_raw( trim( $url ), array( 'http', 'https' ) );
	if ( ! $url ) {
		return 0;
	}
	global $wpdb;
	$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_softdock_source_url' AND meta_value = %s LIMIT 1", $url ) );
	if ( $existing && get_post( $existing ) ) {
		return $existing;
	}
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$id = media_sideload_image( $url, $post_id, null, 'id' );
	if ( is_wp_error( $id ) ) {
		// Not an image (for example an installer): download it as a plain file.
		$tmp = download_url( $url, 300 );
		if ( is_wp_error( $tmp ) ) {
			return 0;
		}
		$file = array( 'name' => wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ), 'tmp_name' => $tmp );
		$id   = media_handle_sideload( $file, $post_id );
		if ( is_wp_error( $id ) ) {
			wp_delete_file( $tmp );
			return 0;
		}
	}
	update_post_meta( $id, '_softdock_source_url', $url );
	return (int) $id;
}

/** Imports one row. Returns 'added', 'updated', or an error message. */
function softdock_csv_row( $row, $job ) {
	$row   = array_map( 'trim', $row );
	$title = isset( $row['title'] ) ? $row['title'] : '';
	if ( '' === $title ) {
		return __( 'No title', 'softdock' );
	}
	$slug     = ! empty( $row['slug'] ) ? sanitize_title( $row['slug'] ) : '';
	$existing = null;
	if ( $job['update'] ) {
		if ( $slug ) {
			$existing = get_page_by_path( $slug, OBJECT, 'software' );
		}
		if ( ! $existing ) {
			$found    = get_posts( array( 'post_type' => 'software', 'title' => $title, 'post_status' => 'any', 'posts_per_page' => 1, 'suppress_filters' => true ) );
			$existing = $found ? $found[0] : null;
		}
	}
	$status = ( isset( $row['status'] ) && in_array( strtolower( $row['status'] ), array( 'draft', 'pending', 'private', 'publish' ), true ) ) ? strtolower( $row['status'] ) : 'publish';
	$data   = array(
		'post_type'   => 'software',
		'post_title'  => $title,
		'post_status' => $status,
	);
	if ( isset( $row['description'] ) && '' !== $row['description'] ) {
		$data['post_content'] = wp_kses_post( $row['description'] );
	}
	if ( $slug ) {
		$data['post_name'] = $slug;
	}
	if ( $existing ) {
		$data['ID'] = $existing->ID;
		$post_id    = wp_update_post( wp_slash( $data ), true );
	} else {
		$post_id = wp_insert_post( wp_slash( $data ), true );
	}
	if ( is_wp_error( $post_id ) ) {
		return $post_id->get_error_message();
	}

	$meta = array(
		'version'      => array( 'sd_version', 'text' ),
		'tagline'      => array( 'sd_tagline', 'text' ),
		'license'      => array( 'sd_license', 'text' ),
		'developer'    => array( 'sd_developer', 'text' ),
		'file_type'    => array( 'sd_file_type', 'text' ),
		'official_url' => array( 'sd_official_url', 'url' ),
		'magnet_url'   => array( 'sd_magnet_url', 'magnet' ),
		'color'        => array( 'sd_color', 'color' ),
	);
	foreach ( $meta as $col => $m ) {
		if ( isset( $row[ $col ] ) && '' !== $row[ $col ] ) {
			update_post_meta( $post_id, $m[0], softdock_clean_field( $row[ $col ], $m[1] ) );
		}
	}
	if ( isset( $row['size'] ) && '' !== $row['size'] ) {
		update_post_meta( $post_id, 'sd_size_mb', softdock_parse_size( $row['size'] ) );
	}
	if ( isset( $row['downloads'] ) && '' !== $row['downloads'] ) {
		update_post_meta( $post_id, 'sd_downloads', (int) preg_replace( '/\D/', '', $row['downloads'] ) );
	}
	foreach ( array( 'features' => 'sd_features', 'requirements' => 'sd_requirements', 'installation' => 'sd_install' ) as $col => $key ) {
		if ( ! empty( $row[ $col ] ) ) {
			update_post_meta( $post_id, $key, softdock_clean_field( implode( "\n", softdock_csv_list( $row[ $col ], false ) ), 'lines' ) );
		}
	}
	if ( ! empty( $row['previous_versions'] ) ) {
		update_post_meta( $post_id, 'sd_versions', softdock_clean_field( implode( "\n", array_filter( array_map( 'trim', preg_split( '/\R/', $row['previous_versions'] ) ) ) ), 'lines' ) );
	}
	if ( ! empty( $row['platforms'] ) ) {
		wp_set_object_terms( $post_id, array_filter( array_map( 'softdock_csv_platform', softdock_csv_list( $row['platforms'] ) ) ), 'platform' );
	}
	if ( ! empty( $row['categories'] ) ) {
		wp_set_object_terms( $post_id, softdock_csv_list( $row['categories'] ), 'software_cat' );
	}

	$notes = array();
	if ( $job['images'] ) {
		if ( ! empty( $row['icon_url'] ) ) {
			$icon = softdock_csv_sideload( $row['icon_url'], $post_id );
			if ( $icon ) {
				set_post_thumbnail( $post_id, $icon );
			} else {
				$notes[] = __( 'icon could not be downloaded', 'softdock' );
			}
		}
		if ( ! empty( $row['screenshot_urls'] ) ) {
			$shots = array();
			foreach ( preg_split( '/[\s,]+/', $row['screenshot_urls'] ) as $u ) {
				$sid = $u ? softdock_csv_sideload( $u, $post_id ) : 0;
				if ( $sid ) {
					$shots[] = $sid;
				} elseif ( $u ) {
					$notes[] = __( 'a screenshot could not be downloaded', 'softdock' );
				}
			}
			if ( $shots ) {
				update_post_meta( $post_id, 'sd_screenshots', implode( ',', $shots ) );
			}
		}
	}
	if ( ! empty( $row['file_url'] ) ) {
		$fid = softdock_csv_sideload( $row['file_url'], $post_id );
		if ( $fid ) {
			update_post_meta( $post_id, 'sd_file', $fid );
		} else {
			$notes[] = __( 'download file could not be copied', 'softdock' );
		}
	}
	foreach ( array( 'sd_downloads', 'sd_rating', 'sd_rating_count', 'sd_size_mb' ) as $key ) {
		if ( '' === (string) get_post_meta( $post_id, $key, true ) ) {
			update_post_meta( $post_id, $key, 0 );
		}
	}
	return array( $existing ? 'updated' : 'added', $notes );
}

add_action( 'wp_ajax_softdock_csv_run', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'softdock_csv_run', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Your session expired. Reload the page and upload the file again.', 'softdock' ) ), 403 );
	}
	$id  = isset( $_POST['job'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', sanitize_text_field( wp_unslash( $_POST['job'] ) ) ) : '';
	$job = get_transient( 'softdock_csv_' . $id );
	if ( ! $job || ! file_exists( $job['path'] ) ) {
		wp_send_json_error( array( 'message' => __( 'This import has expired. Upload the file again.', 'softdock' ) ), 404 );
	}
	wp_raise_memory_limit( 'admin' );
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
	$data   = softdock_csv_read( $job['path'] );
	$rows   = array_slice( $data['rows'], $job['offset'], SOFTDOCK_CSV_BATCH );
	$errors = array();
	wp_defer_term_counting( true );
	foreach ( $rows as $i => $row ) {
		$line = $job['offset'] + $i + 2; // Spreadsheet row number (row 1 is the header).
		try {
			$res = softdock_csv_row( $row, $job );
		} catch ( Throwable $e ) {
			$res = $e->getMessage();
		}
		if ( is_array( $res ) ) {
			++$job['stats'][ $res[0] ];
			if ( $res[1] ) {
				/* translators: 1: row number, 2: program name, 3: problems */
				$errors[] = sprintf( __( 'Row %1$d (%2$s): imported, but %3$s.', 'softdock' ), $line, isset( $row['title'] ) ? $row['title'] : '', implode( ', ', $res[1] ) );
			}
		} else {
			++$job['stats']['failed'];
			/* translators: 1: row number, 2: reason */
			$errors[] = sprintf( __( 'Row %1$d skipped: %2$s', 'softdock' ), $line, $res );
		}
	}
	wp_defer_term_counting( false );
	$job['offset'] += count( $rows );
	$finished       = $job['offset'] >= $job['total'];
	if ( $finished ) {
		wp_delete_file( $job['path'] );
		delete_transient( 'softdock_csv_' . $id );
	} else {
		set_transient( 'softdock_csv_' . $id, $job, DAY_IN_SECONDS );
	}
	wp_cache_set( 'last_changed', microtime(), 'softdock' );
	wp_send_json_success( array(
		'offset'   => $job['offset'],
		'total'    => $job['total'],
		'finished' => $finished,
		'stats'    => $job['stats'],
		'errors'   => $errors,
	) );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'software_page_softdock-csv' === $hook ) {
		wp_enqueue_script( 'softdock-csv', SOFTDOCK_CORE_URL . 'assets/csv.js', array(), SOFTDOCK_CORE_VERSION, true );
		wp_localize_script( 'softdock-csv', 'sdCsv', array(
			'ajax' => admin_url( 'admin-ajax.php' ),
			'list' => admin_url( 'edit.php?post_type=software' ),
			'i18n' => array(
				/* translators: 1: rows done, 2: total rows */
				'progress' => __( 'Imported %1$d of %2$d rows…', 'softdock' ),
				/* translators: 1: added, 2: updated, 3: skipped */
				'done'     => __( 'Finished: %1$d added, %2$d updated, %3$d skipped.', 'softdock' ),
				'view'     => __( 'See all programs', 'softdock' ),
				'error'    => __( 'The server stopped responding. Upload the file again with "Update programs that already exist" ticked: rows already imported are updated, not duplicated.', 'softdock' ),
			),
		) );
	}
} );
