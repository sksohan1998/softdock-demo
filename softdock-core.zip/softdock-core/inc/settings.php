<?php
/**
 * Software → Settings: download buttons for all programs, and which counters visitors see.
 */

defined( 'ABSPATH' ) || exit;

function softdock_setting_defaults() {
	return array(
		'magnet_label'   => __( 'Magnet download', 'softdock' ),
		'show_magnet'    => 1,
		'show_fast'      => 1,
		'show_direct'    => 1,
		'fast_label'     => __( 'Fast download', 'softdock' ),
		'fast_url'       => '',
		'direct_label'   => __( 'Direct download', 'softdock' ),
		'direct_url'     => '',
		'show_downloads' => 1,
		'show_views'     => 1,
		// Button order (1 = first), colours and where the buttons sit on the program page.
		'magnet_order'   => 1,
		'fast_order'     => 2,
		'direct_order'   => 3,
		'magnet_bg'      => '#0f7b5f',
		'magnet_fg'      => '#ffffff',
		'fast_bg'        => '#111111',
		'fast_fg'        => '#ffffff',
		'direct_bg'      => '#f5c518',
		'direct_fg'      => '#1a1a1a',
		'buttons_place'  => 'below',
		'home_order'     => 'latest',
		'home_latest'    => 1,
	);
}

/** Where the download buttons can sit on the program page. */
function softdock_button_places() {
	return array(
		'above'  => __( 'Above the program details (version, size…)', 'softdock' ),
		'below'  => __( 'Below the program details', 'softdock' ),
		'gallery' => __( 'Under the screenshots, in the main column', 'softdock' ),
	);
}

/** One setting, with its default when not saved yet. */
function softdock_setting( $key ) {
	$saved    = get_option( 'softdock_settings', array() );
	$defaults = softdock_setting_defaults();
	$value    = is_array( $saved ) && array_key_exists( $key, $saved ) ? $saved[ $key ] : ( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	if ( in_array( $key, array( 'magnet_label', 'fast_label', 'direct_label' ), true ) && '' === trim( (string) $value ) ) {
		$value = $defaults[ $key ];
	}
	return $value;
}

add_action( 'admin_init', function () {
	register_setting( 'softdock_settings', 'softdock_settings', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in  = is_array( $in ) ? $in : array();
			$old = get_option( 'softdock_settings', array() );
			$old = is_array( $old ) ? $old : array();
			// Each settings page sends only its own fields; keep the others as they were.
			$page = isset( $in['_page'] ) ? $in['_page'] : '';
			$defaults = softdock_setting_defaults();
			$keep     = array();
			if ( 'counters' === $page ) {
				$keep = array( 'magnet_label', 'fast_label', 'fast_url', 'direct_label', 'direct_url', 'show_magnet', 'show_fast', 'show_direct', 'magnet_order', 'fast_order', 'direct_order', 'magnet_bg', 'magnet_fg', 'fast_bg', 'fast_fg', 'direct_bg', 'direct_fg', 'buttons_place' );
			} elseif ( 'links' === $page ) {
				$keep = array( 'home_order', 'home_latest' );
			}
			foreach ( $keep as $k ) {
				$in[ $k ] = isset( $old[ $k ] ) ? $old[ $k ] : $defaults[ $k ];
			}
			$color = function ( $k ) use ( $in, $defaults ) {
				$c = isset( $in[ $k ] ) ? sanitize_hex_color( $in[ $k ] ) : '';
				return $c ? $c : $defaults[ $k ];
			};
			$order = function ( $k ) use ( $in, $defaults ) {
				$n = isset( $in[ $k ] ) ? absint( $in[ $k ] ) : 0;
				return $n >= 1 && $n <= 3 ? $n : $defaults[ $k ];
			};
			return array(
				'magnet_label'   => sanitize_text_field( isset( $in['magnet_label'] ) ? $in['magnet_label'] : '' ),
				'show_magnet'    => empty( $in['show_magnet'] ) ? 0 : 1,
				'show_fast'      => empty( $in['show_fast'] ) ? 0 : 1,
				'show_direct'    => empty( $in['show_direct'] ) ? 0 : 1,
				'fast_label'     => sanitize_text_field( isset( $in['fast_label'] ) ? $in['fast_label'] : '' ),
				'fast_url'       => esc_url_raw( isset( $in['fast_url'] ) ? trim( $in['fast_url'] ) : '', array( 'http', 'https' ) ),
				'direct_label'   => sanitize_text_field( isset( $in['direct_label'] ) ? $in['direct_label'] : '' ),
				'direct_url'     => esc_url_raw( isset( $in['direct_url'] ) ? trim( $in['direct_url'] ) : '', array( 'http', 'https' ) ),
				'show_downloads' => empty( $in['show_downloads'] ) ? 0 : 1,
				'show_views'     => empty( $in['show_views'] ) ? 0 : 1,
				'magnet_order'   => $order( 'magnet_order' ),
				'fast_order'     => $order( 'fast_order' ),
				'direct_order'   => $order( 'direct_order' ),
				'magnet_bg'      => $color( 'magnet_bg' ),
				'magnet_fg'      => $color( 'magnet_fg' ),
				'fast_bg'        => $color( 'fast_bg' ),
				'fast_fg'        => $color( 'fast_fg' ),
				'direct_bg'      => $color( 'direct_bg' ),
				'direct_fg'      => $color( 'direct_fg' ),
				'buttons_place'  => isset( $in['buttons_place'] ) && array_key_exists( $in['buttons_place'], softdock_button_places() ) ? $in['buttons_place'] : 'below',
				'home_order'     => isset( $in['home_order'] ) && 'downloads' === $in['home_order'] ? 'downloads' : 'latest',
				'home_latest'    => empty( $in['home_latest'] ) ? 0 : 1,
			);
		},
	) );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false === strpos( (string) $hook, 'softdock-links' ) ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_add_inline_style( 'wp-color-picker', '.sd-set-row{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:flex-start}.sd-set-row>label,.sd-set-col{display:grid;gap:4px}.sd-btn-preview{display:inline-block;min-width:240px;text-align:center;padding:11px 16px;border-radius:9px;font-weight:700;font-size:15px}' );
	wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){function prev(el){var $td=$(el).closest("td"),$p=$td.find(".sd-btn-preview"),f=$td.find(".sd-color-field");$p.css({background:f.eq(0).val(),color:f.eq(1).val()});}$(".sd-color-field").wpColorPicker({change:function(e,ui){var el=this;setTimeout(function(){prev(el);},0);},clear:function(){var el=this;setTimeout(function(){prev(el);},0);}});});' );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Download links', 'softdock' ), __( 'Download links', 'softdock' ), 'manage_options', 'softdock-links', 'softdock_render_links' );
	add_submenu_page( 'edit.php?post_type=software', __( 'Softdock settings', 'softdock' ), __( 'Settings', 'softdock' ), 'manage_options', 'softdock-settings', 'softdock_render_settings' );
} );

function softdock_render_links() {
	$check = function ( $key, $label ) {
		echo '<input type="hidden" name="softdock_settings[' . esc_attr( $key ) . ']" value="0">';
		echo '<label><input type="checkbox" name="softdock_settings[' . esc_attr( $key ) . ']" value="1"' . checked( 1, (int) softdock_setting( $key ), false ) . '> ' . esc_html( $label ) . '</label>';
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Download links', 'softdock' ); ?></h1>
		<p><?php esc_html_e( 'Choose which download buttons visitors see, and their text. The Fast and Direct buttons can use one link for every program, for example an ad or affiliate page: change it here and every program changes.', 'softdock' ); ?></p>
		<p><?php esc_html_e( 'When a program has no link for a button, the button uses the program’s uploaded file or official website.', 'softdock' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_settings' ); ?>
			<input type="hidden" name="softdock_settings[_page]" value="links">
			<table class="form-table" role="presentation"><tbody>
				<?php
				foreach ( array(
					'magnet' => __( 'Magnet download button', 'softdock' ),
					'fast'   => __( 'Fast download button', 'softdock' ),
					'direct' => __( 'Direct download button', 'softdock' ),
				) as $type => $title ) :
					?>
					<tr>
						<th scope="row"><?php echo esc_html( $title ); ?></th>
						<td>
							<p><?php $check( 'show_' . $type, __( 'Show this button', 'softdock' ) ); ?></p>
							<p class="sd-set-row">
								<label><?php esc_html_e( 'Position', 'softdock' ); ?>
									<select name="softdock_settings[<?php echo esc_attr( $type ); ?>_order]">
										<?php foreach ( array( 1 => __( '1st', 'softdock' ), 2 => __( '2nd', 'softdock' ), 3 => __( '3rd', 'softdock' ) ) as $n => $nl ) : ?>
											<option value="<?php echo (int) $n; ?>"<?php selected( (int) softdock_setting( $type . '_order' ), $n ); ?>><?php echo esc_html( $nl ); ?></option>
										<?php endforeach; ?>
									</select>
								</label>
								<span class="sd-set-col"><span><?php esc_html_e( 'Button colour', 'softdock' ); ?></span>
									<input type="text" class="sd-color-field" name="softdock_settings[<?php echo esc_attr( $type ); ?>_bg]" value="<?php echo esc_attr( softdock_setting( $type . '_bg' ) ); ?>" data-default-color="<?php echo esc_attr( softdock_setting_defaults()[ $type . '_bg' ] ); ?>">
								</span>
								<span class="sd-set-col"><span><?php esc_html_e( 'Text colour', 'softdock' ); ?></span>
									<input type="text" class="sd-color-field" name="softdock_settings[<?php echo esc_attr( $type ); ?>_fg]" value="<?php echo esc_attr( softdock_setting( $type . '_fg' ) ); ?>" data-default-color="<?php echo esc_attr( softdock_setting_defaults()[ $type . '_fg' ] ); ?>">
								</span>
							</p>
							<p><span class="sd-btn-preview" data-type="<?php echo esc_attr( $type ); ?>" style="background:<?php echo esc_attr( softdock_setting( $type . '_bg' ) ); ?>;color:<?php echo esc_attr( softdock_setting( $type . '_fg' ) ); ?>"><?php echo esc_html( softdock_setting( $type . '_label' ) ); ?></span></p>
							<p><label for="sd_<?php echo esc_attr( $type ); ?>_label"><?php esc_html_e( 'Button text', 'softdock' ); ?></label><br>
							<input type="text" class="regular-text" id="sd_<?php echo esc_attr( $type ); ?>_label" name="softdock_settings[<?php echo esc_attr( $type ); ?>_label]" value="<?php echo esc_attr( softdock_setting( $type . '_label' ) ); ?>"></p>
							<?php if ( 'magnet' !== $type ) : ?>
								<p><label for="sd_<?php echo esc_attr( $type ); ?>_url"><?php esc_html_e( 'Link for all programs (ads / affiliate)', 'softdock' ); ?></label><br>
								<input type="url" class="large-text" id="sd_<?php echo esc_attr( $type ); ?>_url" name="softdock_settings[<?php echo esc_attr( $type ); ?>_url]" value="<?php echo esc_attr( softdock_setting( $type . '_url' ) ); ?>" placeholder="https://"></p>
								<p class="description"><?php esc_html_e( 'Empty: each program uses the link typed on its own page.', 'softdock' ); ?></p>
							<?php else : ?>
								<p class="description"><?php esc_html_e( 'Each program has its own magnet link, typed on its page.', 'softdock' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Where the buttons show', 'softdock' ); ?></th>
					<td>
						<?php foreach ( softdock_button_places() as $val => $lab ) : ?>
							<label style="display:block;margin-bottom:6px"><input type="radio" name="softdock_settings[buttons_place]" value="<?php echo esc_attr( $val ); ?>"<?php checked( softdock_setting( 'buttons_place' ), $val ); ?>> <?php echo esc_html( $lab ); ?></label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Counters on the site', 'softdock' ); ?></th>
					<td>
						<?php $check( 'show_downloads', __( 'Show total downloads', 'softdock' ) ); ?><br>
						<?php $check( 'show_views', __( 'Show views', 'softdock' ) ); ?>
						<p class="description"><?php esc_html_e( 'Hidden counters keep counting; visitors just do not see them.', 'softdock' ); ?></p>
					</td>
				</tr>
			</tbody></table>
			<?php submit_button( __( 'Save', 'softdock' ) ); ?>
		</form>
	</div>
	<?php
}

function softdock_render_settings() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Softdock settings', 'softdock' ); ?></h1>
		<p><?php esc_html_e( 'Downloads and views are always counted. These only choose whether visitors see them.', 'softdock' ); ?>
			<?php /* translators: %s: link to the Download links page */ ?>
			<?php printf( esc_html__( 'Button text and shared links are under %s.', 'softdock' ), '<a href="' . esc_url( admin_url( 'edit.php?post_type=software&page=softdock-links' ) ) . '">' . esc_html__( 'Download links', 'softdock' ) . '</a>' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_settings' ); ?>
			<input type="hidden" name="softdock_settings[_page]" value="counters">
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Homepage', 'softdock' ); ?></th>
					<td>
						<label style="display:block;margin-bottom:6px"><input type="radio" name="softdock_settings[home_order]" value="latest"<?php checked( softdock_setting( 'home_order' ), 'latest' ); ?>> <?php esc_html_e( 'Show the latest programs first (default)', 'softdock' ); ?></label>
						<label style="display:block"><input type="radio" name="softdock_settings[home_order]" value="downloads"<?php checked( softdock_setting( 'home_order' ), 'downloads' ); ?>> <?php esc_html_e( 'Show the most downloaded programs first', 'softdock' ); ?></label>
						<p style="margin-top:12px">
							<input type="hidden" name="softdock_settings[home_latest]" value="0">
							<label><input type="checkbox" name="softdock_settings[home_latest]" value="1"<?php checked( 1, (int) softdock_setting( 'home_latest' ) ); ?>> <?php esc_html_e( 'Show a "Latest programs" section at the top of the homepage, with the newest programs from every platform', 'softdock' ); ?></label>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Show on the site', 'softdock' ); ?></th>
					<td>
						<input type="hidden" name="softdock_settings[show_downloads]" value="0">
						<label><input type="checkbox" name="softdock_settings[show_downloads]" value="1"<?php checked( 1, (int) softdock_setting( 'show_downloads' ) ); ?>> <?php esc_html_e( 'Total downloads', 'softdock' ); ?></label><br>
						<input type="hidden" name="softdock_settings[show_views]" value="0">
						<label><input type="checkbox" name="softdock_settings[show_views]" value="1"<?php checked( 1, (int) softdock_setting( 'show_views' ) ); ?>> <?php esc_html_e( 'Views', 'softdock' ); ?></label>
					</td>
				</tr>
			</tbody></table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/*
 * Views: one per visit to a program page. Bots, previews and editors of the site are not counted.
 */
add_action( 'template_redirect', function () {
	if ( ! is_singular( 'software' ) || is_preview() || current_user_can( 'edit_posts' ) ) {
		return;
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	if ( ! $ua || preg_match( '/bot|crawl|spider|preview|slurp|facebookexternalhit|curl|wget/i', $ua ) ) {
		return;
	}
	softdock_increment_meta( get_queried_object_id(), 'sd_views' );
} );

/** Adds one to a counter in a single SQL statement, so simultaneous visits are all counted. */
function softdock_increment_meta( $post_id, $key ) {
	global $wpdb;
	$updated = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->postmeta} SET meta_value = CAST(meta_value AS UNSIGNED) + 1 WHERE post_id = %d AND meta_key = %s",
		$post_id,
		$key
	) );
	if ( ! $updated ) {
		add_post_meta( $post_id, $key, 1, true );
	}
	wp_cache_delete( $post_id, 'post_meta' );
}
