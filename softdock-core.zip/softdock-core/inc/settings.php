<?php
/**
 * Software → Settings: download buttons for all programs, and which counters visitors see.
 */

defined( 'ABSPATH' ) || exit;

function softdock_setting_defaults() {
	return array(
		'fast_label'     => __( 'Fast download', 'softdock' ),
		'fast_url'       => '',
		'direct_label'   => __( 'Direct download', 'softdock' ),
		'direct_url'     => '',
		'show_downloads' => 1,
		'show_views'     => 1,
	);
}

/** One setting, with its default when not saved yet. */
function softdock_setting( $key ) {
	$saved    = get_option( 'softdock_settings', array() );
	$defaults = softdock_setting_defaults();
	$value    = is_array( $saved ) && array_key_exists( $key, $saved ) ? $saved[ $key ] : ( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	if ( in_array( $key, array( 'fast_label', 'direct_label' ), true ) && '' === trim( (string) $value ) ) {
		$value = $defaults[ $key ];
	}
	return $value;
}

add_action( 'admin_init', function () {
	register_setting( 'softdock_settings', 'softdock_settings', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in = is_array( $in ) ? $in : array();
			return array(
				'fast_label'     => sanitize_text_field( isset( $in['fast_label'] ) ? $in['fast_label'] : '' ),
				'fast_url'       => esc_url_raw( isset( $in['fast_url'] ) ? trim( $in['fast_url'] ) : '', array( 'http', 'https' ) ),
				'direct_label'   => sanitize_text_field( isset( $in['direct_label'] ) ? $in['direct_label'] : '' ),
				'direct_url'     => esc_url_raw( isset( $in['direct_url'] ) ? trim( $in['direct_url'] ) : '', array( 'http', 'https' ) ),
				'show_downloads' => empty( $in['show_downloads'] ) ? 0 : 1,
				'show_views'     => empty( $in['show_views'] ) ? 0 : 1,
			);
		},
	) );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Softdock settings', 'softdock' ), __( 'Settings', 'softdock' ), 'manage_options', 'softdock-settings', 'softdock_render_settings' );
} );

function softdock_render_settings() {
	$v = function ( $key ) {
		return softdock_setting( $key );
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Softdock settings', 'softdock' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_settings' ); ?>

			<h2><?php esc_html_e( 'Download buttons', 'softdock' ); ?></h2>
			<p><?php esc_html_e( 'Set the text of the Fast and Direct buttons. Add a link here to use it on every program, for example an ad or affiliate page. Change it here and every program changes at once. Leave the link empty to use each program’s own link.', 'softdock' ); ?></p>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Fast download (black)', 'softdock' ); ?></th>
					<td>
						<p><label for="sd_fast_label"><?php esc_html_e( 'Button text', 'softdock' ); ?></label><br>
						<input type="text" class="regular-text" id="sd_fast_label" name="softdock_settings[fast_label]" value="<?php echo esc_attr( $v( 'fast_label' ) ); ?>"></p>
						<p><label for="sd_fast_url"><?php esc_html_e( 'Link for all programs', 'softdock' ); ?></label><br>
						<input type="url" class="large-text" id="sd_fast_url" name="softdock_settings[fast_url]" value="<?php echo esc_attr( $v( 'fast_url' ) ); ?>" placeholder="https://"></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Direct download (yellow)', 'softdock' ); ?></th>
					<td>
						<p><label for="sd_direct_label"><?php esc_html_e( 'Button text', 'softdock' ); ?></label><br>
						<input type="text" class="regular-text" id="sd_direct_label" name="softdock_settings[direct_label]" value="<?php echo esc_attr( $v( 'direct_label' ) ); ?>"></p>
						<p><label for="sd_direct_url"><?php esc_html_e( 'Link for all programs', 'softdock' ); ?></label><br>
						<input type="url" class="large-text" id="sd_direct_url" name="softdock_settings[direct_url]" value="<?php echo esc_attr( $v( 'direct_url' ) ); ?>" placeholder="https://"></p>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Counters', 'softdock' ); ?></h2>
			<p><?php esc_html_e( 'Downloads and views are always counted. These only choose whether visitors see them.', 'softdock' ); ?></p>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Show on the site', 'softdock' ); ?></th>
					<td>
						<input type="hidden" name="softdock_settings[show_downloads]" value="0">
						<label><input type="checkbox" name="softdock_settings[show_downloads]" value="1"<?php checked( 1, (int) $v( 'show_downloads' ) ); ?>> <?php esc_html_e( 'Total downloads', 'softdock' ); ?></label><br>
						<input type="hidden" name="softdock_settings[show_views]" value="0">
						<label><input type="checkbox" name="softdock_settings[show_views]" value="1"<?php checked( 1, (int) $v( 'show_views' ) ); ?>> <?php esc_html_e( 'Views', 'softdock' ); ?></label>
					</td>
				</tr>
			</tbody></table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/*
 * Views: one per visit to a program page. Bots, previews and editors of the site are not counted.
 */
add_action( 'template_redirect', function () {
	if ( ! is_singular( 'software' ) || is_preview() || current_user_can( 'edit_posts' ) ) {
		return;
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	if ( ! $ua || preg_match( '/bot|crawl|spider|preview|slurp|facebookexternalhit|curl|wget/i', $ua ) ) {
		return;
	}
	softdock_increment_meta( get_queried_object_id(), 'sd_views' );
} );

/** Adds one to a counter in a single SQL statement, so simultaneous visits are all counted. */
function softdock_increment_meta( $post_id, $key ) {
	global $wpdb;
	$updated = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->postmeta} SET meta_value = CAST(meta_value AS UNSIGNED) + 1 WHERE post_id = %d AND meta_key = %s",
		$post_id,
		$key
	) );
	if ( ! $updated ) {
		add_post_meta( $post_id, $key, 1, true );
	}
	wp_cache_delete( $post_id, 'post_meta' );
}
