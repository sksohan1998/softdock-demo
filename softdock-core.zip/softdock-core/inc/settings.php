<?php
/**
 * Software → Settings: download buttons for all programs, and which counters visitors see.
 */

defined( 'ABSPATH' ) || exit;

function softdock_setting_defaults() {
	return array(
		'magnet_label'   => __( 'Magnet download', 'softdock' ),
		'show_magnet'    => 1,
		'show_fast'      => 1,
		'show_direct'    => 1,
		'fast_label'     => __( 'Fast download', 'softdock' ),
		'fast_url'       => '',
		'direct_label'   => __( 'Direct download', 'softdock' ),
		'direct_url'     => '',
		'show_downloads' => 1,
		'show_views'     => 1,
	);
}

/** One setting, with its default when not saved yet. */
function softdock_setting( $key ) {
	$saved    = get_option( 'softdock_settings', array() );
	$defaults = softdock_setting_defaults();
	$value    = is_array( $saved ) && array_key_exists( $key, $saved ) ? $saved[ $key ] : ( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	if ( in_array( $key, array( 'magnet_label', 'fast_label', 'direct_label' ), true ) && '' === trim( (string) $value ) ) {
		$value = $defaults[ $key ];
	}
	return $value;
}

add_action( 'admin_init', function () {
	register_setting( 'softdock_settings', 'softdock_settings', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in  = is_array( $in ) ? $in : array();
			$old = get_option( 'softdock_settings', array() );
			$old = is_array( $old ) ? $old : array();
			// Each settings page sends only its own fields; keep the others as they were.
			$page = isset( $in['_page'] ) ? $in['_page'] : '';
			if ( 'counters' === $page ) {
				foreach ( array( 'magnet_label', 'fast_label', 'fast_url', 'direct_label', 'direct_url', 'show_magnet', 'show_fast', 'show_direct' ) as $k ) {
					$in[ $k ] = isset( $old[ $k ] ) ? $old[ $k ] : ( 0 === strpos( $k, 'show_' ) ? 1 : '' );
				}
			}
			return array(
				'magnet_label'   => sanitize_text_field( isset( $in['magnet_label'] ) ? $in['magnet_label'] : '' ),
				'show_magnet'    => empty( $in['show_magnet'] ) ? 0 : 1,
				'show_fast'      => empty( $in['show_fast'] ) ? 0 : 1,
				'show_direct'    => empty( $in['show_direct'] ) ? 0 : 1,
				'fast_label'     => sanitize_text_field( isset( $in['fast_label'] ) ? $in['fast_label'] : '' ),
				'fast_url'       => esc_url_raw( isset( $in['fast_url'] ) ? trim( $in['fast_url'] ) : '', array( 'http', 'https' ) ),
				'direct_label'   => sanitize_text_field( isset( $in['direct_label'] ) ? $in['direct_label'] : '' ),
				'direct_url'     => esc_url_raw( isset( $in['direct_url'] ) ? trim( $in['direct_url'] ) : '', array( 'http', 'https' ) ),
				'show_downloads' => empty( $in['show_downloads'] ) ? 0 : 1,
				'show_views'     => empty( $in['show_views'] ) ? 0 : 1,
			);
		},
	) );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Download links', 'softdock' ), __( 'Download links', 'softdock' ), 'manage_options', 'softdock-links', 'softdock_render_links' );
	add_submenu_page( 'edit.php?post_type=software', __( 'Softdock settings', 'softdock' ), __( 'Settings', 'softdock' ), 'manage_options', 'softdock-settings', 'softdock_render_settings' );
} );

function softdock_render_links() {
	$check = function ( $key, $label ) {
		echo '<input type="hidden" name="softdock_settings[' . esc_attr( $key ) . ']" value="0">';
		echo '<label><input type="checkbox" name="softdock_settings[' . esc_attr( $key ) . ']" value="1"' . checked( 1, (int) softdock_setting( $key ), false ) . '> ' . esc_html( $label ) . '</label>';
	};
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Download links', 'softdock' ); ?></h1>
		<p><?php esc_html_e( 'Choose which download buttons visitors see, and their text. The Fast and Direct buttons can use one link for every program, for example an ad or affiliate page: change it here and every program changes.', 'softdock' ); ?></p>
		<p><?php esc_html_e( 'When a program has no link for a button, the button uses the program’s uploaded file or official website.', 'softdock' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_settings' ); ?>
			<input type="hidden" name="softdock_settings[_page]" value="links">
			<table class="form-table" role="presentation"><tbody>
				<?php
				foreach ( array(
					'magnet' => __( 'Magnet download button (green)', 'softdock' ),
					'fast'   => __( 'Fast download button (black)', 'softdock' ),
					'direct' => __( 'Direct download button (yellow)', 'softdock' ),
				) as $type => $title ) :
					?>
					<tr>
						<th scope="row"><?php echo esc_html( $title ); ?></th>
						<td>
							<p><?php $check( 'show_' . $type, __( 'Show this button', 'softdock' ) ); ?></p>
							<p><label for="sd_<?php echo esc_attr( $type ); ?>_label"><?php esc_html_e( 'Button text', 'softdock' ); ?></label><br>
							<input type="text" class="regular-text" id="sd_<?php echo esc_attr( $type ); ?>_label" name="softdock_settings[<?php echo esc_attr( $type ); ?>_label]" value="<?php echo esc_attr( softdock_setting( $type . '_label' ) ); ?>"></p>
							<?php if ( 'magnet' !== $type ) : ?>
								<p><label for="sd_<?php echo esc_attr( $type ); ?>_url"><?php esc_html_e( 'Link for all programs (ads / affiliate)', 'softdock' ); ?></label><br>
								<input type="url" class="large-text" id="sd_<?php echo esc_attr( $type ); ?>_url" name="softdock_settings[<?php echo esc_attr( $type ); ?>_url]" value="<?php echo esc_attr( softdock_setting( $type . '_url' ) ); ?>" placeholder="https://"></p>
								<p class="description"><?php esc_html_e( 'Empty: each program uses the link typed on its own page.', 'softdock' ); ?></p>
							<?php else : ?>
								<p class="description"><?php esc_html_e( 'Each program has its own magnet link, typed on its page.', 'softdock' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Counters on the site', 'softdock' ); ?></th>
					<td>
						<?php $check( 'show_downloads', __( 'Show total downloads', 'softdock' ) ); ?><br>
						<?php $check( 'show_views', __( 'Show views', 'softdock' ) ); ?>
						<p class="description"><?php esc_html_e( 'Hidden counters keep counting; visitors just do not see them.', 'softdock' ); ?></p>
					</td>
				</tr>
			</tbody></table>
			<?php submit_button( __( 'Save', 'softdock' ) ); ?>
		</form>
	</div>
	<?php
}

function softdock_render_settings() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Softdock settings', 'softdock' ); ?></h1>
		<p><?php esc_html_e( 'Downloads and views are always counted. These only choose whether visitors see them.', 'softdock' ); ?>
			<?php /* translators: %s: link to the Download links page */ ?>
			<?php printf( esc_html__( 'Button text and shared links are under %s.', 'softdock' ), '<a href="' . esc_url( admin_url( 'edit.php?post_type=software&page=softdock-links' ) ) . '">' . esc_html__( 'Download links', 'softdock' ) . '</a>' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_settings' ); ?>
			<input type="hidden" name="softdock_settings[_page]" value="counters">
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Show on the site', 'softdock' ); ?></th>
					<td>
						<input type="hidden" name="softdock_settings[show_downloads]" value="0">
						<label><input type="checkbox" name="softdock_settings[show_downloads]" value="1"<?php checked( 1, (int) softdock_setting( 'show_downloads' ) ); ?>> <?php esc_html_e( 'Total downloads', 'softdock' ); ?></label><br>
						<input type="hidden" name="softdock_settings[show_views]" value="0">
						<label><input type="checkbox" name="softdock_settings[show_views]" value="1"<?php checked( 1, (int) softdock_setting( 'show_views' ) ); ?>> <?php esc_html_e( 'Views', 'softdock' ); ?></label>
					</td>
				</tr>
			</tbody></table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/*
 * Views: one per visit to a program page. Bots, previews and editors of the site are not counted.
 */
add_action( 'template_redirect', function () {
	if ( ! is_singular( 'software' ) || is_preview() || current_user_can( 'edit_posts' ) ) {
		return;
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	if ( ! $ua || preg_match( '/bot|crawl|spider|preview|slurp|facebookexternalhit|curl|wget/i', $ua ) ) {
		return;
	}
	softdock_increment_meta( get_queried_object_id(), 'sd_views' );
} );

/** Adds one to a counter in a single SQL statement, so simultaneous visits are all counted. */
function softdock_increment_meta( $post_id, $key ) {
	global $wpdb;
	$updated = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->postmeta} SET meta_value = CAST(meta_value AS UNSIGNED) + 1 WHERE post_id = %d AND meta_key = %s",
		$post_id,
		$key
	) );
	if ( ! $updated ) {
		add_post_meta( $post_id, $key, 1, true );
	}
	wp_cache_delete( $post_id, 'post_meta' );
}
