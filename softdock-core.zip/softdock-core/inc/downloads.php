<?php
/**
 * Download links: count the click, then send the visitor to the hosted file or the official site.
 */

defined( 'ABSPATH' ) || exit;

/** Where the Download button leads: the uploaded file when set, otherwise the official page. */
function softdock_download_target( $post_id ) {
	$file = absint( get_post_meta( $post_id, 'sd_file', true ) );
	if ( $file ) {
		$url = wp_get_attachment_url( $file );
		if ( $url ) {
			return $url;
		}
	}
	$url = get_post_meta( $post_id, 'sd_official_url', true );
	return wp_http_validate_url( $url ) ? $url : '';
}

function softdock_download_url( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	return add_query_arg( 'sd_go', $post_id, home_url( '/' ) );
}

add_action( 'template_redirect', function () {
	if ( empty( $_GET['sd_go'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$post_id = absint( $_GET['sd_go'] ); // phpcs:ignore WordPress.Security.NonceVerification
	$post    = get_post( $post_id );
	$url     = ( $post && 'software' === $post->post_type && 'publish' === $post->post_status ) ? softdock_download_target( $post_id ) : '';
	if ( ! $url ) {
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}
	// Bots and link previews should not inflate the count.
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	if ( $ua && ! preg_match( '/bot|crawl|spider|preview|slurp|facebookexternalhit|curl|wget/i', $ua ) ) {
		softdock_increment_downloads( $post_id );
	}
	nocache_headers();
	header( 'X-Robots-Tag: noindex', true );
	wp_redirect( $url, 302, 'Softdock' ); // phpcs:ignore WordPress.Security.SafeRedirect -- URL is set by an editor and validated above.
	exit;
} );

/** Adds one download in a single SQL statement, so simultaneous clicks are all counted. */
function softdock_increment_downloads( $post_id ) {
	global $wpdb;
	$updated = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->postmeta} SET meta_value = CAST(meta_value AS UNSIGNED) + 1 WHERE post_id = %d AND meta_key = 'sd_downloads'",
		$post_id
	) );
	if ( ! $updated ) {
		add_post_meta( $post_id, 'sd_downloads', 1, true );
	}
	wp_cache_delete( $post_id, 'post_meta' );
}
