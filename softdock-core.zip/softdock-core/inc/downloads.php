<?php
/**
 * Download links: count the click, then send the visitor to the hosted file or the official site.
 */

defined( 'ABSPATH' ) || exit;

/** Download buttons in display order: type => label. */
function softdock_download_types() {
	return array(
		'magnet' => __( 'Magnet download', 'softdock' ),
		'fast'   => softdock_setting( 'fast_label' ),
		'direct' => softdock_setting( 'direct_label' ),
	);
}

/**
 * Where a download button leads.
 * magnet: the magnet link. fast: the fast link. direct: the direct link, else the uploaded file.
 * No type (older links): the uploaded file, else the official website.
 */
function softdock_download_target( $post_id, $type = '' ) {
	if ( 'magnet' === $type ) {
		$url = (string) get_post_meta( $post_id, 'sd_magnet_url', true );
		return 0 === stripos( $url, 'magnet:?' ) ? $url : '';
	}
	// A link in Software → Settings is used for every program.
	if ( 'fast' === $type || 'direct' === $type ) {
		$global = softdock_setting( $type . '_url' );
		if ( wp_http_validate_url( $global ) ) {
			return $global;
		}
	}
	if ( 'fast' === $type ) {
		$url = get_post_meta( $post_id, 'sd_fast_url', true );
		return wp_http_validate_url( $url ) ? $url : '';
	}
	if ( 'direct' === $type ) {
		$url = get_post_meta( $post_id, 'sd_direct_url', true );
		if ( wp_http_validate_url( $url ) ) {
			return $url;
		}
	}
	$file = absint( get_post_meta( $post_id, 'sd_file', true ) );
	if ( $file ) {
		$url = wp_get_attachment_url( $file );
		if ( $url ) {
			return $url;
		}
	}
	if ( 'direct' === $type ) {
		return '';
	}
	$url = get_post_meta( $post_id, 'sd_official_url', true );
	return wp_http_validate_url( $url ) ? $url : '';
}

/** The buttons a program has: type => target URL. Falls back to one Direct button for the official site. */
function softdock_download_buttons( $post_id ) {
	$out = array();
	foreach ( array_keys( softdock_download_types() ) as $type ) {
		$url = softdock_download_target( $post_id, $type );
		if ( $url ) {
			$out[ $type ] = $url;
		}
	}
	if ( ! $out ) {
		$url = softdock_download_target( $post_id );
		if ( $url ) {
			$out['direct'] = $url;
		}
	}
	return $out;
}

function softdock_download_url( $post_id = null, $type = '' ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$args    = array( 'sd_go' => $post_id );
	if ( $type ) {
		$args['sd_type'] = $type;
	}
	return add_query_arg( $args, home_url( '/' ) );
}

add_action( 'template_redirect', function () {
	if ( empty( $_GET['sd_go'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$post_id = absint( $_GET['sd_go'] ); // phpcs:ignore WordPress.Security.NonceVerification
	$post    = get_post( $post_id );
	$type    = isset( $_GET['sd_type'] ) ? sanitize_key( $_GET['sd_type'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$buttons = ( $post && 'software' === $post->post_type && 'publish' === $post->post_status ) ? softdock_download_buttons( $post_id ) : array();
	$url     = $type ? ( isset( $buttons[ $type ] ) ? $buttons[ $type ] : '' ) : softdock_download_target( $post_id );
	if ( ! $url ) {
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}
	// Bots and link previews should not inflate the count.
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	if ( $ua && ! preg_match( '/bot|crawl|spider|preview|slurp|facebookexternalhit|curl|wget/i', $ua ) ) {
		softdock_increment_downloads( $post_id );
	}
	// Magnet buttons link straight to the magnet: address and only report the click here.
	if ( isset( $_GET['sd_count'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		status_header( 204 );
		exit;
	}
	nocache_headers();
	header( 'X-Robots-Tag: noindex', true );
	wp_redirect( $url, 302, 'Softdock' ); // phpcs:ignore WordPress.Security.SafeRedirect -- URL is set by an editor and validated above.
	exit;
} );

/** Adds one download in a single SQL statement, so simultaneous clicks are all counted. */
function softdock_increment_downloads( $post_id ) {
	global $wpdb;
	$updated = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->postmeta} SET meta_value = CAST(meta_value AS UNSIGNED) + 1 WHERE post_id = %d AND meta_key = 'sd_downloads'",
		$post_id
	) );
	if ( ! $updated ) {
		add_post_meta( $post_id, 'sd_downloads', 1, true );
	}
	wp_cache_delete( $post_id, 'post_meta' );
}
