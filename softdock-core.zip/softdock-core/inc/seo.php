<?php
/**
 * Search engine details for program pages: description and SoftwareApplication data.
 * Skipped when an SEO plugin that writes its own description is active.
 */

defined( 'ABSPATH' ) || exit;

function softdock_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\Load' );
}

add_action( 'wp_head', function () {
	if ( ! is_singular( 'software' ) ) {
		return;
	}
	$pid     = get_queried_object_id();
	$tagline = get_post_meta( $pid, 'sd_tagline', true );
	$desc    = $tagline ? $tagline : wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $pid ) ), 30, '…' );

	if ( ! softdock_seo_plugin_active() && $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( get_the_title( $pid ) ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( get_permalink( $pid ) ) . '">' . "\n";
		if ( has_post_thumbnail( $pid ) ) {
			echo '<meta property="og:image" content="' . esc_url( get_the_post_thumbnail_url( $pid, 'large' ) ) . '">' . "\n";
		}
	}

	$os = array();
	foreach ( (array) get_the_terms( $pid, 'platform' ) as $t ) {
		if ( $t instanceof WP_Term && 'games' !== $t->slug ) {
			$os[] = $t->name;
		}
	}
	$cats = get_the_terms( $pid, 'software_cat' );
	$data = array(
		'@context'            => 'https://schema.org',
		'@type'               => 'SoftwareApplication',
		'name'                => get_the_title( $pid ),
		'url'                 => get_permalink( $pid ),
		'description'         => $desc,
		'softwareVersion'     => get_post_meta( $pid, 'sd_version', true ),
		'operatingSystem'     => implode( ', ', $os ),
		'applicationCategory' => ( $cats && ! is_wp_error( $cats ) ) ? $cats[0]->name : null,
		'dateModified'        => get_post_modified_time( 'c', true, $pid ),
		'offers'              => array( '@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'USD' ),
	);
	$size = (float) get_post_meta( $pid, 'sd_size_mb', true );
	if ( $size > 0 ) {
		$data['fileSize'] = round( $size ) . 'MB';
	}
	$count = (int) get_post_meta( $pid, 'sd_rating_count', true );
	if ( $count > 0 ) {
		$data['aggregateRating'] = array(
			'@type'       => 'AggregateRating',
			'ratingValue' => round( (float) get_post_meta( $pid, 'sd_rating', true ), 1 ),
			'ratingCount' => $count,
			'bestRating'  => 5,
		);
	}
	if ( has_post_thumbnail( $pid ) ) {
		$data['image'] = get_the_post_thumbnail_url( $pid, 'large' );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array_filter( $data ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
} );
