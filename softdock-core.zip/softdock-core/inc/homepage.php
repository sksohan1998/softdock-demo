<?php
/**
 * Software → Homepage: what the homepage shows, in which order, the Popular list on the
 * right side, and which parts of the header are shown. The header menu itself is edited in
 * Appearance → Menus (location "Header menu").
 */

defined( 'ABSPATH' ) || exit;

function softdock_home_defaults() {
	return array(
		'latest_show'    => 1,
		'latest_title'   => __( 'Latest programs', 'softdock' ),
		'latest_count'   => 6,
		'section_order'  => 'latest', // latest | downloads | views | rating.
		'section_count'  => 6,
		'sections'       => array(), // term_id => [ show, title, order ].
		'popular_show'   => 1,
		'popular_title'  => __( 'Popular downloads', 'softdock' ),
		'popular_count'  => 8,
		'popular_by'     => 'downloads', // downloads | views | rating.
		'popular_pages'  => 'home', // home | all (also on program and list pages).
		'popular_cat'    => 0, // Only programs in this category (0 = all).
		'cats_show'      => 1,
		'cats_title'     => __( 'Categories', 'softdock' ),
		'cats_count'     => 10,
		'banner_show'    => 0,
		'banner_image'   => 0,
		'banner_link'    => '',
		'banner_newtab'  => 1,
		'order_popular'  => 1,
		'order_cats'     => 2,
		'order_banner'   => 3,
		'show_search'    => 1,
		'show_cats'      => 1,
		'show_theme_btn' => 1,
	);
}

/** One homepage setting, with its default. */
function softdock_home( $key ) {
	$saved = get_option( 'softdock_home', array() );
	$def   = softdock_home_defaults();
	if ( is_array( $saved ) && array_key_exists( $key, $saved ) ) {
		$v = $saved[ $key ];
		if ( in_array( $key, array( 'latest_title', 'popular_title', 'cats_title' ), true ) && '' === trim( (string) $v ) ) {
			return $def[ $key ];
		}
		return $v;
	}
	return isset( $def[ $key ] ) ? $def[ $key ] : '';
}

/** Platform sections in the order chosen on the Homepage page, with their settings. */
function softdock_home_sections() {
	$saved = softdock_home( 'sections' );
	$saved = is_array( $saved ) ? $saved : array();
	$out   = array();
	$i     = 0;
	foreach ( softdock_platforms() as $t ) {
		$s     = isset( $saved[ $t->term_id ] ) ? $saved[ $t->term_id ] : array();
		$out[] = array(
			'term'  => $t,
			'show'  => isset( $s['show'] ) ? (int) $s['show'] : 1,
			'title' => isset( $s['title'] ) && '' !== trim( $s['title'] ) ? $s['title'] : $t->name,
			'order' => isset( $s['order'] ) ? (int) $s['order'] : ++$i * 10,
		);
	}
	usort( $out, function ( $a, $b ) {
		return $a['order'] - $b['order'];
	} );
	return $out;
}

/** Programs ordered for a homepage list: latest, downloads, views or rating. */
function softdock_home_query( $by, $count, $platform = '', $cat = 0 ) {
	$args = array(
		'post_type'           => 'software',
		'posts_per_page'      => max( 1, (int) $count ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);
	$keys = array( 'downloads' => 'sd_downloads', 'views' => 'sd_views', 'rating' => 'sd_rating' );
	if ( isset( $keys[ $by ] ) && function_exists( 'softdock_meta_order_clause' ) ) {
		$args['meta_query'] = softdock_meta_order_clause( $keys[ $by ] );
		$args['orderby']    = array( 'has' => 'DESC', 'date' => 'DESC' );
	} else {
		$args['orderby'] = array( 'date' => 'DESC', 'ID' => 'DESC' );
	}
	if ( $platform ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'platform', 'field' => 'slug', 'terms' => $platform ) );
	}
	if ( $cat ) {
		$args['tax_query']   = isset( $args['tax_query'] ) ? $args['tax_query'] : array();
		$args['tax_query'][] = array( 'taxonomy' => 'software_cat', 'field' => 'term_id', 'terms' => (int) $cat );
	}
	return new WP_Query( $args );
}

add_action( 'admin_init', function () {
	register_setting( 'softdock_home', 'softdock_home', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in    = is_array( $in ) ? $in : array();
			$def   = softdock_home_defaults();
			$num   = function ( $k, $min, $max ) use ( $in, $def ) {
				$n = isset( $in[ $k ] ) ? absint( $in[ $k ] ) : $def[ $k ];
				return min( $max, max( $min, $n ) );
			};
			$pick  = function ( $k, $allowed ) use ( $in, $def ) {
				return isset( $in[ $k ] ) && in_array( $in[ $k ], $allowed, true ) ? $in[ $k ] : $def[ $k ];
			};
			$secs = array();
			if ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
				foreach ( $in['sections'] as $tid => $s ) {
					$secs[ absint( $tid ) ] = array(
						'show'  => empty( $s['show'] ) ? 0 : 1,
						'title' => isset( $s['title'] ) ? sanitize_text_field( $s['title'] ) : '',
						'order' => isset( $s['order'] ) ? (int) $s['order'] : 0,
					);
				}
			}
			return array(
				'latest_show'    => empty( $in['latest_show'] ) ? 0 : 1,
				'latest_title'   => isset( $in['latest_title'] ) ? sanitize_text_field( $in['latest_title'] ) : '',
				'latest_count'   => $num( 'latest_count', 1, 30 ),
				'section_order'  => $pick( 'section_order', array( 'latest', 'downloads', 'views', 'rating' ) ),
				'section_count'  => $num( 'section_count', 1, 30 ),
				'sections'       => $secs,
				'popular_show'   => empty( $in['popular_show'] ) ? 0 : 1,
				'popular_title'  => isset( $in['popular_title'] ) ? sanitize_text_field( $in['popular_title'] ) : '',
				'popular_count'  => $num( 'popular_count', 1, 20 ),
				'popular_by'     => $pick( 'popular_by', array( 'downloads', 'views', 'rating', 'latest' ) ),
				'popular_pages'  => $pick( 'popular_pages', array( 'home', 'all' ) ),
				'popular_cat'    => isset( $in['popular_cat'] ) ? absint( $in['popular_cat'] ) : 0,
				'cats_show'      => empty( $in['cats_show'] ) ? 0 : 1,
				'cats_title'     => isset( $in['cats_title'] ) ? sanitize_text_field( $in['cats_title'] ) : '',
				'cats_count'     => $num( 'cats_count', 1, 50 ),
				'banner_show'    => empty( $in['banner_show'] ) ? 0 : 1,
				'banner_image'   => isset( $in['banner_image'] ) ? absint( $in['banner_image'] ) : 0,
				'banner_link'    => isset( $in['banner_link'] ) ? esc_url_raw( trim( $in['banner_link'] ), array( 'http', 'https' ) ) : '',
				'banner_newtab'  => empty( $in['banner_newtab'] ) ? 0 : 1,
				'order_popular'  => $num( 'order_popular', 1, 3 ),
				'order_cats'     => $num( 'order_cats', 1, 3 ),
				'order_banner'   => $num( 'order_banner', 1, 3 ),
				'show_search'    => empty( $in['show_search'] ) ? 0 : 1,
				'show_cats'      => empty( $in['show_cats'] ) ? 0 : 1,
				'show_theme_btn' => empty( $in['show_theme_btn'] ) ? 0 : 1,
			);
		},
	) );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Homepage', 'softdock' ), __( 'Homepage', 'softdock' ), 'manage_options', 'softdock-home', 'softdock_render_home_page' );
}, 11 );

function softdock_render_home_page() {
	$h     = function ( $k ) {
		return softdock_home( $k );
	};
	$check = function ( $name, $on, $label ) {
		echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="0">';
		echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( 1, (int) $on, false ) . '> ' . esc_html( $label ) . '</label>';
	};
	$orders = array(
		'latest'    => __( 'Latest first', 'softdock' ),
		'downloads' => __( 'Most downloaded first', 'softdock' ),
		'views'     => __( 'Most viewed first', 'softdock' ),
		'rating'    => __( 'Top rated first', 'softdock' ),
	);
	$select = function ( $name, $value, $options ) {
		echo '<select name="' . esc_attr( $name ) . '">';
		foreach ( $options as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $value, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	};
	?>
	<div class="wrap sd-home-admin">
		<h1><?php esc_html_e( 'Homepage', 'softdock' ); ?></h1>
		<p><?php esc_html_e( 'Choose what the homepage shows. Changes appear on the site as soon as you save.', 'softdock' ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank"><?php esc_html_e( 'View homepage ↗', 'softdock' ); ?></a></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_home' ); ?>

			<h2><?php esc_html_e( 'Header', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Menu', 'softdock' ); ?></th>
					<td>
						<?php if ( has_nav_menu( 'header' ) ) : ?>
							<p><?php esc_html_e( 'The header shows your own menu.', 'softdock' ); ?></p>
						<?php else : ?>
							<p><?php esc_html_e( 'The header shows the platform tabs (Windows, macOS…).', 'softdock' ); ?></p>
						<?php endif; ?>
						<p class="description"><?php esc_html_e( 'To add, remove, rename or reorder menu items, make a menu and tick "Header menu" as its location. Without one, the platform tabs are shown.', 'softdock' ); ?></p>
						<p><a class="button" href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>"><?php esc_html_e( 'Edit the header menu', 'softdock' ); ?></a></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Show in the header', 'softdock' ); ?></th>
					<td>
						<?php $check( 'softdock_home[show_search]', $h( 'show_search' ), __( 'Search box', 'softdock' ) ); ?><br>
						<?php $check( 'softdock_home[show_cats]', $h( 'show_cats' ), __( 'Categories button', 'softdock' ) ); ?><br>
						<?php $check( 'softdock_home[show_theme_btn]', $h( 'show_theme_btn' ), __( 'Light / dark mode button', 'softdock' ) ); ?>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Latest programs (top of the page)', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Section', 'softdock' ); ?></th>
					<td>
						<p><?php $check( 'softdock_home[latest_show]', $h( 'latest_show' ), __( 'Show this section', 'softdock' ) ); ?></p>
						<p><label><?php esc_html_e( 'Heading', 'softdock' ); ?><br><input type="text" class="regular-text" name="softdock_home[latest_title]" value="<?php echo esc_attr( $h( 'latest_title' ) ); ?>"></label></p>
						<p><label><?php esc_html_e( 'How many programs', 'softdock' ); ?> <input type="number" min="1" max="30" class="small-text" name="softdock_home[latest_count]" value="<?php echo (int) $h( 'latest_count' ); ?>"></label></p>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Platform sections', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'All sections', 'softdock' ); ?></th>
					<td>
						<p><label><?php esc_html_e( 'Order programs by', 'softdock' ); ?> <?php $select( 'softdock_home[section_order]', $h( 'section_order' ), $orders ); ?></label></p>
						<p><label><?php esc_html_e( 'Programs per section', 'softdock' ); ?> <input type="number" min="1" max="30" class="small-text" name="softdock_home[section_count]" value="<?php echo (int) $h( 'section_count' ); ?>"></label></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Each section', 'softdock' ); ?></th>
					<td>
						<table class="widefat striped" style="max-width:640px">
							<thead><tr><th><?php esc_html_e( 'Show', 'softdock' ); ?></th><th><?php esc_html_e( 'Platform', 'softdock' ); ?></th><th><?php esc_html_e( 'Heading', 'softdock' ); ?></th><th><?php esc_html_e( 'Position', 'softdock' ); ?></th></tr></thead>
							<tbody>
							<?php foreach ( softdock_home_sections() as $n => $sec ) : ?>
								<?php $tid = (int) $sec['term']->term_id; ?>
								<tr>
									<td><input type="hidden" name="softdock_home[sections][<?php echo $tid; ?>][show]" value="0"><input type="checkbox" name="softdock_home[sections][<?php echo $tid; ?>][show]" value="1"<?php checked( 1, $sec['show'] ); ?> aria-label="<?php esc_attr_e( 'Show', 'softdock' ); ?>"></td>
									<td><?php echo esc_html( $sec['term']->name ); ?></td>
									<td><input type="text" name="softdock_home[sections][<?php echo $tid; ?>][title]" value="<?php echo esc_attr( $sec['title'] === $sec['term']->name ? '' : $sec['title'] ); ?>" placeholder="<?php echo esc_attr( $sec['term']->name ); ?>"></td>
									<td><input type="number" class="small-text" name="softdock_home[sections][<?php echo $tid; ?>][order]" value="<?php echo (int) ( ( $n + 1 ) * 10 ); ?>"></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
						<p class="description"><?php esc_html_e( 'Untick to hide a section. Leave the heading empty to use the platform name. Lower position numbers show first. New platforms (Software → Platforms) appear here automatically.', 'softdock' ); ?></p>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Right side', 'softdock' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Up to three blocks show on the right: the Popular list, a Categories box and a banner. Choose which ones and their order. On phones they show below the programs.', 'softdock' ); ?></p>
			<?php
			$pos = function ( $name, $value ) use ( $select ) {
				echo '<label>' . esc_html__( 'Position', 'softdock' ) . ' ';
				$select( $name, (string) $value, array( '1' => __( '1st', 'softdock' ), '2' => __( '2nd', 'softdock' ), '3' => __( '3rd', 'softdock' ) ) );
				echo '</label>';
			};
			$cat_opts = array( '0' => __( 'All categories', 'softdock' ) );
			foreach ( get_terms( array( 'taxonomy' => 'software_cat', 'hide_empty' => false ) ) as $t ) {
				if ( $t instanceof WP_Term ) {
					$cat_opts[ (string) $t->term_id ] = $t->name;
				}
			}
			$img = (int) $h( 'banner_image' );
			?>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Popular list', 'softdock' ); ?></th>
					<td>
						<p><?php $check( 'softdock_home[popular_show]', $h( 'popular_show' ), __( 'Show the list', 'softdock' ) ); ?> &nbsp; <?php $pos( 'softdock_home[order_popular]', $h( 'order_popular' ) ); ?></p>
						<p><label><?php esc_html_e( 'Heading', 'softdock' ); ?><br><input type="text" class="regular-text" name="softdock_home[popular_title]" value="<?php echo esc_attr( $h( 'popular_title' ) ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Show', 'softdock' ); ?> <?php $select( 'softdock_home[popular_by]', $h( 'popular_by' ), array( 'downloads' => __( 'Most downloaded', 'softdock' ), 'views' => __( 'Most viewed', 'softdock' ), 'rating' => __( 'Top rated', 'softdock' ), 'latest' => __( 'Latest uploads', 'softdock' ) ) ); ?></label>
						&nbsp; <label><?php esc_html_e( 'from', 'softdock' ); ?> <?php $select( 'softdock_home[popular_cat]', (string) $h( 'popular_cat' ), $cat_opts ); ?></label></p>
						<p><label><?php esc_html_e( 'How many programs', 'softdock' ); ?> <input type="number" min="1" max="20" class="small-text" name="softdock_home[popular_count]" value="<?php echo (int) $h( 'popular_count' ); ?>"></label></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Categories box', 'softdock' ); ?></th>
					<td>
						<p><?php $check( 'softdock_home[cats_show]', $h( 'cats_show' ), __( 'Show the box', 'softdock' ) ); ?> &nbsp; <?php $pos( 'softdock_home[order_cats]', $h( 'order_cats' ) ); ?></p>
						<p><label><?php esc_html_e( 'Heading', 'softdock' ); ?><br><input type="text" class="regular-text" name="softdock_home[cats_title]" value="<?php echo esc_attr( $h( 'cats_title' ) ); ?>"></label></p>
						<p><label><?php esc_html_e( 'How many categories', 'softdock' ); ?> <input type="number" min="1" max="50" class="small-text" name="softdock_home[cats_count]" value="<?php echo (int) $h( 'cats_count' ); ?>"></label></p>
						<p class="description"><?php esc_html_e( 'Shows the categories with the most programs, with their program counts.', 'softdock' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Banner', 'softdock' ); ?></th>
					<td>
						<p><?php $check( 'softdock_home[banner_show]', $h( 'banner_show' ), __( 'Show the banner', 'softdock' ) ); ?> &nbsp; <?php $pos( 'softdock_home[order_banner]', $h( 'order_banner' ) ); ?></p>
						<div class="sd-banner-pick">
							<input type="hidden" name="softdock_home[banner_image]" id="sd_banner_image" value="<?php echo $img ? (int) $img : ''; ?>">
							<div class="sd-banner-preview"><?php echo $img ? wp_get_attachment_image( $img, 'medium' ) : '<span>' . esc_html__( 'No image yet', 'softdock' ) . '</span>'; ?></div>
							<p><button type="button" class="button sd-banner-upload"><?php esc_html_e( 'Choose banner image', 'softdock' ); ?></button> <button type="button" class="button-link sd-banner-remove"<?php echo $img ? '' : ' hidden'; ?>><?php esc_html_e( 'Remove', 'softdock' ); ?></button></p>
						</div>
						<p><label><?php esc_html_e( 'Link when clicked (optional)', 'softdock' ); ?><br><input type="url" class="large-text" name="softdock_home[banner_link]" value="<?php echo esc_attr( $h( 'banner_link' ) ); ?>" placeholder="https://"></label></p>
						<p><?php $check( 'softdock_home[banner_newtab]', $h( 'banner_newtab' ), __( 'Open the link in a new tab', 'softdock' ) ); ?></p>
						<p class="description"><?php esc_html_e( 'About 300 px wide works best, for example 300×250 or 300×600.', 'softdock' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Where', 'softdock' ); ?></th>
					<td><?php $select( 'softdock_home[popular_pages]', $h( 'popular_pages' ), array( 'home' => __( 'Homepage only', 'softdock' ), 'all' => __( 'Homepage and list pages (platforms, categories, search)', 'softdock' ) ) ); ?></td>
				</tr>
			</tbody></table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false === strpos( (string) $hook, 'softdock-home' ) ) {
		return;
	}
	wp_enqueue_media();
	wp_add_inline_style( 'common', '.sd-banner-preview{max-width:300px;min-height:60px;border:1px dashed #c3c4c7;border-radius:6px;display:grid;place-items:center;overflow:hidden;background:#f6f7f7;color:#646970}.sd-banner-preview img{display:block;width:100%;height:auto}' );
	wp_add_inline_script( 'media-editor', 'jQuery(function($){var f;$(".sd-banner-upload").on("click",function(e){e.preventDefault();if(!f){f=wp.media({title:"Banner image",button:{text:"Use this image"},library:{type:"image"},multiple:false});f.on("select",function(){var a=f.state().get("selection").first().toJSON();$("#sd_banner_image").val(a.id);$(".sd-banner-preview").html($("<img alt=\"\">").attr("src",(a.sizes&&a.sizes.medium?a.sizes.medium:a).url));$(".sd-banner-remove").prop("hidden",false);});}f.open();});$(".sd-banner-remove").on("click",function(e){e.preventDefault();$("#sd_banner_image").val("");$(".sd-banner-preview").html("<span>No image yet</span>");$(this).prop("hidden",true);});});' );
} );
