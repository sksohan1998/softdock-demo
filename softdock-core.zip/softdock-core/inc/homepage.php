<?php
/**
 * Software → Homepage: what the homepage shows, in which order, the Popular list on the
 * right side, and which parts of the header are shown. The header menu itself is edited in
 * Appearance → Menus (location "Header menu").
 */

defined( 'ABSPATH' ) || exit;

function softdock_home_defaults() {
	return array(
		'latest_show'    => 1,
		'latest_title'   => __( 'Latest programs', 'softdock' ),
		'latest_count'   => 6,
		'section_order'  => 'latest', // latest | downloads | views | rating.
		'section_count'  => 6,
		'sections'       => array(), // term_id => [ show, title, order ].
		'popular_show'   => 1,
		'popular_title'  => __( 'Popular downloads', 'softdock' ),
		'popular_count'  => 8,
		'popular_by'     => 'downloads', // downloads | views | rating.
		'popular_pages'  => 'home', // home | all (also on program and list pages).
		'show_search'    => 1,
		'show_cats'      => 1,
		'show_theme_btn' => 1,
	);
}

/** One homepage setting, with its default. */
function softdock_home( $key ) {
	$saved = get_option( 'softdock_home', array() );
	$def   = softdock_home_defaults();
	if ( is_array( $saved ) && array_key_exists( $key, $saved ) ) {
		$v = $saved[ $key ];
		if ( in_array( $key, array( 'latest_title', 'popular_title' ), true ) && '' === trim( (string) $v ) ) {
			return $def[ $key ];
		}
		return $v;
	}
	return isset( $def[ $key ] ) ? $def[ $key ] : '';
}

/** Platform sections in the order chosen on the Homepage page, with their settings. */
function softdock_home_sections() {
	$saved = softdock_home( 'sections' );
	$saved = is_array( $saved ) ? $saved : array();
	$out   = array();
	$i     = 0;
	foreach ( softdock_platforms() as $t ) {
		$s     = isset( $saved[ $t->term_id ] ) ? $saved[ $t->term_id ] : array();
		$out[] = array(
			'term'  => $t,
			'show'  => isset( $s['show'] ) ? (int) $s['show'] : 1,
			'title' => isset( $s['title'] ) && '' !== trim( $s['title'] ) ? $s['title'] : $t->name,
			'order' => isset( $s['order'] ) ? (int) $s['order'] : ++$i * 10,
		);
	}
	usort( $out, function ( $a, $b ) {
		return $a['order'] - $b['order'];
	} );
	return $out;
}

/** Programs ordered for a homepage list: latest, downloads, views or rating. */
function softdock_home_query( $by, $count, $platform = '' ) {
	$args = array(
		'post_type'           => 'software',
		'posts_per_page'      => max( 1, (int) $count ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);
	$keys = array( 'downloads' => 'sd_downloads', 'views' => 'sd_views', 'rating' => 'sd_rating' );
	if ( isset( $keys[ $by ] ) && function_exists( 'softdock_meta_order_clause' ) ) {
		$args['meta_query'] = softdock_meta_order_clause( $keys[ $by ] );
		$args['orderby']    = array( 'has' => 'DESC', 'date' => 'DESC' );
	} else {
		$args['orderby'] = array( 'date' => 'DESC', 'ID' => 'DESC' );
	}
	if ( $platform ) {
		$args['tax_query'] = array( array( 'taxonomy' => 'platform', 'field' => 'slug', 'terms' => $platform ) );
	}
	return new WP_Query( $args );
}

add_action( 'admin_init', function () {
	register_setting( 'softdock_home', 'softdock_home', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in    = is_array( $in ) ? $in : array();
			$def   = softdock_home_defaults();
			$num   = function ( $k, $min, $max ) use ( $in, $def ) {
				$n = isset( $in[ $k ] ) ? absint( $in[ $k ] ) : $def[ $k ];
				return min( $max, max( $min, $n ) );
			};
			$pick  = function ( $k, $allowed ) use ( $in, $def ) {
				return isset( $in[ $k ] ) && in_array( $in[ $k ], $allowed, true ) ? $in[ $k ] : $def[ $k ];
			};
			$secs = array();
			if ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
				foreach ( $in['sections'] as $tid => $s ) {
					$secs[ absint( $tid ) ] = array(
						'show'  => empty( $s['show'] ) ? 0 : 1,
						'title' => isset( $s['title'] ) ? sanitize_text_field( $s['title'] ) : '',
						'order' => isset( $s['order'] ) ? (int) $s['order'] : 0,
					);
				}
			}
			return array(
				'latest_show'    => empty( $in['latest_show'] ) ? 0 : 1,
				'latest_title'   => isset( $in['latest_title'] ) ? sanitize_text_field( $in['latest_title'] ) : '',
				'latest_count'   => $num( 'latest_count', 1, 30 ),
				'section_order'  => $pick( 'section_order', array( 'latest', 'downloads', 'views', 'rating' ) ),
				'section_count'  => $num( 'section_count', 1, 30 ),
				'sections'       => $secs,
				'popular_show'   => empty( $in['popular_show'] ) ? 0 : 1,
				'popular_title'  => isset( $in['popular_title'] ) ? sanitize_text_field( $in['popular_title'] ) : '',
				'popular_count'  => $num( 'popular_count', 1, 20 ),
				'popular_by'     => $pick( 'popular_by', array( 'downloads', 'views', 'rating', 'latest' ) ),
				'popular_pages'  => $pick( 'popular_pages', array( 'home', 'all' ) ),
				'show_search'    => empty( $in['show_search'] ) ? 0 : 1,
				'show_cats'      => empty( $in['show_cats'] ) ? 0 : 1,
				'show_theme_btn' => empty( $in['show_theme_btn'] ) ? 0 : 1,
			);
		},
	) );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Homepage', 'softdock' ), __( 'Homepage', 'softdock' ), 'manage_options', 'softdock-home', 'softdock_render_home_page' );
}, 11 );

function softdock_render_home_page() {
	$h     = function ( $k ) {
		return softdock_home( $k );
	};
	$check = function ( $name, $on, $label ) {
		echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="0">';
		echo '<label><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( 1, (int) $on, false ) . '> ' . esc_html( $label ) . '</label>';
	};
	$orders = array(
		'latest'    => __( 'Latest first', 'softdock' ),
		'downloads' => __( 'Most downloaded first', 'softdock' ),
		'views'     => __( 'Most viewed first', 'softdock' ),
		'rating'    => __( 'Top rated first', 'softdock' ),
	);
	$select = function ( $name, $value, $options ) {
		echo '<select name="' . esc_attr( $name ) . '">';
		foreach ( $options as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $value, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	};
	?>
	<div class="wrap sd-home-admin">
		<h1><?php esc_html_e( 'Homepage', 'softdock' ); ?></h1>
		<p><?php esc_html_e( 'Choose what the homepage shows. Changes appear on the site as soon as you save.', 'softdock' ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank"><?php esc_html_e( 'View homepage ↗', 'softdock' ); ?></a></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'softdock_home' ); ?>

			<h2><?php esc_html_e( 'Header', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Menu', 'softdock' ); ?></th>
					<td>
						<?php if ( has_nav_menu( 'header' ) ) : ?>
							<p><?php esc_html_e( 'The header shows your own menu.', 'softdock' ); ?></p>
						<?php else : ?>
							<p><?php esc_html_e( 'The header shows the platform tabs (Windows, macOS…).', 'softdock' ); ?></p>
						<?php endif; ?>
						<p class="description"><?php esc_html_e( 'To add, remove, rename or reorder menu items, make a menu and tick "Header menu" as its location. Without one, the platform tabs are shown.', 'softdock' ); ?></p>
						<p><a class="button" href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>"><?php esc_html_e( 'Edit the header menu', 'softdock' ); ?></a></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Show in the header', 'softdock' ); ?></th>
					<td>
						<?php $check( 'softdock_home[show_search]', $h( 'show_search' ), __( 'Search box', 'softdock' ) ); ?><br>
						<?php $check( 'softdock_home[show_cats]', $h( 'show_cats' ), __( 'Categories button', 'softdock' ) ); ?><br>
						<?php $check( 'softdock_home[show_theme_btn]', $h( 'show_theme_btn' ), __( 'Light / dark mode button', 'softdock' ) ); ?>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Latest programs (top of the page)', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'Section', 'softdock' ); ?></th>
					<td>
						<p><?php $check( 'softdock_home[latest_show]', $h( 'latest_show' ), __( 'Show this section', 'softdock' ) ); ?></p>
						<p><label><?php esc_html_e( 'Heading', 'softdock' ); ?><br><input type="text" class="regular-text" name="softdock_home[latest_title]" value="<?php echo esc_attr( $h( 'latest_title' ) ); ?>"></label></p>
						<p><label><?php esc_html_e( 'How many programs', 'softdock' ); ?> <input type="number" min="1" max="30" class="small-text" name="softdock_home[latest_count]" value="<?php echo (int) $h( 'latest_count' ); ?>"></label></p>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Platform sections', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'All sections', 'softdock' ); ?></th>
					<td>
						<p><label><?php esc_html_e( 'Order programs by', 'softdock' ); ?> <?php $select( 'softdock_home[section_order]', $h( 'section_order' ), $orders ); ?></label></p>
						<p><label><?php esc_html_e( 'Programs per section', 'softdock' ); ?> <input type="number" min="1" max="30" class="small-text" name="softdock_home[section_count]" value="<?php echo (int) $h( 'section_count' ); ?>"></label></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Each section', 'softdock' ); ?></th>
					<td>
						<table class="widefat striped" style="max-width:640px">
							<thead><tr><th><?php esc_html_e( 'Show', 'softdock' ); ?></th><th><?php esc_html_e( 'Platform', 'softdock' ); ?></th><th><?php esc_html_e( 'Heading', 'softdock' ); ?></th><th><?php esc_html_e( 'Position', 'softdock' ); ?></th></tr></thead>
							<tbody>
							<?php foreach ( softdock_home_sections() as $n => $sec ) : ?>
								<?php $tid = (int) $sec['term']->term_id; ?>
								<tr>
									<td><input type="hidden" name="softdock_home[sections][<?php echo $tid; ?>][show]" value="0"><input type="checkbox" name="softdock_home[sections][<?php echo $tid; ?>][show]" value="1"<?php checked( 1, $sec['show'] ); ?> aria-label="<?php esc_attr_e( 'Show', 'softdock' ); ?>"></td>
									<td><?php echo esc_html( $sec['term']->name ); ?></td>
									<td><input type="text" name="softdock_home[sections][<?php echo $tid; ?>][title]" value="<?php echo esc_attr( $sec['title'] === $sec['term']->name ? '' : $sec['title'] ); ?>" placeholder="<?php echo esc_attr( $sec['term']->name ); ?>"></td>
									<td><input type="number" class="small-text" name="softdock_home[sections][<?php echo $tid; ?>][order]" value="<?php echo (int) ( ( $n + 1 ) * 10 ); ?>"></td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
						<p class="description"><?php esc_html_e( 'Untick to hide a section. Leave the heading empty to use the platform name. Lower position numbers show first. New platforms (Software → Platforms) appear here automatically.', 'softdock' ); ?></p>
					</td>
				</tr>
			</tbody></table>

			<h2><?php esc_html_e( 'Popular list (right side)', 'softdock' ); ?></h2>
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row"><?php esc_html_e( 'List', 'softdock' ); ?></th>
					<td>
						<p><?php $check( 'softdock_home[popular_show]', $h( 'popular_show' ), __( 'Show the list', 'softdock' ) ); ?></p>
						<p><label><?php esc_html_e( 'Heading', 'softdock' ); ?><br><input type="text" class="regular-text" name="softdock_home[popular_title]" value="<?php echo esc_attr( $h( 'popular_title' ) ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Show', 'softdock' ); ?> <?php $select( 'softdock_home[popular_by]', $h( 'popular_by' ), array( 'downloads' => __( 'Most downloaded', 'softdock' ), 'views' => __( 'Most viewed', 'softdock' ), 'rating' => __( 'Top rated', 'softdock' ), 'latest' => __( 'Latest uploads', 'softdock' ) ) ); ?></label></p>
						<p><label><?php esc_html_e( 'How many programs', 'softdock' ); ?> <input type="number" min="1" max="20" class="small-text" name="softdock_home[popular_count]" value="<?php echo (int) $h( 'popular_count' ); ?>"></label></p>
						<p><label><?php esc_html_e( 'Where', 'softdock' ); ?> <?php $select( 'softdock_home[popular_pages]', $h( 'popular_pages' ), array( 'home' => __( 'Homepage only', 'softdock' ), 'all' => __( 'Homepage and list pages (platforms, categories, search)', 'softdock' ) ) ); ?></label></p>
						<p class="description"><?php esc_html_e( 'On phones the list shows below the programs.', 'softdock' ); ?></p>
					</td>
				</tr>
			</tbody></table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
