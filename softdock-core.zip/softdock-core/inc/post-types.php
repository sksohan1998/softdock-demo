<?php
/**
 * Software post type, Platform and Category taxonomies.
 */

defined( 'ABSPATH' ) || exit;

/** Default platforms: slug => label. Order here is the order of the tab strip. */
function softdock_default_platforms() {
	return array(
		'windows' => 'Windows',
		'mac'     => 'macOS',
		'android' => 'Android',
		'linux'   => 'Linux',
		'games'   => 'Games',
	);
}

/** URL words for programs, platforms and categories (Software → Page URLs). */
function softdock_url_base( $which ) {
	$def   = array( 'program' => 'software', 'platform' => 'platform', 'category' => 'software-category' );
	$saved = get_option( 'softdock_urls', array() );
	$v     = is_array( $saved ) && ! empty( $saved[ $which ] ) ? $saved[ $which ] : $def[ $which ];
	return sanitize_title( $v ) ? sanitize_title( $v ) : $def[ $which ];
}

function softdock_register_types() {
	register_post_type( 'software', array(
		'labels'        => array(
			'name'          => __( 'Software', 'softdock' ),
			'singular_name' => __( 'Program', 'softdock' ),
			'add_new_item'  => __( 'Add program', 'softdock' ),
			'edit_item'     => __( 'Edit program', 'softdock' ),
			'all_items'     => __( 'All programs', 'softdock' ),
			'search_items'  => __( 'Search programs', 'softdock' ),
			'not_found'     => __( 'No programs found', 'softdock' ),
		),
		'public'        => true,
		'has_archive'   => softdock_url_base( 'program' ),
		'menu_icon'     => 'dashicons-download',
		'menu_position' => 5,
		'show_in_rest'  => true,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'comments', 'excerpt', 'revisions', 'custom-fields' ),
		'rewrite'       => array( 'slug' => softdock_url_base( 'program' ), 'with_front' => false ),
	) );

	register_taxonomy( 'platform', 'software', array(
		'labels'            => array(
			'name'          => __( 'Platforms', 'softdock' ),
			'singular_name' => __( 'Platform', 'softdock' ),
			'add_new_item'  => __( 'Add platform', 'softdock' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => softdock_url_base( 'platform' ), 'with_front' => false ),
	) );

	register_taxonomy( 'software_cat', 'software', array(
		'labels'            => array(
			'name'          => __( 'Categories', 'softdock' ),
			'singular_name' => __( 'Category', 'softdock' ),
			'add_new_item'  => __( 'Add category', 'softdock' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => softdock_url_base( 'category' ), 'with_front' => false ),
	) );
}
add_action( 'init', 'softdock_register_types' );

// Refresh permalinks once after the theme's URL structure changes.
add_action( 'init', function () {
	if ( get_option( 'softdock_rewrite_version' ) !== SOFTDOCK_CORE_VERSION ) {
		flush_rewrite_rules( false );
		update_option( 'softdock_rewrite_version', SOFTDOCK_CORE_VERSION );
	}
}, 99 );

function softdock_ensure_platforms() {
	$order = 0;
	foreach ( softdock_default_platforms() as $slug => $name ) {
		$term = term_exists( $slug, 'platform' );
		if ( ! $term ) {
			$term = wp_insert_term( $name, 'platform', array( 'slug' => $slug ) );
		}
		if ( ! is_wp_error( $term ) ) {
			update_term_meta( (int) $term['term_id'], 'softdock_order', $order++ );
		}
	}
}

/** Platforms in tab order. Platforms added later without an order go last. */
function softdock_platforms() {
	$terms = get_terms( array( 'taxonomy' => 'platform', 'hide_empty' => false ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, function ( $a, $b ) {
		$oa = get_term_meta( $a->term_id, 'softdock_order', true );
		$ob = get_term_meta( $b->term_id, 'softdock_order', true );
		$oa = '' === $oa ? 999 : (int) $oa;
		$ob = '' === $ob ? 999 : (int) $ob;
		return $oa === $ob ? strcmp( $a->name, $b->name ) : $oa - $ob;
	} );
	return $terms;
}

/** Sort the admin program list by downloads. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && in_array( $q->get( 'orderby' ), array( 'sd_downloads', 'sd_views' ), true ) ) {
		$q->set( 'meta_key', $q->get( 'orderby' ) );
		$q->set( 'orderby', 'meta_value_num' );
	}
} );

/** "Program published", "Program updated"… instead of "Post published" on the program screen. */
add_filter( 'post_updated_messages', function ( $m ) {
	global $post;
	$link        = $post ? ' <a href="' . esc_url( get_permalink( $post ) ) . '" target="_blank">' . esc_html__( 'View program', 'softdock' ) . '</a>' : '';
	$m['software'] = array(
		1  => __( 'Program updated.', 'softdock' ) . $link,
		4  => __( 'Program updated.', 'softdock' ),
		6  => __( 'Program published.', 'softdock' ) . $link,
		7  => __( 'Program saved.', 'softdock' ),
		8  => __( 'Program submitted for review.', 'softdock' ),
		10 => __( 'Draft saved.', 'softdock' ),
	);
	return $m;
} );

/* ---------- Software → Page URLs ---------- */

add_action( 'admin_init', function () {
	register_setting( 'softdock_urls', 'softdock_urls', array(
		'type'              => 'array',
		'sanitize_callback' => function ( $in ) {
			$in  = is_array( $in ) ? $in : array();
			$out = array();
			$old = array();
			foreach ( array( 'program', 'platform', 'category' ) as $k ) {
				$out[ $k ] = isset( $in[ $k ] ) ? sanitize_title( $in[ $k ] ) : '';
				$before    = softdock_url_base( $k );
				$after     = $out[ $k ] ? $out[ $k ] : $before;
				if ( $after !== $before ) {
					$old[ $k ] = $before;
				}
			}
			if ( $old ) {
				// Remember earlier words so old links keep working (redirected below).
				$hist = get_option( 'softdock_url_history', array() );
				$hist = is_array( $hist ) ? $hist : array();
				foreach ( $old as $k => $word ) {
					$hist[ $k ]   = isset( $hist[ $k ] ) && is_array( $hist[ $k ] ) ? $hist[ $k ] : array();
					$hist[ $k ][] = $word;
					$hist[ $k ]   = array_values( array_unique( $hist[ $k ] ) );
				}
				update_option( 'softdock_url_history', $hist );
			}
			update_option( 'softdock_rewrite_version', '' ); // Rebuild the addresses on the next page load.
			return $out;
		},
	) );
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'edit.php?post_type=software', __( 'Page URLs', 'softdock' ), __( 'Page URLs', 'softdock' ), 'manage_options', 'softdock-urls', 'softdock_render_urls_page' );
}, 12 );

function softdock_render_urls_page() {
	$rows = array(
		'program'  => array( __( 'Program pages', 'softdock' ), array( 'software', 'download', 'downloads', 'app', 'apps', 'program', 'programs', 'soft', 'get' ), 'vlc' ),
		'platform' => array( __( 'Platform pages', 'softdock' ), array( 'platform', 'os', 'for', 'system' ), 'windows' ),
		'category' => array( __( 'Category pages', 'softdock' ), array( 'software-category', 'category', 'categories', 'type', 'apps' ), 'audio' ),
	);
	echo '<div class="wrap sd-cp"><h1>' . esc_html__( 'Page URLs', 'softdock' ) . '</h1>';
	if ( function_exists( 'softdock_cp_tabs' ) ) {
		softdock_cp_tabs();
	}
	echo '<p>' . esc_html__( 'The word in front of each page address. Pick a suggestion or type your own (letters, numbers and dashes). Old addresses keep working: visitors are sent to the new ones.', 'softdock' ) . '</p>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'softdock_urls' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( $rows as $k => $r ) {
		$val = softdock_url_base( $k );
		echo '<tr><th scope="row"><label for="sd_url_' . esc_attr( $k ) . '">' . esc_html( $r[0] ) . '</label></th><td>';
		echo '<code class="sd-url-pre">' . esc_html( untrailingslashit( home_url() ) ) . '/</code><input type="text" id="sd_url_' . esc_attr( $k ) . '" class="regular-text sd-url-word" name="softdock_urls[' . esc_attr( $k ) . ']" value="' . esc_attr( $val ) . '" list="sd_url_list_' . esc_attr( $k ) . '" data-example="' . esc_attr( $r[2] ) . '"><code>/' . esc_html( $r[2] ) . '/</code>';
		echo '<datalist id="sd_url_list_' . esc_attr( $k ) . '">';
		foreach ( $r[1] as $sug ) {
			echo '<option value="' . esc_attr( $sug ) . '">';
		}
		echo '</datalist><p class="sd-url-chips">';
		foreach ( $r[1] as $sug ) {
			echo '<button type="button" class="button button-small" data-for="sd_url_' . esc_attr( $k ) . '" data-word="' . esc_attr( $sug ) . '">' . esc_html( $sug ) . '</button> ';
		}
		echo '</p></td></tr>';
	}
	echo '</tbody></table>';
	submit_button();
	echo '</form></div>';
	echo '<script>document.querySelectorAll(".sd-url-chips button").forEach(function(b){b.addEventListener("click",function(){var i=document.getElementById(b.dataset.for);i.value=b.dataset.word;i.focus();});});</script>';
	echo '<style>.sd-url-pre{background:none;padding:0 2px 0 0;color:#646970}.sd-url-word{width:200px!important}.sd-url-chips{margin-top:8px}.sd-url-chips .button{margin:0 4px 4px 0}</style>';
}

/** Old program, platform and category addresses send visitors to the new ones. */
add_action( 'template_redirect', function () {
	if ( ! is_404() ) {
		return;
	}
	$hist = get_option( 'softdock_url_history', array() );
	if ( ! is_array( $hist ) || ! $hist ) {
		return;
	}
	$path  = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' );
	$home  = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
	$path  = $home && 0 === strpos( $path, $home ) ? trim( substr( $path, strlen( $home ) ), '/' ) : $path;
	$parts = explode( '/', $path );
	if ( count( $parts ) < 1 || '' === $parts[0] ) {
		return;
	}
	$map = array( 'program' => 'software', 'platform' => 'platform', 'category' => 'software_cat' );
	foreach ( $hist as $k => $words ) {
		if ( ! isset( $map[ $k ] ) || ! in_array( $parts[0], (array) $words, true ) ) {
			continue;
		}
		$target = '';
		if ( 'program' === $k ) {
			if ( empty( $parts[1] ) ) {
				$target = get_post_type_archive_link( 'software' );
			} else {
				$p      = get_page_by_path( sanitize_title( $parts[1] ), OBJECT, 'software' );
				$target = $p ? get_permalink( $p ) : '';
			}
		} elseif ( ! empty( $parts[1] ) ) {
			$t      = get_term_by( 'slug', sanitize_title( $parts[1] ), $map[ $k ] );
			$target = $t ? get_term_link( $t ) : '';
		}
		if ( $target && ! is_wp_error( $target ) ) {
			wp_safe_redirect( $target, 301 );
			exit;
		}
	}
}, 1 );
