<?php
/**
 * Software post type, Platform and Category taxonomies.
 */

defined( 'ABSPATH' ) || exit;

/** Default platforms: slug => label. Order here is the order of the tab strip. */
function softdock_default_platforms() {
	return array(
		'windows' => 'Windows',
		'mac'     => 'macOS',
		'android' => 'Android',
		'linux'   => 'Linux',
		'games'   => 'Games',
	);
}

function softdock_register_types() {
	register_post_type( 'software', array(
		'labels'        => array(
			'name'          => __( 'Software', 'softdock' ),
			'singular_name' => __( 'Program', 'softdock' ),
			'add_new_item'  => __( 'Add program', 'softdock' ),
			'edit_item'     => __( 'Edit program', 'softdock' ),
			'all_items'     => __( 'All programs', 'softdock' ),
			'search_items'  => __( 'Search programs', 'softdock' ),
			'not_found'     => __( 'No programs found', 'softdock' ),
		),
		'public'        => true,
		'has_archive'   => 'software',
		'menu_icon'     => 'dashicons-download',
		'menu_position' => 5,
		'show_in_rest'  => true,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'comments', 'excerpt', 'revisions', 'custom-fields' ),
		'rewrite'       => array( 'slug' => 'software', 'with_front' => false ),
	) );

	register_taxonomy( 'platform', 'software', array(
		'labels'            => array(
			'name'          => __( 'Platforms', 'softdock' ),
			'singular_name' => __( 'Platform', 'softdock' ),
			'add_new_item'  => __( 'Add platform', 'softdock' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'platform', 'with_front' => false ),
	) );

	register_taxonomy( 'software_cat', 'software', array(
		'labels'            => array(
			'name'          => __( 'Categories', 'softdock' ),
			'singular_name' => __( 'Category', 'softdock' ),
			'add_new_item'  => __( 'Add category', 'softdock' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'software-category', 'with_front' => false ),
	) );
}
add_action( 'init', 'softdock_register_types' );

// Refresh permalinks once after the theme's URL structure changes.
add_action( 'init', function () {
	if ( get_option( 'softdock_rewrite_version' ) !== SOFTDOCK_CORE_VERSION ) {
		flush_rewrite_rules( false );
		update_option( 'softdock_rewrite_version', SOFTDOCK_CORE_VERSION );
	}
}, 99 );

function softdock_ensure_platforms() {
	$order = 0;
	foreach ( softdock_default_platforms() as $slug => $name ) {
		$term = term_exists( $slug, 'platform' );
		if ( ! $term ) {
			$term = wp_insert_term( $name, 'platform', array( 'slug' => $slug ) );
		}
		if ( ! is_wp_error( $term ) ) {
			update_term_meta( (int) $term['term_id'], 'softdock_order', $order++ );
		}
	}
}

/** Platforms in tab order. Platforms added later without an order go last. */
function softdock_platforms() {
	$terms = get_terms( array( 'taxonomy' => 'platform', 'hide_empty' => false ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	usort( $terms, function ( $a, $b ) {
		$oa = get_term_meta( $a->term_id, 'softdock_order', true );
		$ob = get_term_meta( $b->term_id, 'softdock_order', true );
		$oa = '' === $oa ? 999 : (int) $oa;
		$ob = '' === $ob ? 999 : (int) $ob;
		return $oa === $ob ? strcmp( $a->name, $b->name ) : $oa - $ob;
	} );
	return $terms;
}

/** Sort the admin program list by downloads. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && 'sd_downloads' === $q->get( 'orderby' ) ) {
		$q->set( 'meta_key', 'sd_downloads' );
		$q->set( 'orderby', 'meta_value_num' );
	}
} );
