<?php
/**
 * Posts → Add New Post in the same layout as the program screen:
 * green band, main card with title, summary, featured image and text,
 * and a side card with page URL, categories, tags and publishing.
 * Uses the classic edit form, so WordPress saves everything as usual.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'add_meta_boxes_post', function () {
	foreach ( array( 'categorydiv', 'tagsdiv-post_tag', 'postexcerpt', 'postimagediv', 'postcustom', 'submitdiv', 'slugdiv', 'commentstatusdiv', 'formatdiv' ) as $box ) {
		foreach ( array( 'normal', 'side', 'advanced' ) as $ctx ) {
			remove_meta_box( $box, 'post', $ctx );
		}
	}
}, 99 );

add_action( 'edit_form_top', function ( $post ) {
	if ( 'post' !== $post->post_type ) {
		return;
	}
	$title     = 'auto-draft' === $post->post_status ? '' : $post->post_title;
	$thumb_id  = (int) get_post_thumbnail_id( $post->ID );
	$thumb_url = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'large' ) : '';
	$published = in_array( $post->post_status, array( 'publish', 'future', 'private' ), true );
	$cats      = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );
	$cats      = is_wp_error( $cats ) ? array() : $cats;
	$tags      = wp_get_post_terms( $post->ID, 'post_tag', array( 'fields' => 'names' ) );
	$tags      = is_wp_error( $tags ) ? '' : implode( ', ', $tags );
	$letter    = $title ? ( function_exists( 'mb_substr' ) ? mb_substr( $title, 0, 1 ) : substr( $title, 0, 1 ) ) : 'P';
	$author    = get_userdata( $post->post_author ? $post->post_author : get_current_user_id() );
	$no_title  = __( 'Post title', 'softdock' );

	wp_nonce_field( 'softdock_save', 'softdock_nonce', false );
	?>
	<div class="sd-app sd-post-app" data-empty-title="<?php echo esc_attr( $no_title ); ?>">
		<div class="sd-band">
			<h1><span class="sd-live-title"><?php echo esc_html( $title ? $title : $no_title ); ?></span></h1>
			<nav class="sd-crumbs"><span><?php esc_html_e( 'Home', 'softdock' ); ?></span>›<span class="sd-live-cat"><?php esc_html_e( 'Category', 'softdock' ); ?></span></nav>
		</div>

		<div class="sd-detail">
			<div class="sd-card sd-main">
				<div class="sd-h2">
					<textarea name="post_title" id="title" class="sd-title" rows="1" placeholder="<?php echo esc_attr( $no_title ); ?>" autocomplete="off" spellcheck="true"><?php echo esc_textarea( $title ); ?></textarea>
				</div>
				<input type="text" name="excerpt" id="excerpt" class="sd-lead" value="<?php echo esc_attr( $post->post_excerpt ); ?>" placeholder="<?php esc_attr_e( 'Short summary shown in lists and search results (optional)', 'softdock' ); ?>">

				<input type="hidden" name="sd_icon" id="sd_icon" value="<?php echo $thumb_id ? (int) $thumb_id : ''; ?>">
				<div class="sd-gallery sd-feature<?php echo $thumb_url ? ' has-shots' : ''; ?>">
					<div class="sd-shots"><?php if ( $thumb_url ) : ?><div class="sd-shot on"><img src="<?php echo esc_url( $thumb_url ); ?>" alt=""></div><?php endif; ?></div>
					<div class="sd-mock" aria-hidden="true"><div class="sd-win" style="grid-template-rows:1fr"><div class="sd-pane" style="background:linear-gradient(120deg,#0f7b5fcc,#0f7b5f22)"></div></div></div>
					<div class="sd-gallery-actions">
						<button type="button" class="sd-btn sd-pick-feature"><?php esc_html_e( 'Upload featured image', 'softdock' ); ?></button>
						<button type="button" class="sd-btn sd-btn-ghost sd-clear-feature"><?php esc_html_e( 'Remove', 'softdock' ); ?></button>
					</div>
				</div>

				<h3><?php esc_html_e( 'Post text', 'softdock' ); ?></h3>
				<div class="sd-entry"><?php wp_editor( $post->post_content, 'content', array( 'textarea_rows' => 16, 'media_buttons' => true ) ); ?></div>
			</div>

			<aside class="sd-aside">
				<div class="sd-card sd-side-card">
					<div class="sd-head">
						<div class="sd-ico" style="background:#0f7b5f"><span class="sd-letter"><?php echo esc_html( $letter ); ?></span></div>
						<div class="sd-head-text">
							<b class="sd-live-title"><?php echo esc_html( $title ? $title : $no_title ); ?></b>
							<div class="sd-icon-links"><?php echo esc_html( $published ? __( 'Published', 'softdock' ) : __( 'Draft', 'softdock' ) ); ?></div>
						</div>
					</div>

					<dl class="sd-facts">
						<dt><?php esc_html_e( 'Author', 'softdock' ); ?></dt><dd><?php echo esc_html( $author ? $author->display_name : '' ); ?></dd>
						<dt><?php esc_html_e( 'Date', 'softdock' ); ?></dt><dd><?php echo esc_html( 'auto-draft' === $post->post_status ? __( 'Now', 'softdock' ) : get_the_date( '', $post ) ); ?></dd>
						<dt><?php esc_html_e( 'Comments', 'softdock' ); ?></dt><dd class="sd-num"><?php echo esc_html( number_format_i18n( (int) $post->comment_count ) ); ?></dd>
					</dl>

					<div class="sd-block">
						<label class="sd-label" for="post_name"><?php esc_html_e( 'Page URL', 'softdock' ); ?></label>
						<div class="sd-url">
							<span class="sd-url-base">/</span>
							<input type="text" name="post_name" id="post_name" value="<?php echo esc_attr( 'auto-draft' === $post->post_status ? '' : urldecode( $post->post_name ) ); ?>" placeholder="<?php esc_attr_e( 'post-title', 'softdock' ); ?>" autocomplete="off">
						</div>
						<p class="sd-note"><?php esc_html_e( 'Leave empty to make it from the title.', 'softdock' ); ?></p>
					</div>

					<div class="sd-block">
						<span class="sd-label"><?php esc_html_e( 'Category', 'softdock' ); ?> <a class="sd-add-link" href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=category' ) ); ?>" target="_blank"><?php esc_html_e( 'Add new', 'softdock' ); ?></a></span>
						<?php softdock_editor_terms( $post, 'category', $cats ); ?>
					</div>

					<div class="sd-block">
						<label class="sd-label" for="sd_tags"><?php esc_html_e( 'Tags', 'softdock' ); ?></label>
						<input type="text" name="tax_input[post_tag]" id="sd_tags" class="sd-boxed" value="<?php echo esc_attr( $tags ); ?>" placeholder="<?php esc_attr_e( 'Separate with commas', 'softdock' ); ?>">
					</div>
				</div>

				<div class="sd-card sd-publish">
					<div class="sd-status"><?php esc_html_e( 'Status:', 'softdock' ); ?> <b><?php echo esc_html( $published ? __( 'Published', 'softdock' ) : __( 'Draft', 'softdock' ) ); ?></b>
						<?php if ( $published ) : ?> · <a href="<?php echo esc_url( get_permalink( $post ) ); ?>" target="_blank"><?php esc_html_e( 'View post ↗', 'softdock' ); ?></a><?php endif; ?>
					</div>
					<div class="sd-actions">
						<?php if ( $published ) : ?>
							<input type="submit" name="save" id="publish" class="sd-btn sd-btn-primary" value="<?php esc_attr_e( 'Update', 'softdock' ); ?>">
						<?php else : ?>
							<input type="submit" name="save" id="save-post" class="sd-btn sd-btn-ghost" value="<?php esc_attr_e( 'Save draft', 'softdock' ); ?>">
							<input type="hidden" name="post_status" value="draft">
							<input type="submit" name="publish" id="publish" class="sd-btn sd-btn-primary" value="<?php echo esc_attr( current_user_can( 'publish_posts' ) ? __( 'Publish', 'softdock' ) : __( 'Submit for review', 'softdock' ) ); ?>">
						<?php endif; ?>
					</div>
					<label class="sd-check"><input type="checkbox" name="comment_status" value="open"<?php checked( 'open', $post->comment_status ); ?>> <?php esc_html_e( 'Allow comments', 'softdock' ); ?></label>
					<input type="hidden" name="ping_status" value="<?php echo esc_attr( $post->ping_status ); ?>">
					<?php if ( 'auto-draft' !== $post->post_status && current_user_can( 'delete_post', $post->ID ) ) : ?>
						<a class="sd-trash" href="<?php echo esc_url( get_delete_post_link( $post->ID ) ); ?>"><?php esc_html_e( 'Move to Trash', 'softdock' ); ?></a>
					<?php endif; ?>
				</div>
			</aside>
		</div>
	</div>
	<?php
} );
