<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main class="wrap" id="view">
	<?php
	$shown = 0;
	// Newest programs from every platform, always first (Software → Settings can turn this off).
	if ( ! function_exists( 'softdock_setting' ) || softdock_setting( 'home_latest' ) ) :
		$latest = new WP_Query( array(
			'post_type'           => 'software',
			'posts_per_page'      => 6,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'orderby'             => array( 'date' => 'DESC', 'ID' => 'DESC' ),
		) );
		if ( $latest->have_posts() ) :
			++$shown;
			?>
			<section>
				<div class="sec-h"><h2><?php esc_html_e( 'Latest programs', 'softdock' ); ?></h2><a class="ghost" href="<?php echo esc_url( add_query_arg( 'sort', 'newest', get_post_type_archive_link( 'software' ) ) ); ?>"><?php esc_html_e( 'View all', 'softdock' ); ?></a></div>
				<div class="list">
					<?php
					while ( $latest->have_posts() ) {
						$latest->the_post();
						get_template_part( 'template-parts/software-row' );
					}
					wp_reset_postdata();
					?>
				</div>
			</section>
			<?php
		endif;
	endif;
	foreach ( softdock_platforms() as $plat ) :
		$q = softdock_home_on_platform( $plat->slug );
		if ( ! $q->have_posts() ) {
			continue;
		}
		++$shown;
		?>
		<section>
			<div class="sec-h"><h2><?php echo esc_html( $plat->name ); ?></h2><a class="ghost" href="<?php echo esc_url( get_term_link( $plat ) ); ?>"><?php esc_html_e( 'View all', 'softdock' ); ?></a></div>
			<div class="list">
				<?php
				while ( $q->have_posts() ) {
					$q->the_post();
					get_template_part( 'template-parts/software-row' );
				}
				wp_reset_postdata();
				?>
			</div>
		</section>
	<?php endforeach; ?>
	<?php if ( ! $shown ) : ?>
		<div class="empty">
			<?php esc_html_e( 'No programs yet.', 'softdock' ); ?>
			<?php if ( current_user_can( 'edit_posts' ) ) : ?>
				<br><a style="color:var(--accent);font-weight:600" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=software' ) ); ?>"><?php esc_html_e( 'Add your first program', 'softdock' ); ?></a>
				<?php if ( current_user_can( 'manage_options' ) ) : ?>
					&middot; <a style="color:var(--accent);font-weight:600" href="<?php echo esc_url( admin_url( 'tools.php?page=softdock-sample' ) ); ?>"><?php esc_html_e( 'or import sample programs', 'softdock' ); ?></a>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</main>
<?php
get_footer();
