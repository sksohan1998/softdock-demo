<?php
defined( 'ABSPATH' ) || exit;
get_header();

// Everything below is set in Software → Homepage.
$has_home = function_exists( 'softdock_home' );
ob_start();
$has_side = softdock_popular_sidebar();
$side     = ob_get_clean();
?>
<main class="wrap<?php echo $has_side ? ' with-side' : ''; ?>" id="view">
	<div class="home-main">
	<?php
	$shown = 0;
	$row   = function ( $q ) {
		while ( $q->have_posts() ) {
			$q->the_post();
			get_template_part( 'template-parts/software-row' );
		}
		wp_reset_postdata();
	};

	// Latest programs from every platform, at the top.
	if ( ! $has_home || softdock_home( 'latest_show' ) ) :
		$latest = $has_home ? softdock_home_query( 'latest', softdock_home( 'latest_count' ) ) : softdock_home_on_platform( '', 6 );
		if ( $latest->have_posts() ) :
			++$shown;
			?>
			<section>
				<div class="sec-h"><h2><?php echo esc_html( $has_home ? softdock_home( 'latest_title' ) : __( 'Latest programs', 'softdock' ) ); ?></h2><a class="ghost" href="<?php echo esc_url( add_query_arg( 'sort', 'newest', get_post_type_archive_link( 'software' ) ) ); ?>"><?php esc_html_e( 'View all', 'softdock' ); ?></a></div>
				<div class="list"><?php $row( $latest ); ?></div>
			</section>
			<?php
		endif;
	endif;

	// One section per platform, in the order and with the headings chosen in the admin.
	$sections = $has_home ? softdock_home_sections() : array_map( function ( $t ) {
		return array( 'term' => $t, 'show' => 1, 'title' => $t->name );
	}, softdock_platforms() );
	foreach ( $sections as $sec ) :
		if ( ! $sec['show'] ) {
			continue;
		}
		$plat = $sec['term'];
		$q    = $has_home ? softdock_home_query( softdock_home( 'section_order' ), softdock_home( 'section_count' ), $plat->slug ) : softdock_home_on_platform( $plat->slug );
		if ( ! $q->have_posts() ) {
			continue;
		}
		++$shown;
		?>
		<section>
			<div class="sec-h"><h2><?php echo esc_html( $sec['title'] ); ?></h2><a class="ghost" href="<?php echo esc_url( get_term_link( $plat ) ); ?>"><?php esc_html_e( 'View all', 'softdock' ); ?></a></div>
			<div class="list"><?php $row( $q ); ?></div>
		</section>
	<?php endforeach; ?>

	<?php if ( ! $shown ) : ?>
		<div class="empty">
			<?php esc_html_e( 'No programs yet.', 'softdock' ); ?>
			<?php if ( current_user_can( 'edit_posts' ) ) : ?>
				<br><a style="color:var(--accent);font-weight:600" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=software' ) ); ?>"><?php esc_html_e( 'Add your first program', 'softdock' ); ?></a>
				<?php if ( current_user_can( 'manage_options' ) ) : ?>
					&middot; <a style="color:var(--accent);font-weight:600" href="<?php echo esc_url( admin_url( 'tools.php?page=softdock-sample' ) ); ?>"><?php esc_html_e( 'or import sample programs', 'softdock' ); ?></a>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	</div>
	<?php echo $side; // phpcs:ignore WordPress.Security.EscapeOutput -- built by softdock_popular_sidebar(), which escapes. ?>
</main>
<?php
get_footer();
