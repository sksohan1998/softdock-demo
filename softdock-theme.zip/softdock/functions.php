<?php
/**
 * Softdock theme setup.
 */

defined( 'ABSPATH' ) || exit;

define( 'SOFTDOCK_VERSION', '1.4.0' );

/*
 * Programs, platforms, categories, downloads and ratings live in the Softdock Core plugin,
 * so content stays when the theme changes. Without it, the theme shows a notice and plain pages.
 */
add_action( 'after_setup_theme', function () {
	if ( defined( 'SOFTDOCK_CORE' ) ) {
		require get_template_directory() . '/inc/helpers.php';
		require get_template_directory() . '/inc/queries.php';
	}
} );

add_action( 'admin_notices', function () {
	if ( defined( 'SOFTDOCK_CORE' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p>' . esc_html__( 'The Softdock theme needs the Softdock Core plugin. Upload and activate it under Plugins → Add New → Upload Plugin.', 'softdock' ) . '</p></div>';
} );

/** Without the plugin, use the plain fallback template for everything. */
add_filter( 'template_include', function ( $template ) {
	return defined( 'SOFTDOCK_CORE' ) ? $template : get_template_directory() . '/index.php';
} );

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'softdock', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 68, 'width' => 68, 'flex-width' => true ) );
	add_image_size( 'softdock-icon', 104, 104, true );
	add_image_size( 'softdock-shot', 1280, 720, false );
	register_nav_menus( array( 'footer' => __( 'Footer menu', 'softdock' ) ) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'softdock-fonts', 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600&family=JetBrains+Mono:wght@500&display=swap', array(), null );
	wp_enqueue_style( 'softdock', get_stylesheet_uri(), array( 'softdock-fonts' ), SOFTDOCK_VERSION );
	wp_enqueue_script( 'softdock', get_template_directory_uri() . '/assets/site.js', array(), SOFTDOCK_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'softdock', 'softdock', array(
		'ajax' => admin_url( 'admin-ajax.php' ),
		'i18n' => array(
			'thanks' => __( 'Thanks for rating.', 'softdock' ),
			'failed' => __( 'Could not save your rating. Check your connection and try again.', 'softdock' ),
		),
	) );
	if ( is_singular( 'software' ) && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
} );

// New comments wait for approval unless the admin changes this in Settings → Discussion.
add_action( 'after_switch_theme', function () {
	update_option( 'comment_moderation', 1 );
	flush_rewrite_rules();
} );

/** Keep the chip and category caches fresh when programs or terms change. */
function softdock_bump_cache() {
	wp_cache_set( 'last_changed', microtime(), 'softdock' );
}
add_action( 'save_post_software', 'softdock_bump_cache' );
add_action( 'deleted_post', 'softdock_bump_cache' );
add_action( 'trashed_post', 'softdock_bump_cache' );
add_action( 'set_object_terms', 'softdock_bump_cache' );
add_action( 'edited_term', 'softdock_bump_cache' );
add_action( 'delete_term', 'softdock_bump_cache' );
