<?php defined( 'ABSPATH' ) || exit; ?>
<footer><div class="wrap">
	<span><?php echo esc_html( get_bloginfo( 'description' ) ); ?></span>
	<?php
	wp_nav_menu( array(
		'theme_location' => 'footer',
		'container'      => false,
		'depth'          => 1,
		'fallback_cb'    => false,
		'items_wrap'     => '<ul style="display:flex;gap:16px;list-style:none;margin:0;padding:0;flex-wrap:wrap">%3$s</ul>',
	) );
	?>
	<span>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></span>
</div></footer>
<?php wp_footer(); ?>
</body>
</html>
