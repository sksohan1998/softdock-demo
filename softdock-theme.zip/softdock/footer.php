<?php defined( 'ABSPATH' ) || exit; ?>
<?php if ( softdock_opt( 'footer_show', 1 ) ) : ?>
<footer><div class="wrap">
	<?php
	$ftext = trim( (string) softdock_opt( 'footer_text', '' ) );
	$ftext = '' !== $ftext ? $ftext : esc_html( get_bloginfo( 'description' ) );
	?>
	<span class="foot-text"><?php echo wp_kses( $ftext, array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ), 'strong' => array(), 'em' => array(), 'br' => array() ) ); ?></span>
	<?php
	if ( softdock_opt( 'footer_menu_show', 1 ) ) {
		wp_nav_menu( array(
			'theme_location' => 'footer',
			'container'      => false,
			'depth'          => 1,
			'fallback_cb'    => false,
			'items_wrap'     => '<ul style="display:flex;gap:16px;list-style:none;margin:0;padding:0;flex-wrap:wrap">%3$s</ul>',
		) );
	}
	$copy = (string) softdock_opt( 'footer_copyright', '© {year} {site}' );
	if ( '' !== trim( $copy ) ) {
		echo '<span>' . esc_html( strtr( $copy, array( '{year}' => wp_date( 'Y' ), '{site}' => get_bloginfo( 'name' ) ) ) ) . '</span>';
	}
	?>
</div></footer>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
