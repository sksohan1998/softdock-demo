(function () {
  /* Keep the sticky header right under the WordPress admin bar, or at the very top when
     the bar is hidden, scrolls away (phones) or is not shown at all. */
  var head = document.querySelector('body > header, header');
  function placeHeader() {
    if (!head) return;
    var bar = document.getElementById('wpadminbar');
    var top = 0;
    if (bar) {
      var cs = getComputedStyle(bar);
      if (cs.position === 'fixed' && cs.display !== 'none' && cs.visibility !== 'hidden') top = bar.getBoundingClientRect().bottom;
    }
    head.style.top = Math.max(0, Math.round(top)) + 'px';
  }
  placeHeader();

  /* Search button opens the search box under the menu bar ("/" also opens it). */
  var sbtn = document.getElementById('searchbtn'), spanel = document.getElementById('searchpanel');
  if (sbtn && spanel) {
    var openSearch = function (open) {
      spanel.hidden = !open; sbtn.setAttribute('aria-expanded', String(open));
      if (open) { var i = document.getElementById('q'); if (i) i.focus(); }
    };
    sbtn.addEventListener('click', function () { openSearch(spanel.hidden); });
    document.addEventListener('keydown', function (e) {
      var tag = (e.target.tagName || '').toLowerCase();
      if (e.key === '/' && spanel.hidden && tag !== 'input' && tag !== 'textarea' && !e.target.isContentEditable) { e.preventDefault(); openSearch(true); }
      if (e.key === 'Escape' && !spanel.hidden && document.activeElement && document.activeElement.id === 'q' && !document.activeElement.value) openSearch(false);
    });
  }

  /* Search suggestions while typing. */
  var q = document.getElementById('q'), box = document.getElementById('q-suggest');
  if (q && box && window.softdock && softdock.suggest) {
    var t = softdock.i18n || {}, timer, active = -1, last = '', ctrl;
    var esc = function (v) { var d = document.createElement('div'); d.textContent = v == null ? '' : String(v); return d.innerHTML; };
    var close = function () { box.hidden = true; q.setAttribute('aria-expanded', 'false'); active = -1; };
    var items = function () { return box.querySelectorAll('a'); };
    var mark = function (i) {
      var a = items(); if (!a.length) return;
      active = (i + a.length) % a.length;
      for (var k = 0; k < a.length; k++) a[k].classList.toggle('on', k === active);
      a[active].scrollIntoView({ block: 'nearest' });
    };
    var render = function (list, term) {
      var h = '';
      list.forEach(function (it, i) {
        if (it.type === 'program') {
          var ico = it.icon ? (it.svg ? '<span style="background:' + esc(it.color) + '"><img class="s-svg" src="' + esc(it.icon) + '" alt=""></span>' : '<img src="' + esc(it.icon) + '" alt="">') : '<span style="background:' + esc(it.color) + '">' + esc(it.letter) + '</span>';
          h += '<a role="option" href="' + esc(it.url) + '"><i class="s-ico">' + ico + '</i><b>' + esc(it.title) + '</b><small>' + esc(it.version) + '</small></a>';
        } else {
          h += '<a role="option" class="s-term" href="' + esc(it.url) + '"><i class="s-ico s-tag">#</i><b>' + esc(it.title) + '</b><small>' + esc(it.type === 'platform' ? t.platform : t.category) + ' · ' + it.count + '</small></a>';
        }
      });
      if (!list.length) h = '<p class="s-none">' + esc(t.noResult) + '</p>';
      else h += '<a role="option" class="s-all" href="' + esc(q.form.action) + '?s=' + encodeURIComponent(term) + '&post_type=software">' + esc(t.seeAll) + ' “' + esc(term) + '”</a>';
      box.innerHTML = h; box.hidden = false;
      // Phones: the list spans the screen, just under the search box.
      box.style.top = window.innerWidth <= 520 ? Math.round(q.getBoundingClientRect().bottom + 6) + 'px' : ''; q.setAttribute('aria-expanded', 'true'); active = -1;
    };
    var lookup = function () {
      var term = q.value.trim();
      if (!term) { close(); last = ''; return; }
      if (term === last) { box.hidden = false; return; }
      last = term;
      if (ctrl && ctrl.abort) ctrl.abort();
      ctrl = window.AbortController ? new AbortController() : null;
      fetch(softdock.ajax + '?action=softdock_suggest&q=' + encodeURIComponent(term), ctrl ? { signal: ctrl.signal } : {})
        .then(function (r) { return r.json(); })
        .then(function (j) { if (q.value.trim() === term) render((j && j.data && j.data.items) || [], term); })
        .catch(function () {});
    };
    q.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(lookup, 120); });
    q.addEventListener('focus', function () { if (q.value.trim() && box.innerHTML) box.hidden = false; });
    q.addEventListener('keydown', function (e) {
      if (box.hidden) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); mark(active + 1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); mark(active - 1); }
      else if (e.key === 'Enter' && active >= 0) { e.preventDefault(); items()[active].click(); }
      else if (e.key === 'Escape') { close(); }
    });
    document.addEventListener('click', function (e) { if (!q.form.contains(e.target)) close(); });
  }

  /* Light / dark mode switch. Light is the default. */
  var tbtn = document.getElementById('themebtn');
  if (tbtn) tbtn.addEventListener('click', function () {
    var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    // Remembered only while this tab is open: every new visit starts in light mode.
    try { sessionStorage.setItem('sdTheme', dark ? 'dark' : 'light'); } catch (e) {}
  });

  /* Magnet buttons: open the torrent app without leaving the page, and count the click. */
  var magFrame;
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[data-count]');
    if (a) {
      e.preventDefault();
      var u = a.getAttribute('data-count');
      if (navigator.sendBeacon) navigator.sendBeacon(u); else fetch(u, { keepalive: true, credentials: 'same-origin' });
      if (!magFrame) { magFrame = document.createElement('iframe'); magFrame.hidden = true; magFrame.setAttribute('aria-hidden', 'true'); document.body.appendChild(magFrame); }
      magFrame.src = a.getAttribute('href');
      return;
    }
    var b = e.target.closest && e.target.closest('.dl-none');
    if (b) {
      var note = b.parentNode.querySelector('.dl-note');
      if (!note) { note = document.createElement('p'); note.className = 'note dl-note'; note.setAttribute('role', 'status'); b.insertAdjacentElement('afterend', note); }
      note.textContent = b.getAttribute('data-note');
    }
  });
  window.addEventListener('resize', placeHeader);
  window.addEventListener('load', placeHeader);

  var btn = document.getElementById('catbtn');
  var menu = document.getElementById('catmenu');
  function closeMenu() { if (menu) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); } }
  if (btn && menu) {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      menu.hidden = !menu.hidden;
      btn.setAttribute('aria-expanded', String(!menu.hidden));
    });
    document.addEventListener('click', function (e) { if (!menu.contains(e.target)) closeMenu(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });
  }

  var sort = document.getElementById('sort');
  if (sort) sort.addEventListener('change', function () { sort.form.submit(); });

  var gal = document.getElementById('gal');
  if (gal) {
    var idx = 0;
    gal.addEventListener('click', function (e) {
      var b = e.target.closest('[data-shot]');
      if (!b) return;
      var shots = gal.querySelectorAll('.shot'), dots = gal.querySelectorAll('.dots i');
      idx = (idx + Number(b.dataset.shot) + shots.length) % shots.length;
      shots.forEach(function (s, i) { s.classList.toggle('on', i === idx); });
      dots.forEach(function (d, i) { d.classList.toggle('on', i === idx); });
    });
  }

  var rate = document.querySelector('.rate');
  if (rate && window.softdock) {
    var msg = rate.querySelector('.rate-msg');
    rate.addEventListener('click', function (e) {
      var b = e.target.closest('[data-stars]');
      if (!b || rate.hasAttribute('data-done')) return;
      var body = new FormData();
      body.append('action', 'softdock_rate');
      body.append('post', rate.dataset.post);
      body.append('stars', b.dataset.stars);
      rate.setAttribute('data-done', '');
      fetch(softdock.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (r) {
          if (!r.success) { msg.textContent = (r.data && r.data.message) || softdock.i18n.failed; return; }
          rate.querySelectorAll('[data-stars]').forEach(function (s) { s.classList.toggle('on', Number(s.dataset.stars) <= Number(b.dataset.stars)); });
          msg.textContent = softdock.i18n.thanks;
          var score = document.getElementById('sd-score');
          if (score) {
            var full = Math.round(r.data.rating);
            score.innerHTML = '<span class="stars">' + '★'.repeat(full) + '<s>' + '★'.repeat(5 - full) + '</s></span> <span class="num" style="color:var(--muted);font-size:13px"></span>';
            score.lastChild.textContent = Number(r.data.rating).toFixed(1) + ' (' + r.data.count + ')';
          }
        })
        .catch(function () { msg.textContent = softdock.i18n.failed; rate.removeAttribute('data-done'); });
    });
  }
})();
