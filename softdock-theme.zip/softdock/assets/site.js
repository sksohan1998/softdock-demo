(function () {
  /* Keep the sticky header right under the WordPress admin bar, or at the very top when
     the bar is hidden, scrolls away (phones) or is not shown at all. */
  var head = document.querySelector('body > header, header');
  function placeHeader() {
    if (!head) return;
    var bar = document.getElementById('wpadminbar');
    var top = 0;
    if (bar) {
      var cs = getComputedStyle(bar);
      if (cs.position === 'fixed' && cs.display !== 'none' && cs.visibility !== 'hidden') top = bar.getBoundingClientRect().bottom;
    }
    head.style.top = Math.max(0, Math.round(top)) + 'px';
  }
  placeHeader();

  /* Light / dark mode switch. Light is the default. */
  var tbtn = document.getElementById('themebtn');
  if (tbtn) tbtn.addEventListener('click', function () {
    var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    // Remembered only while this tab is open: every new visit starts in light mode.
    try { sessionStorage.setItem('sdTheme', dark ? 'dark' : 'light'); } catch (e) {}
  });

  /* Magnet buttons open the torrent app directly; count the click in the background. */
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[data-count]');
    if (!a) return;
    var u = a.getAttribute('data-count');
    if (navigator.sendBeacon) navigator.sendBeacon(u); else fetch(u, { keepalive: true, credentials: 'same-origin' });
  });
  window.addEventListener('resize', placeHeader);
  window.addEventListener('load', placeHeader);

  var btn = document.getElementById('catbtn');
  var menu = document.getElementById('catmenu');
  function closeMenu() { if (menu) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); } }
  if (btn && menu) {
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      menu.hidden = !menu.hidden;
      btn.setAttribute('aria-expanded', String(!menu.hidden));
    });
    document.addEventListener('click', function (e) { if (!menu.contains(e.target)) closeMenu(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });
  }

  var sort = document.getElementById('sort');
  if (sort) sort.addEventListener('change', function () { sort.form.submit(); });

  var gal = document.getElementById('gal');
  if (gal) {
    var idx = 0;
    gal.addEventListener('click', function (e) {
      var b = e.target.closest('[data-shot]');
      if (!b) return;
      var shots = gal.querySelectorAll('.shot'), dots = gal.querySelectorAll('.dots i');
      idx = (idx + Number(b.dataset.shot) + shots.length) % shots.length;
      shots.forEach(function (s, i) { s.classList.toggle('on', i === idx); });
      dots.forEach(function (d, i) { d.classList.toggle('on', i === idx); });
    });
  }

  var rate = document.querySelector('.rate');
  if (rate && window.softdock) {
    var msg = rate.querySelector('.rate-msg');
    rate.addEventListener('click', function (e) {
      var b = e.target.closest('[data-stars]');
      if (!b || rate.hasAttribute('data-done')) return;
      var body = new FormData();
      body.append('action', 'softdock_rate');
      body.append('post', rate.dataset.post);
      body.append('stars', b.dataset.stars);
      rate.setAttribute('data-done', '');
      fetch(softdock.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (r) {
          if (!r.success) { msg.textContent = (r.data && r.data.message) || softdock.i18n.failed; return; }
          rate.querySelectorAll('[data-stars]').forEach(function (s) { s.classList.toggle('on', Number(s.dataset.stars) <= Number(b.dataset.stars)); });
          msg.textContent = softdock.i18n.thanks;
          var score = document.getElementById('sd-score');
          if (score) {
            var full = Math.round(r.data.rating);
            score.innerHTML = '<span class="stars">' + '★'.repeat(full) + '<s>' + '★'.repeat(5 - full) + '</s></span> <span class="num" style="color:var(--muted);font-size:13px"></span>';
            score.lastChild.textContent = Number(r.data.rating).toFixed(1) + ' (' + r.data.count + ')';
          }
        })
        .catch(function () { msg.textContent = softdock.i18n.failed; rate.removeAttribute('data-done'); });
    });
  }
})();
