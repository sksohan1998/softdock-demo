<?php
defined( 'ABSPATH' ) || exit;
get_header();
the_post();

$pid      = get_the_ID();
$ver      = get_post_meta( $pid, 'sd_version', true );
$tagline  = get_post_meta( $pid, 'sd_tagline', true );
$lic      = get_post_meta( $pid, 'sd_license', true );
$dev      = get_post_meta( $pid, 'sd_developer', true );
$official = get_post_meta( $pid, 'sd_official_url', true );
$rating   = (float) get_post_meta( $pid, 'sd_rating', true );
$votes    = (int) get_post_meta( $pid, 'sd_rating_count', true );
$cat      = softdock_first_term( $pid, 'software_cat' );
$plat     = softdock_main_platform( $pid );
$os       = softdock_os_list( $pid );
$shots    = array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $pid, 'sd_screenshots', true ) ) ) );
$features = softdock_lines( $pid, 'sd_features' );
$reqs     = softdock_lines( $pid, 'sd_requirements' );
$versions = softdock_versions( $pid );
list( $sz, $unit ) = softdock_size( get_post_meta( $pid, 'sd_size_mb', true ) );
$target = softdock_download_target( $pid );
$hosted = $target && absint( get_post_meta( $pid, 'sd_file', true ) ) && wp_get_attachment_url( absint( get_post_meta( $pid, 'sd_file', true ) ) ) === $target;
$host   = $target ? wp_parse_url( $target, PHP_URL_HOST ) : '';
?>
<div class="band"><div class="wrap">
	<h1><?php the_title(); ?> <?php echo esc_html( $ver ); ?></h1>
	<nav class="crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'softdock' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'softdock' ); ?></a>
		<?php if ( $plat ) : ?>›<a href="<?php echo esc_url( get_term_link( $plat ) ); ?>"><?php echo esc_html( $plat->name ); ?></a><?php endif; ?>
		<?php if ( $cat ) : ?>›<a href="<?php echo esc_url( get_term_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a><?php endif; ?>
	</nav>
</div></div>
<main class="wrap" id="view">
<div class="detail">
	<article class="card">
		<h2>
			<?php
			/* translators: 1: program name, 2: version */
			echo esc_html( sprintf( __( '%1$s %2$s download', 'softdock' ), get_the_title(), $ver ) );
			?>
		</h2>
		<?php if ( $tagline ) : ?>
			<p class="lead">
				<?php
				echo esc_html( rtrim( $tagline, '.' ) . '.' );
				if ( $os ) {
					/* translators: %s: list of operating systems */
					echo ' ' . esc_html( sprintf( __( 'For %s.', 'softdock' ), implode( ', ', $os ) ) );
				}
				?>
			</p>
		<?php endif; ?>

		<div class="gallery" id="gal">
			<?php if ( $shots ) : ?>
				<?php foreach ( array_values( $shots ) as $i => $id ) : ?>
					<div class="shot <?php echo 0 === $i ? 'on' : ''; ?>"><?php echo wp_get_attachment_image( $id, 'softdock-shot', false, array( 'loading' => $i ? 'lazy' : 'eager' ) ); ?></div>
				<?php endforeach; ?>
			<?php else : ?>
				<?php
				$color = get_post_meta( $pid, 'sd_color', true );
				$color = $color ? $color : '#0f7b5f';
				foreach ( array( __( 'Main window', 'softdock' ), __( 'Settings', 'softdock' ), __( 'Projects', 'softdock' ) ) as $i => $label ) :
					?>
					<div class="shot mock <?php echo 0 === $i ? 'on' : ''; ?>" aria-hidden="true"><div class="win"><div class="tb"><i></i><i></i><i></i>&nbsp;<?php echo esc_html( get_the_title() . ' — ' . $label ); ?></div><div class="bd"><div class="side"></div><div class="pane" style="background:linear-gradient(<?php echo (int) ( 120 + $i * 50 ); ?>deg,<?php echo esc_attr( $color ); ?>cc,<?php echo esc_attr( $color ); ?>22)"></div></div></div></div>
				<?php endforeach; ?>
				<?php $shots = array( 1, 2, 3 ); ?>
			<?php endif; ?>
			<?php if ( count( $shots ) > 1 ) : ?>
				<button class="arrow l" data-shot="-1" aria-label="<?php esc_attr_e( 'Previous screenshot', 'softdock' ); ?>">‹</button>
				<button class="arrow r" data-shot="1" aria-label="<?php esc_attr_e( 'Next screenshot', 'softdock' ); ?>">›</button>
				<div class="dots"><?php foreach ( array_values( $shots ) as $i => $unused ) : ?><i class="<?php echo 0 === $i ? 'on' : ''; ?>"></i><?php endforeach; ?></div>
			<?php endif; ?>
		</div>

		<?php /* translators: %s: program name */ ?>
		<h3><?php echo esc_html( sprintf( __( 'Overview of %s', 'softdock' ), get_the_title() ) ); ?></h3>
		<div class="entry"><?php the_content(); ?></div>

		<?php if ( $features ) : ?>
			<h3><?php esc_html_e( 'Features', 'softdock' ); ?></h3>
			<ul class="feat"><?php foreach ( $features as $f ) : ?><li><?php echo esc_html( $f ); ?></li><?php endforeach; ?></ul>
		<?php endif; ?>

		<?php if ( $reqs ) : ?>
			<h3><?php esc_html_e( 'System requirements', 'softdock' ); ?></h3>
			<ul><?php foreach ( $reqs as $r ) : ?><li><?php echo esc_html( $r ); ?></li><?php endforeach; ?></ul>
		<?php endif; ?>

		<?php if ( $versions ) : ?>
			<h3><?php esc_html_e( 'Previous versions', 'softdock' ); ?></h3>
			<div class="tbl-wrap"><table>
				<thead><tr><th><?php esc_html_e( 'Date', 'softdock' ); ?></th><th><?php esc_html_e( 'Version', 'softdock' ); ?></th><th><?php esc_html_e( 'Size', 'softdock' ); ?></th><th><span class="screen-reader-text"><?php esc_html_e( 'Link', 'softdock' ); ?></span></th></tr></thead>
				<tbody>
				<?php foreach ( $versions as $v ) : ?>
					<?php $ts = strtotime( $v['date'] ); ?>
					<tr>
						<td><?php echo esc_html( $ts ? wp_date( get_option( 'date_format' ), $ts ) : $v['date'] ); ?></td>
						<td class="num"><?php echo esc_html( $v['version'] ); ?></td>
						<td class="num"><?php echo esc_html( implode( ' ', softdock_size( $v['size'] ) ) ); ?></td>
						<td><?php if ( $v['url'] ) : ?><a href="<?php echo esc_url( $v['url'] ); ?>" target="_blank" rel="noopener nofollow" style="color:var(--accent);font-weight:600"><?php esc_html_e( 'Official archive ↗', 'softdock' ); ?></a><?php endif; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		<?php endif; ?>

		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
		?>
	</article>

	<aside class="aside">
		<div class="card" style="padding:20px">
			<div style="display:flex;gap:12px;align-items:center">
				<?php echo softdock_icon( $pid ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<div><b style="font-size:17px"><?php the_title(); ?></b>
					<div id="sd-score"><?php echo softdock_stars( $rating, $votes ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php if ( $votes ) : ?> <span class="num" style="color:var(--muted);font-size:13px"><?php echo esc_html( number_format_i18n( $rating, 1 ) ); ?> (<?php echo esc_html( number_format_i18n( $votes ) ); ?>)</span><?php endif; ?></div>
				</div>
			</div>
			<dl class="facts">
				<?php if ( $ver ) : ?><dt><?php esc_html_e( 'Version', 'softdock' ); ?></dt><dd class="num"><?php echo esc_html( $ver ); ?></dd><?php endif; ?>
				<dt><?php esc_html_e( 'Size', 'softdock' ); ?></dt><dd class="num"><?php echo esc_html( trim( $sz . ' ' . $unit ) ); ?></dd>
				<?php if ( $lic ) : ?><dt><?php esc_html_e( 'License', 'softdock' ); ?></dt><dd><?php echo esc_html( $lic ); ?></dd><?php endif; ?>
				<?php if ( $dev ) : ?><dt><?php esc_html_e( 'Developer', 'softdock' ); ?></dt><dd><?php echo esc_html( $dev ); ?></dd><?php endif; ?>
				<?php if ( $cat ) : ?><dt><?php esc_html_e( 'Category', 'softdock' ); ?></dt><dd><a href="<?php echo esc_url( get_term_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a></dd><?php endif; ?>
				<dt><?php esc_html_e( 'Updated', 'softdock' ); ?></dt><dd><?php echo esc_html( get_the_modified_date() ); ?></dd>
				<dt><?php esc_html_e( 'Downloads', 'softdock' ); ?></dt><dd class="num"><?php echo esc_html( number_format_i18n( (int) get_post_meta( $pid, 'sd_downloads', true ) ) ); ?></dd>
			</dl>
			<?php if ( $target && $hosted ) : ?>
				<a class="dl" href="<?php echo esc_url( softdock_download_url( $pid ) ); ?>" rel="nofollow" style="margin-top:18px"><?php esc_html_e( 'Download now', 'softdock' ); ?></a>
				<?php /* translators: %s: file name */ ?>
				<p class="note"><?php echo esc_html( sprintf( __( 'File: %s', 'softdock' ), wp_basename( wp_parse_url( $target, PHP_URL_PATH ) ) ) ); ?></p>
				<?php if ( $official ) : ?><p class="note"><a href="<?php echo esc_url( $official ); ?>" target="_blank" rel="noopener nofollow" style="color:var(--accent)"><?php esc_html_e( 'Official website ↗', 'softdock' ); ?></a></p><?php endif; ?>
			<?php elseif ( $target ) : ?>
				<a class="dl" href="<?php echo esc_url( softdock_download_url( $pid ) ); ?>" target="_blank" rel="noopener nofollow" style="margin-top:18px"><?php esc_html_e( 'Download from official site ↗', 'softdock' ); ?></a>
				<?php /* translators: %s: website host name */ ?>
				<p class="note"><?php echo esc_html( sprintf( __( 'Opens %s in a new tab.', 'softdock' ), $host ) ); ?></p>
			<?php endif; ?>
			<div class="rate" data-post="<?php echo (int) $pid; ?>">
				<span><?php esc_html_e( 'Rate it:', 'softdock' ); ?></span>
				<span>
					<?php for ( $i = 1; $i <= 5; $i++ ) : ?>
						<?php /* translators: %d: number of stars */ ?>
						<button type="button" data-stars="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr( sprintf( _n( '%d star', '%d stars', $i, 'softdock' ), $i ) ); ?>">★</button>
					<?php endfor; ?>
				</span>
				<span class="rate-msg" role="status"></span>
			</div>
		</div>

		<?php
		$related = $cat ? new WP_Query( array(
			'post_type'      => 'software',
			'posts_per_page' => 5,
			'post__not_in'   => array( $pid ),
			'no_found_rows'  => true,
			'meta_query'     => softdock_meta_order_clause( 'sd_downloads' ),
			'orderby'        => array( 'has' => 'DESC' ),
			'tax_query'      => array( array( 'taxonomy' => 'software_cat', 'terms' => $cat->term_id ) ),
		) ) : null;
		if ( $related && $related->have_posts() ) :
			?>
			<div class="card" style="padding:16px">
				<?php /* translators: %s: category name */ ?>
				<b style="font-family:var(--display);font-size:16px"><?php echo esc_html( sprintf( __( 'More in %s', 'softdock' ), $cat->name ) ); ?></b>
				<div style="display:grid;gap:2px;margin-top:8px">
					<?php
					while ( $related->have_posts() ) :
						$related->the_post();
						?>
						<a class="mini" href="<?php the_permalink(); ?>"><?php echo softdock_icon(); // phpcs:ignore WordPress.Security.EscapeOutput ?><div><b><?php the_title(); ?></b><small><?php echo esc_html( get_post_meta( get_the_ID(), 'sd_version', true ) . ' · ' . implode( ' ', softdock_size( get_post_meta( get_the_ID(), 'sd_size_mb', true ) ) ) ); ?></small></div></a>
						<?php
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		<?php endif; ?>
	</aside>
</div>
</main>
<?php
get_footer();
