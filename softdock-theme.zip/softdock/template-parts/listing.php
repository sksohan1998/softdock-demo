<?php
/**
 * Shared listing layout for platform, category, all-software and search pages.
 */
defined( 'ABSPATH' ) || exit;
global $wp_query;

/*
 * The page's own term. With a filter in the URL (?platform= or ?software_cat=), WordPress may report
 * the filter term as the queried object, so take the term from the other taxonomy instead.
 */
$obj = get_queried_object();
foreach ( array( 'platform' => 'software_cat', 'software_cat' => 'platform' ) as $filter => $page_tax ) {
	if ( isset( $_GET[ $filter ] ) && get_query_var( $page_tax ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$page_term = get_term_by( 'slug', sanitize_title( get_query_var( $page_tax ) ), $page_tax );
		if ( $page_term ) {
			$obj = $page_term;
		}
		break;
	}
}
if ( is_search() ) {
	/* translators: %s: search terms */
	$title = sprintf( __( 'Results for “%s”', 'softdock' ), get_search_query() );
} elseif ( $obj instanceof WP_Term ) {
	$title = $obj->name;
} else {
	$title = __( 'All software', 'softdock' );
}

// Chips: on a platform page filter by category, everywhere else filter by platform.
$filter_tax = ( $obj instanceof WP_Term && 'platform' === $obj->taxonomy ) ? 'software_cat' : 'platform';
$active     = isset( $_GET[ $filter_tax ] ) ? sanitize_title( wp_unslash( $_GET[ $filter_tax ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$chips      = softdock_terms_in( $filter_tax, $obj instanceof WP_Term ? $obj : null, is_search() ? get_search_query( false ) : '' );
if ( 'platform' === $filter_tax ) {
	$order = wp_list_pluck( softdock_platforms(), 'term_id' );
	usort( $chips, function ( $a, $b ) use ( $order ) {
		return (int) array_search( $a->term_id, $order, true ) - (int) array_search( $b->term_id, $order, true );
	} );
}
$base_url = remove_query_arg( array( $filter_tax, 'paged' ) );
$base_url = preg_replace( '#/page/\d+/?#', '/', $base_url );
$sort     = softdock_current_sort();
?>
<div class="band"><div class="wrap">
	<h1><?php echo esc_html( $title ); ?></h1>
	<nav class="crumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'softdock' ); ?>"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'softdock' ); ?></a>›<span><?php echo esc_html( $title ); ?></span></nav>
</div></div>
<main class="wrap" id="view">
<section>
	<form class="toolbar" method="get" action="">
		<?php if ( is_search() ) : ?>
			<input type="hidden" name="s" value="<?php echo esc_attr( get_search_query() ); ?>"><input type="hidden" name="post_type" value="software">
		<?php endif; ?>
		<?php if ( $active ) : ?><input type="hidden" name="<?php echo esc_attr( $filter_tax ); ?>" value="<?php echo esc_attr( $active ); ?>"><?php endif; ?>
		<label for="sort" style="color:var(--muted);font-size:13px"><?php esc_html_e( 'Sort', 'softdock' ); ?></label>
		<select id="sort" name="sort">
			<?php foreach ( softdock_sorts() as $k => $label ) : ?>
				<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $sort, $k ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
		<noscript><button class="ghost"><?php esc_html_e( 'Apply', 'softdock' ); ?></button></noscript>
		<span style="flex:1"></span>
		<span class="num" style="color:var(--muted);font-size:13px">
			<?php
			/* translators: %s: number of programs */
			echo esc_html( sprintf( _n( '%s program', '%s programs', $wp_query->found_posts, 'softdock' ), number_format_i18n( $wp_query->found_posts ) ) );
			?>
		</span>
	</form>
	<?php if ( count( $chips ) > 1 ) : ?>
		<div class="toolbar">
			<a class="chip <?php echo $active ? '' : 'on'; ?>" href="<?php echo esc_url( $base_url ); ?>"><?php esc_html_e( 'All', 'softdock' ); ?></a>
			<?php foreach ( $chips as $chip ) : ?>
				<a class="chip <?php echo $active === $chip->slug ? 'on' : ''; ?>" href="<?php echo esc_url( add_query_arg( $filter_tax, $chip->slug, $base_url ) ); ?>"><?php echo esc_html( $chip->name ); ?></a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<div class="list">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/software-row' );
			}
		} else {
			echo '<div class="empty">' . esc_html__( 'Nothing matches. Try a shorter search or another category.', 'softdock' ) . '</div>';
		}
		?>
	</div>
	<?php
	$links = paginate_links( array( 'type' => 'array', 'prev_text' => '‹', 'next_text' => '›' ) );
	if ( $links ) {
		echo '<nav class="pager" aria-label="' . esc_attr__( 'Pages', 'softdock' ) . '">' . implode( '', $links ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	?>
</section>
</main>
