<?php
defined( 'ABSPATH' ) || exit;
$pid  = get_the_ID();
$cat  = softdock_first_term( $pid, 'software_cat' );
$plat = softdock_main_platform( $pid );
$here = get_query_var( 'platform' ) ? get_term_by( 'slug', sanitize_title( get_query_var( 'platform' ) ), 'platform' ) : null;
if ( $here && has_term( $here->term_id, 'platform', $pid ) ) {
	$plat = $here;
}
$lic  = get_post_meta( $pid, 'sd_license', true );
list( $sz, $unit ) = softdock_size( get_post_meta( $pid, 'sd_size_mb', true ) );
?>
<article class="row">
	<?php echo softdock_icon( $pid ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<div style="min-width:0">
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?> <span><?php echo esc_html( get_post_meta( $pid, 'sd_version', true ) ); ?></span></a></h3>
		<p><?php echo esc_html( get_post_meta( $pid, 'sd_tagline', true ) ); ?></p>
		<?php if ( $cat ) : ?><span class="tag"><?php echo esc_html( $cat->name ); ?></span><?php endif; ?>
		<?php if ( $lic ) : ?><span class="lic"><?php echo esc_html( $lic ); ?></span><?php endif; ?>
	</div>
	<div class="meta"><b><?php echo $plat ? esc_html( $plat->name ) : '—'; ?></b><span class="num">↓ <?php echo esc_html( number_format_i18n( (int) get_post_meta( $pid, 'sd_downloads', true ) ) ); ?></span></div>
	<div class="meta"><?php esc_html_e( 'Rating', 'softdock' ); ?><?php echo softdock_stars( get_post_meta( $pid, 'sd_rating', true ), (int) get_post_meta( $pid, 'sd_rating_count', true ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
	<div class="size"><?php echo esc_html( $sz ); ?><small><?php echo esc_html( $unit ); ?></small></div>
</article>
