<?php
defined( 'ABSPATH' ) || exit;
get_header();
get_template_part( 'template-parts/listing' );
get_footer();
