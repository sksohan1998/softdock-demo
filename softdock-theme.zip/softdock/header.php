<?php defined( 'ABSPATH' ) || exit; ?><!doctype html>
<html <?php language_attributes(); ?> data-theme="light">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{localStorage.removeItem('sdTheme');if(sessionStorage.getItem('sdTheme')==='dark')document.documentElement.setAttribute('data-theme','dark')}catch(e){}</script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#view"><?php esc_html_e( 'Skip to content', 'softdock' ); ?></a>
<header class="topnav<?php echo softdock_opt( 'header_sticky', 1 ) ? '' : ' not-sticky'; ?>">
	<div class="wrap">
		<div class="capsule">
			<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php
				if ( has_custom_logo() ) {
					$logo = wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'style' => 'height:34px;width:auto' ) );
					echo $logo; // phpcs:ignore WordPress.Security.EscapeOutput
				} else {
					echo '<i>' . esc_html( function_exists( 'mb_substr' ) ? mb_substr( get_bloginfo( 'name' ), 0, 1 ) : substr( get_bloginfo( 'name' ), 0, 1 ) ) . '</i>';
				}
				?>
				<?php if ( softdock_opt( 'logo_text_show', 1 ) ) : ?><b><?php bloginfo( 'name' ); ?></b><?php endif; ?>
			</a>

			<?php if ( defined( 'SOFTDOCK_CORE' ) ) : ?>
				<?php if ( has_nav_menu( 'header' ) ) : ?>
					<nav class="pills" aria-label="<?php esc_attr_e( 'Main menu', 'softdock' ); ?>">
						<?php
						wp_nav_menu( array(
							'theme_location' => 'header',
							'container'      => false,
							'depth'          => 1,
							'items_wrap'     => '%3$s',
							'walker'         => new Softdock_Tab_Walker(),
						) );
						?>
					</nav>
				<?php else : ?>
					<nav class="pills" aria-label="<?php esc_attr_e( 'Platforms', 'softdock' ); ?>">
						<?php
						$current     = 0;
						$plat_in_url = get_query_var( 'platform' );
						if ( $plat_in_url && ! isset( $_GET['platform'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
							$t       = get_term_by( 'slug', sanitize_title( $plat_in_url ), 'platform' );
							$current = $t ? $t->term_id : 0;
						}
						foreach ( softdock_platforms() as $plat ) {
							printf( '<a href="%s" class="%s">%s<span>%s</span></a>', esc_url( get_term_link( $plat ) ), $current === $plat->term_id ? 'on' : '', softdock_platform_icon( $plat->slug ), esc_html( $plat->name ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- fixed SVG markup.
						}
						?>
					</nav>
				<?php endif; ?>
			<?php else : ?>
				<span class="pills"></span>
			<?php endif; ?>

			<div class="cap-right">
				<?php $search_bar = 'bar' === softdock_opt( 'search_mode', 'icon' ); ?>
				<?php if ( softdock_head_show( 'search' ) && ! $search_bar ) : ?>
				<button class="iconbtn" id="searchbtn" type="button" aria-expanded="<?php echo is_search() ? 'true' : 'false'; ?>" aria-controls="searchpanel" aria-label="<?php esc_attr_e( 'Search', 'softdock' ); ?>" title="<?php esc_attr_e( 'Search', 'softdock' ); ?>">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
				</button>
				<?php endif; ?>
				<?php if ( softdock_head_show( 'theme_btn' ) ) : ?>
				<button class="iconbtn themebtn" id="themebtn" type="button" aria-label="<?php esc_attr_e( 'Switch light or dark mode', 'softdock' ); ?>" title="<?php esc_attr_e( 'Light / dark mode', 'softdock' ); ?>">
					<svg class="i-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
					<svg class="i-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
				</button>
				<?php endif; ?>
				<?php if ( defined( 'SOFTDOCK_CORE' ) && softdock_head_show( 'cats' ) ) : ?>
				<button class="catbtn" id="catbtn" type="button" aria-expanded="false" aria-controls="catmenu"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><rect x="13" y="13" width="8" height="8" rx="2"/></svg><span><?php echo esc_html( softdock_opt( 'cats_label', __( 'Categories', 'softdock' ) ) ); ?></span></button>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( softdock_head_show( 'search' ) ) : ?>
		<div class="search-panel<?php echo $search_bar ? ' is-bar' : ''; ?>" id="searchpanel"<?php echo ( is_search() || $search_bar ) ? '' : ' hidden'; ?>>
			<form class="search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label for="q" class="screen-reader-text"><?php esc_html_e( 'Search software', 'softdock' ); ?></label>
				<svg viewBox="0 0 24 24" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
				<input id="q" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr( softdock_opt( 'search_placeholder', __( 'Search software…', 'softdock' ) ) ); ?>" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="q-suggest">
				<div class="suggest" id="q-suggest" role="listbox" hidden></div>
				<?php if ( defined( 'SOFTDOCK_CORE' ) ) : ?><input type="hidden" name="post_type" value="software"><?php endif; ?>
			</form>
		</div>
		<?php endif; ?>

		<?php if ( defined( 'SOFTDOCK_CORE' ) ) : ?>
		<div class="catmenu" id="catmenu" hidden>
			<?php
			$cats = get_terms( array( 'taxonomy' => 'software_cat', 'hide_empty' => true ) );
			if ( ! is_wp_error( $cats ) ) {
				foreach ( $cats as $cat ) {
					printf( '<a href="%s">%s<small>%d</small></a>', esc_url( get_term_link( $cat ) ), esc_html( $cat->name ), (int) $cat->count );
				}
			}
			?>
		</div>
		<?php endif; ?>
	</div>
</header>
