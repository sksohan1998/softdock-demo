<?php
/**
 * Fallback for blog posts, pages and anything without its own template.
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main class="wrap" id="view">
	<?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class( 'card' ); ?>>
				<?php if ( is_singular() ) : ?>
					<h2><?php the_title(); ?></h2>
					<div class="entry"><?php the_content(); ?></div>
					<?php
					wp_link_pages();
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
				<?php else : ?>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<div class="entry"><?php the_excerpt(); ?></div>
				<?php endif; ?>
			</article>
		<?php endwhile; ?>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<div class="empty"><?php esc_html_e( 'This page could not be found.', 'softdock' ); ?> <a style="color:var(--accent)" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go to the home page', 'softdock' ); ?></a></div>
	<?php endif; ?>
</main>
<?php
get_footer();
