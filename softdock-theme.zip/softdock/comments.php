<?php
defined( 'ABSPATH' ) || exit;
if ( post_password_required() ) {
	return;
}
?>
<section id="comments">
	<h3><?php esc_html_e( 'Comments', 'softdock' ); ?> <span class="num" style="color:var(--muted);font-size:15px">(<?php echo esc_html( number_format_i18n( get_comments_number() ) ); ?>)</span></h3>
	<?php
	comment_form( array(
		'title_reply'         => __( 'Leave a comment', 'softdock' ),
		'title_reply_before'  => '<p id="reply-title" class="comment-reply-title" style="font-weight:600;margin:0 0 8px">',
		'title_reply_after'   => '</p>',
		'label_submit'        => __( 'Post comment', 'softdock' ),
		'comment_notes_after' => '',
	) );
	if ( have_comments() ) :
		?>
		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'style'       => 'ol',
				'short_ping'  => true,
				'avatar_size' => 0,
			) );
			?>
		</ol>
		<?php
		the_comments_navigation();
	endif;
	?>
</section>
