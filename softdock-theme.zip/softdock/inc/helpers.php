<?php
/**
 * Template helpers.
 */

defined( 'ABSPATH' ) || exit;

/** Returns [number, unit] for a size in MB. */
function softdock_size( $mb ) {
	$mb = (float) $mb;
	if ( $mb <= 0 ) {
		return array( '—', '' );
	}
	if ( $mb >= 1024 ) {
		return array( number_format_i18n( $mb / 1024, 2 ), 'GB' );
	}
	if ( $mb < 1 ) {
		return array( number_format_i18n( max( 1, round( $mb * 1024 ) ) ), 'KB' );
	}
	return array( $mb < 10 ? number_format_i18n( $mb, 1 ) : number_format_i18n( round( $mb ) ), 'MB' );
}

function softdock_stars( $rating, $count = null ) {
	if ( 0 === $count ) {
		return '<span class="stars" style="color:var(--muted);letter-spacing:0;font-size:12px">' . esc_html__( 'No ratings yet', 'softdock' ) . '</span>';
	}
	$rating = max( 0, min( 5, (float) $rating ) );
	$full   = (int) round( $rating );
	/* translators: %s: rating */
	$label = sprintf( __( '%s out of 5', 'softdock' ), number_format_i18n( $rating, 1 ) );
	return '<span class="stars" role="img" aria-label="' . esc_attr( $label ) . '">' . str_repeat( '★', $full ) . '<s>' . str_repeat( '★', 5 - $full ) . '</s></span>';
}

function softdock_icon( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( has_post_thumbnail( $post_id ) ) {
		return '<div class="ico">' . get_the_post_thumbnail( $post_id, 'softdock-icon', array( 'alt' => '' ) ) . '</div>';
	}
	$color  = get_post_meta( $post_id, 'sd_color', true );
	$color  = $color ? $color : '#0f7b5f';
	$letter = function_exists( 'mb_substr' ) ? mb_substr( get_the_title( $post_id ), 0, 1 ) : substr( get_the_title( $post_id ), 0, 1 );
	return '<div class="ico" style="background:' . esc_attr( $color ) . '" aria-hidden="true">' . esc_html( $letter ) . '</div>';
}

/** First platform of a program in tab order, skipping "games" when there is another. */
function softdock_main_platform( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$terms   = get_the_terms( $post_id, 'platform' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	$order = wp_list_pluck( softdock_platforms(), 'term_id' );
	usort( $terms, function ( $a, $b ) use ( $order ) {
		return array_search( $a->term_id, $order, true ) - array_search( $b->term_id, $order, true );
	} );
	foreach ( $terms as $t ) {
		if ( 'games' !== $t->slug ) {
			return $t;
		}
	}
	return $terms[0];
}

function softdock_first_term( $post_id, $tax ) {
	$terms = get_the_terms( $post_id, $tax );
	return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
}

function softdock_lines( $post_id, $key ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $post_id, $key, true ) ) ) ) );
}

/** Previous versions as arrays: date, version, size, url. */
function softdock_versions( $post_id ) {
	$out = array();
	foreach ( softdock_lines( $post_id, 'sd_versions' ) as $line ) {
		$p    = array_map( 'trim', explode( '|', $line ) );
		$name = isset( $p[0] ) ? $p[0] : '';
		// Older entries started with a date (2026-09-10); show it as a readable date.
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $name ) && strtotime( $name ) ) {
			$name = wp_date( get_option( 'date_format' ), strtotime( $name ) );
		}
		$size = isset( $p[2] ) ? $p[2] : '';
		if ( '' !== $size && is_numeric( $size ) ) {
			$size = implode( ' ', softdock_size( $size ) ); // A plain number means MB.
		}
		$out[] = array(
			'name'    => $name,
			'version' => isset( $p[1] ) ? $p[1] : '',
			'size'    => $size,
			'url'     => ! empty( $p[3] ) ? $p[3] : '',
		);
	}
	return $out;
}

/** Platform labels a program runs on, excluding the Games grouping. */
function softdock_os_list( $post_id ) {
	$terms = get_the_terms( $post_id, 'platform' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return array();
	}
	return wp_list_pluck( array_filter( $terms, function ( $t ) {
		return 'games' !== $t->slug;
	} ), 'name' );
}

/** Sort options for listing pages: key => label. */
function softdock_sorts() {
	return array(
		// When download counts are hidden from visitors, don't mention downloads.
		'popular' => softdock_show( 'downloads' ) ? __( 'Most downloaded', 'softdock' ) : __( 'Most popular', 'softdock' ),
		'newest'  => __( 'Recently updated', 'softdock' ),
		'rating'  => __( 'Top rated', 'softdock' ),
		'name'    => __( 'Name A–Z', 'softdock' ),
		'size'    => __( 'Smallest first', 'softdock' ),
	);
}

function softdock_current_sort() {
	$sort = isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : 'popular'; // phpcs:ignore WordPress.Security.NonceVerification
	return array_key_exists( $sort, softdock_sorts() ) ? $sort : 'popular';
}

/**
 * Terms of $tax used by published programs, optionally limited to programs in another term.
 * One SQL query, cached until programs or terms change.
 */
function softdock_terms_in( $tax, $within = null, $search = '' ) {
	global $wpdb;
	$last = wp_cache_get( 'last_changed', 'softdock' );
	if ( ! $last ) {
		$last = microtime();
		wp_cache_set( 'last_changed', $last, 'softdock' );
	}
	$key = 'terms_' . md5( $tax . '|' . ( $within ? $within->term_taxonomy_id : 0 ) . '|' . $search . '|' . $last );
	$ids = wp_cache_get( $key, 'softdock' );
	if ( false === $ids ) {
		$ids = get_transient( 'softdock_' . $key );
	}
	if ( false === $ids ) {
		$sql  = "SELECT DISTINCT tt.term_id FROM {$wpdb->term_taxonomy} tt
			INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
			INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id AND p.post_type = 'software' AND p.post_status = 'publish'";
		$args = array();
		if ( $within ) {
			$sql   .= " INNER JOIN {$wpdb->term_relationships} w ON w.object_id = p.ID AND w.term_taxonomy_id = %d";
			$args[] = $within->term_taxonomy_id;
		}
		$sql   .= ' WHERE tt.taxonomy = %s';
		$args[] = $tax;
		if ( '' !== $search ) {
			$like   = '%' . $wpdb->esc_like( $search ) . '%';
			$sql   .= ' AND ( p.post_title LIKE %s OR p.post_content LIKE %s OR p.post_excerpt LIKE %s )';
			$args[] = $like;
			$args[] = $like;
			$args[] = $like;
		}
		$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $args ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		wp_cache_set( $key, $ids, 'softdock', HOUR_IN_SECONDS );
		if ( ! wp_using_ext_object_cache() ) {
			set_transient( 'softdock_' . $key, $ids, 10 * MINUTE_IN_SECONDS );
		}
	}
	if ( ! $ids ) {
		return array();
	}
	$terms = get_terms( array( 'taxonomy' => $tax, 'include' => $ids, 'hide_empty' => false, 'orderby' => 'name' ) );
	return is_wp_error( $terms ) ? array() : $terms;
}

/** Whether visitors see a counter (downloads or views), from Software → Settings. */
function softdock_show( $what ) {
	return function_exists( 'softdock_setting' ) ? (bool) softdock_setting( 'show_' . $what ) : true;
}

/** Prints the right-side blocks (Popular list, Categories box, banner) set in Software → Homepage. */
function softdock_popular_sidebar() {
	if ( ! function_exists( 'softdock_home' ) ) {
		return false;
	}
	$blocks = array();

	if ( softdock_home( 'popular_show' ) ) {
		$q = softdock_home_query( softdock_home( 'popular_by' ), softdock_home( 'popular_count' ), '', softdock_home( 'popular_cat' ) );
		if ( $q->have_posts() ) {
			$html = '<div class="card side-card"><h2>' . esc_html( softdock_home( 'popular_title' ) ) . '</h2><ol class="pop">';
			$n    = 0;
			while ( $q->have_posts() ) {
				$q->the_post();
				$pid   = get_the_ID();
				$html .= '<li><a class="mini" href="' . esc_url( get_permalink() ) . '"><span class="pop-n">' . (int) ++$n . '</span>' . softdock_icon( $pid ) . '<div><b>' . esc_html( get_the_title() ) . '</b><small>' . esc_html( trim( get_post_meta( $pid, 'sd_version', true ) . ' · ' . implode( ' ', softdock_size( get_post_meta( $pid, 'sd_size_mb', true ) ) ), ' ·' ) ) . '</small></div></a></li>';
			}
			wp_reset_postdata();
			$blocks[ (int) softdock_home( 'order_popular' ) * 10 + 1 ] = $html . '</ol></div>';
		}
	}

	if ( softdock_home( 'cats_show' ) ) {
		$cats = get_terms( array( 'taxonomy' => 'software_cat', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => (int) softdock_home( 'cats_count' ) ) );
		if ( $cats && ! is_wp_error( $cats ) ) {
			$html = '<div class="card side-card"><h2>' . esc_html( softdock_home( 'cats_title' ) ) . '</h2><ul class="side-cats">';
			foreach ( $cats as $c ) {
				$html .= '<li><a href="' . esc_url( get_term_link( $c ) ) . '"><span>' . esc_html( $c->name ) . '</span><small>' . (int) $c->count . '</small></a></li>';
			}
			$blocks[ (int) softdock_home( 'order_cats' ) * 10 + 2 ] = $html . '</ul></div>';
		}
	}

	$img = (int) softdock_home( 'banner_image' );
	if ( softdock_home( 'banner_show' ) && $img && wp_get_attachment_image_url( $img, 'medium_large' ) ) {
		$pic  = wp_get_attachment_image( $img, 'medium_large', false, array( 'class' => 'side-banner-img', 'loading' => 'lazy' ) );
		$link = softdock_home( 'banner_link' );
		$html = $link ? '<a class="side-banner" href="' . esc_url( $link ) . '" rel="sponsored noopener"' . ( softdock_home( 'banner_newtab' ) ? ' target="_blank"' : '' ) . '>' . $pic . '</a>' : '<div class="side-banner">' . $pic . '</div>';
		$blocks[ (int) softdock_home( 'order_banner' ) * 10 + 3 ] = $html;
	}

	if ( ! $blocks ) {
		return false;
	}
	ksort( $blocks );
	echo '<aside class="home-side">' . implode( '', $blocks ) . '</aside>'; // phpcs:ignore WordPress.Security.EscapeOutput -- every part is escaped above.
	return true;
}

/** Small icon for a platform tab, by slug. */
function softdock_platform_icon( $slug ) {
	$icons = array(
		'windows' => '<path d="M3 5.5 10.5 4.5v7H3zM12 4.3 21 3v8.5h-9zM3 12.5h7.5v7L3 18.5zM12 12.5h9V21l-9-1.3z" fill="currentColor" stroke="none"/>',
		'mac'     => '<path d="M16.5 12.6c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.1-2.8.9-3.5.9s-1.8-.9-3-.8c-1.5 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.3.8 1.1 1.7 2.4 2.9 2.3 1.2 0 1.6-.7 3-.7s1.8.7 3 .7c1.3 0 2.1-1.1 2.8-2.3.9-1.3 1.3-2.6 1.3-2.6s-2.5-1-2.5-3.8zM14.2 5.8c.6-.8 1.1-1.9 1-3-.9 0-2.1.6-2.7 1.4-.6.7-1.1 1.8-1 2.9 1 .1 2.1-.5 2.7-1.3z" fill="currentColor" stroke="none"/>',
		'android' => '<path d="M6 10h12v7a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1zM4 10.5v5M20 10.5v5M9 18v3M15 18v3M7.5 8.5a4.5 4.5 0 0 1 9 0zM8 4l1.5 2M16 4l-1.5 2"/>',
		'linux'   => '<path d="M12 3c-2 0-3 1.8-3 4 0 1.5-.6 2.6-1.6 4C6 12.7 5 14.6 5 16.5 5 19 7 21 9 21h6c2 0 4-2 4-4.5 0-1.9-1-3.8-2.4-5.5-1-1.4-1.6-2.5-1.6-4 0-2.2-1-4-3-4z"/><circle cx="10.5" cy="8" r=".6" fill="currentColor"/><circle cx="13.5" cy="8" r=".6" fill="currentColor"/>',
		'games'   => '<path d="M7 9h10a4 4 0 0 1 3.9 4.8l-.7 3.4a2 2 0 0 1-3.4 1L15 16.5H9l-1.8 1.7a2 2 0 0 1-3.4-1l-.7-3.4A4 4 0 0 1 7 9zM8 11.5v3M6.5 13h3M15.5 12.5h.01M17.5 14h.01"/>',
	);
	$path = isset( $icons[ $slug ] ) ? $icons[ $slug ] : '<rect x="4" y="5" width="16" height="11" rx="2"/><path d="M9 20h6M12 16v4"/>';
	return '<svg class="tab-ico" viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}
