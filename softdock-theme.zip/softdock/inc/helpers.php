<?php
/**
 * Template helpers.
 */

defined( 'ABSPATH' ) || exit;

/** Returns [number, unit] for a size in MB. */
function softdock_size( $mb ) {
	$mb = (float) $mb;
	if ( $mb <= 0 ) {
		return array( '—', '' );
	}
	if ( $mb >= 1024 ) {
		return array( number_format_i18n( $mb / 1024, 2 ), 'GB' );
	}
	if ( $mb < 1 ) {
		return array( number_format_i18n( max( 1, round( $mb * 1024 ) ) ), 'KB' );
	}
	return array( $mb < 10 ? number_format_i18n( $mb, 1 ) : number_format_i18n( round( $mb ) ), 'MB' );
}

function softdock_stars( $rating, $count = null ) {
	if ( 0 === $count ) {
		return '<span class="stars" style="color:var(--muted);letter-spacing:0;font-size:12px">' . esc_html__( 'No ratings yet', 'softdock' ) . '</span>';
	}
	$rating = max( 0, min( 5, (float) $rating ) );
	$full   = (int) round( $rating );
	/* translators: %s: rating */
	$label = sprintf( __( '%s out of 5', 'softdock' ), number_format_i18n( $rating, 1 ) );
	return '<span class="stars" role="img" aria-label="' . esc_attr( $label ) . '">' . str_repeat( '★', $full ) . '<s>' . str_repeat( '★', 5 - $full ) . '</s></span>';
}

function softdock_icon( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	if ( has_post_thumbnail( $post_id ) ) {
		return '<div class="ico">' . get_the_post_thumbnail( $post_id, 'softdock-icon', array( 'alt' => '' ) ) . '</div>';
	}
	$color  = get_post_meta( $post_id, 'sd_color', true );
	$color  = $color ? $color : '#0f7b5f';
	$letter = function_exists( 'mb_substr' ) ? mb_substr( get_the_title( $post_id ), 0, 1 ) : substr( get_the_title( $post_id ), 0, 1 );
	return '<div class="ico" style="background:' . esc_attr( $color ) . '" aria-hidden="true">' . esc_html( $letter ) . '</div>';
}

/** First platform of a program in tab order, skipping "games" when there is another. */
function softdock_main_platform( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$terms   = get_the_terms( $post_id, 'platform' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	$order = wp_list_pluck( softdock_platforms(), 'term_id' );
	usort( $terms, function ( $a, $b ) use ( $order ) {
		return array_search( $a->term_id, $order, true ) - array_search( $b->term_id, $order, true );
	} );
	foreach ( $terms as $t ) {
		if ( 'games' !== $t->slug ) {
			return $t;
		}
	}
	return $terms[0];
}

function softdock_first_term( $post_id, $tax ) {
	$terms = get_the_terms( $post_id, $tax );
	return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
}

function softdock_lines( $post_id, $key ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $post_id, $key, true ) ) ) ) );
}

/** Previous versions as arrays: date, version, size, url. */
function softdock_versions( $post_id ) {
	$out = array();
	foreach ( softdock_lines( $post_id, 'sd_versions' ) as $line ) {
		$p = array_map( 'trim', explode( '|', $line ) );
		$out[] = array(
			'date'    => isset( $p[0] ) ? $p[0] : '',
			'version' => isset( $p[1] ) ? $p[1] : '',
			'size'    => isset( $p[2] ) ? (float) $p[2] : 0,
			'url'     => ! empty( $p[3] ) ? $p[3] : get_post_meta( $post_id, 'sd_official_url', true ),
		);
	}
	return $out;
}

/** Platform labels a program runs on, excluding the Games grouping. */
function softdock_os_list( $post_id ) {
	$terms = get_the_terms( $post_id, 'platform' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return array();
	}
	return wp_list_pluck( array_filter( $terms, function ( $t ) {
		return 'games' !== $t->slug;
	} ), 'name' );
}

/** Sort options for listing pages: key => label. */
function softdock_sorts() {
	return array(
		// When download counts are hidden from visitors, don't mention downloads.
		'popular' => softdock_show( 'downloads' ) ? __( 'Most downloaded', 'softdock' ) : __( 'Most popular', 'softdock' ),
		'newest'  => __( 'Recently updated', 'softdock' ),
		'rating'  => __( 'Top rated', 'softdock' ),
		'name'    => __( 'Name A–Z', 'softdock' ),
		'size'    => __( 'Smallest first', 'softdock' ),
	);
}

function softdock_current_sort() {
	$sort = isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : 'popular'; // phpcs:ignore WordPress.Security.NonceVerification
	return array_key_exists( $sort, softdock_sorts() ) ? $sort : 'popular';
}

/**
 * Terms of $tax used by published programs, optionally limited to programs in another term.
 * One SQL query, cached until programs or terms change.
 */
function softdock_terms_in( $tax, $within = null, $search = '' ) {
	global $wpdb;
	$last = wp_cache_get( 'last_changed', 'softdock' );
	if ( ! $last ) {
		$last = microtime();
		wp_cache_set( 'last_changed', $last, 'softdock' );
	}
	$key = 'terms_' . md5( $tax . '|' . ( $within ? $within->term_taxonomy_id : 0 ) . '|' . $search . '|' . $last );
	$ids = wp_cache_get( $key, 'softdock' );
	if ( false === $ids ) {
		$ids = get_transient( 'softdock_' . $key );
	}
	if ( false === $ids ) {
		$sql  = "SELECT DISTINCT tt.term_id FROM {$wpdb->term_taxonomy} tt
			INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
			INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id AND p.post_type = 'software' AND p.post_status = 'publish'";
		$args = array();
		if ( $within ) {
			$sql   .= " INNER JOIN {$wpdb->term_relationships} w ON w.object_id = p.ID AND w.term_taxonomy_id = %d";
			$args[] = $within->term_taxonomy_id;
		}
		$sql   .= ' WHERE tt.taxonomy = %s';
		$args[] = $tax;
		if ( '' !== $search ) {
			$like   = '%' . $wpdb->esc_like( $search ) . '%';
			$sql   .= ' AND ( p.post_title LIKE %s OR p.post_content LIKE %s OR p.post_excerpt LIKE %s )';
			$args[] = $like;
			$args[] = $like;
			$args[] = $like;
		}
		$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $args ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		wp_cache_set( $key, $ids, 'softdock', HOUR_IN_SECONDS );
		if ( ! wp_using_ext_object_cache() ) {
			set_transient( 'softdock_' . $key, $ids, 10 * MINUTE_IN_SECONDS );
		}
	}
	if ( ! $ids ) {
		return array();
	}
	$terms = get_terms( array( 'taxonomy' => $tax, 'include' => $ids, 'hide_empty' => false, 'orderby' => 'name' ) );
	return is_wp_error( $terms ) ? array() : $terms;
}

/** Whether visitors see a counter (downloads or views), from Software → Settings. */
function softdock_show( $what ) {
	return function_exists( 'softdock_setting' ) ? (bool) softdock_setting( 'show_' . $what ) : true;
}
