<?php
/**
 * Query changes for listings and search.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	$listing = $q->is_search() || $q->is_post_type_archive( 'software' ) || $q->is_tax( array( 'platform', 'software_cat' ) );
	if ( ! $listing ) {
		return;
	}
	if ( $q->is_search() ) {
		$q->set( 'post_type', 'software' );
	}
	$q->set( 'posts_per_page', 12 );

	switch ( softdock_current_sort() ) {
		case 'newest':
			$q->set( 'orderby', 'modified' );
			$q->set( 'order', 'DESC' );
			break;
		case 'name':
			$q->set( 'orderby', 'title' );
			$q->set( 'order', 'ASC' );
			break;
		case 'rating':
			softdock_order_by_meta( $q, 'sd_rating', 'DESC' );
			break;
		case 'size':
			softdock_order_by_meta( $q, 'sd_size_mb', 'ASC' );
			break;
		default:
			if ( $q->is_search() && ! isset( $_GET['sort'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				return; // Keep WordPress relevance order for plain searches.
			}
			softdock_order_by_meta( $q, 'sd_downloads', 'DESC' );
	}
} );

/** Orders by a numeric meta key while keeping posts that lack it. */
function softdock_order_by_meta( $q, $key, $order ) {
	$q->set( 'meta_query', softdock_meta_order_clause( $key ) );
	$q->set( 'orderby', array( 'has' => $order, 'title' => 'ASC' ) );
}

/** Most downloaded programs on a platform, for the home page sections. */
function softdock_top_on_platform( $slug, $count = 6 ) {
	return new WP_Query( array(
		'post_type'           => 'software',
		'posts_per_page'      => $count,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'meta_query'          => softdock_meta_order_clause( 'sd_downloads' ),
		'orderby'             => array( 'has' => 'DESC', 'title' => 'ASC' ),
		'tax_query'           => array( array( 'taxonomy' => 'platform', 'field' => 'slug', 'terms' => $slug ) ),
	) );
}

/** Meta query that orders by a number but still includes programs without that value. */
function softdock_meta_order_clause( $key ) {
	return array(
		'relation' => 'OR',
		'has'      => array( 'key' => $key, 'type' => 'DECIMAL(12,2)' ),
		'missing'  => array( 'key' => $key, 'compare' => 'NOT EXISTS' ),
	);
}
